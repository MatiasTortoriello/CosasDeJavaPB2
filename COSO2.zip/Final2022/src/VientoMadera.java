
public class VientoMadera extends Viento {

	public VientoMadera(String name, int tono, String descr, int tp) {
		super(name, tono, descr, tp);
		// TODO Auto-generated constructor stub
	}
	
	public void tocar() {
	 System.out.println("soy un instrumento de viento de madera y estoy tocando");	
	}

	@Override
	public void afinar() {
		System.out.println("soy un instrumento de viento de madera y me estoy afinando");
		
	}

	@Override
	public void lustrar() {
		// TODO Auto-generated method stub
		
	}

}
