package ar.edu.unlam.Class;

import java.util.TreeSet;

public class ComplejoSimple extends Complejo {
	
	TreeSet<Participantes> listaParticipantes=new TreeSet<Participantes>();
	TreeSet<Comisario> listaComisario=new TreeSet<Comisario>();
	
	public ComplejoSimple(Integer id,String nombre, Double areaOcupada) {
		super(id, nombre, areaOcupada);
		
	}

	public TreeSet<Participantes> getListaParticipantes() {
		return listaParticipantes;
	}

	public void setListaParticipantes(TreeSet<Participantes> listaParticipantes) {
		this.listaParticipantes = listaParticipantes;
	}

	public TreeSet<Comisario> getListaComisario() {
		return listaComisario;
	}

	public void setListaComisario(TreeSet<Comisario> listaComisario) {
		this.listaComisario = listaComisario;
	}
	

}
