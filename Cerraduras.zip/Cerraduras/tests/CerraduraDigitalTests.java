import org.junit.Assert;
import org.junit.Test;

public class CerraduraDigitalTests {

	@Test
	public void puedoCrearla() {
		new CerraduraDigital(1, 2, 3);
	}

	@Test
	public void abre() {
		CerraduraDigital c = new CerraduraDigital(1, 2, 3);
		c.ingresarClave(1, 2, 3);

		Assert.assertTrue(c.presionarOk());
	}

	@Test
	public void noAbre() {
		CerraduraDigital c = new CerraduraDigital(1, 2, 3);
		c.ingresarClave(3, 2, 1);

		Assert.assertFalse(c.presionarOk());
	}
	
	@Test
	public void abrirDeUna() {
		CerraduraDigital c = new CerraduraDigital(0, 0, 0);

		Assert.assertFalse(c.presionarOk());
	}

}
