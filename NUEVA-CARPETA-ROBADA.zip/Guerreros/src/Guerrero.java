
public class Guerrero extends UnidadAtaque{
	
	private int vida=100;
	private boolean estaVivo=true;
	private int danio;
	
	
	public Guerrero(int vida, int danio) {
		this.vida = vida;
		this.danio = danio;
	}


	public void atacar(UnidadAtaque atacado){
		if(this.estaVivo)
			atacado.recibirAtaque(danio);
	}
	
	public void recibirAtaque(int danio){
		if(estaVivo){
			this.vida-=danio;
		}
	
	}
}
