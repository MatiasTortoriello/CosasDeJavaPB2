package Guerra;

public class Guerrero extends Unidad {
	
	private double salud;
	private double danio;

	public Guerrero(double salud, double danio) {
		super();
		this.salud = salud;
		this.danio = danio;
	}

	public void recibirDanio (double danio) {
		if (this.estaVivo())
			this.salud-= danio ;
	}
	
	public void atacar(Unidad otro) {
		if (this.salud > 0)
			otro.recibirDanio(this.danio);
	}
	
	
	public double getSalud() {
		return salud;
	}

	public void setSalud(double salud) {
		this.salud = salud;
	}

	public double getDanio() {
		return danio;
	}

	public void setDanio(double danio) {
		this.danio = danio;
	}

	@Override
	public boolean estaVivo() {
		// TODO Auto-generated method stub
		return false;
	}

}
