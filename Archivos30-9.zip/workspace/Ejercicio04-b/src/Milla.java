
public class Milla extends UnidadDeLongitud {
	
	Milla(double cantidad){
		this.cantidad = cantidad;
	}
	
	public double aMetro(){
		return this.cantidad * 1609.34;
	}
	
	public double aPie(){
		return this.cantidad * 5280;
	}
	
	public double aKm(){
		return this.cantidad * 1.60934;
	}
	
	public double aMilla(){
		return this.cantidad;
	}
}
