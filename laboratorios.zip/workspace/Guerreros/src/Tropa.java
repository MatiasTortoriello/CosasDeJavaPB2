import java.util.ArrayList;

public class Tropa extends UnidadAtaque{

	private ArrayList<UnidadAtaque> unidades = new ArrayList<UnidadAtaque>();

	public Tropa(ArrayList<UnidadAtaque> guerreros) {
		this.unidades = guerreros;
	}
	
	public void atacar(UnidadAtaque atacado){
		
		unidades.get(0).atacar(atacado);
	}
	
	public void recibirAtaque(int danio){
		int unidad=  (int) (Math.random() * (this.unidades.size();))
		unidades.get(unidad).recibirAtaque(danio);
		if(unidades.get(unidad).)
	}


	
}
