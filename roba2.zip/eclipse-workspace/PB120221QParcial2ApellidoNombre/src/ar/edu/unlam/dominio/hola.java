package ar.edu.unlam.dominio;

public interface hola {

}
