package Carrito;

public class PackPrecioFijo extends Pack {
	
	private double precio;
	
	public PackPrecioFijo (double precio) {
		this.precioUnitario = precio;
		super(precioTotal);
	}

	public void agregar(Articulo art) {
		this.precioTotal += this.precioUnitario;
	}
	
}
