import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import java.util.TreeSet;

public class Maps {
	public static void main(String[] args) {
		// MAPS, DICTIONARIES, HASHES, OBJECTS, ASSOCIATIVE ARRAYS, PROPERTIES, ETC.
		// KEY-VALUE PAIRS NAMED ENTRIES
		
		Map<String, String> map = new HashMap<String, String>();
		map.put("Argentina", "BuenosAires");
		System.out.println(map);
		
		// CONTAINS?
		// Should return true
		System.out.println(map.containsKey("Argentina"));
		System.out.println(map.containsValue("BuenosAires"));
		
		// Should return false
		System.out.println(map.containsKey("France"));
		System.out.println(map.containsValue("Cairo"));
		
		// ADD
		map.put("Chile", "Santiago");
		map.put("France", "Paris");
		map.put("Egypt", "Cairo");
		System.out.println(map);
		
		// REPEAT
		map.put("Argentina", "Santiago");
		System.out.println(map);
		
		// GET
		System.out.println(map.get("Chile"));
		
		// TRANSVERSE
		for (String key : map.keySet())
			System.out.println(map.get(key));
		for (Entry<String, String> entry : map.entrySet())
			System.out.println("COUNTRY: " + entry.getKey() + ", CITY: " + entry.getValue());
		
		// SIZE
		System.out.println(map.size());
		
		// EMPTY
//		map.clear();
//		System.out.println(map);
		
		// IS EMPTY?
		System.out.println(map.isEmpty());
		
		// GET KEYS
		System.out.println(map.keySet());
		
		// GET VALUES
		System.out.println(map.values());
		
		// GET ENTRIES
		System.out.println(map.entrySet());
		
		// PRINT
		System.out.println(map);
		
		// Returns Santiago
		System.out.println(map.getOrDefault("Argentina", "COUNTRY NOT IN LIST"));
		//Returns COUNTRY NOT IN LIST
		System.out.println(map.getOrDefault("New Zealand", "COUNTRY NOT IN LIST"));
		
		// Adds Colombia, Bogot�
		map.putIfAbsent("Colombia", "Bogot�");
		System.out.println(map);
		// Does nothing
		map.putIfAbsent("Argentina", "Usuahia");
		System.out.println(map);
	}
}
