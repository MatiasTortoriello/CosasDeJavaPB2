
public class Monticulos {

	public static void main(String[] args) {
		Monticulo mont = new Monticulo();
		
		mont.insertar(5);
		mont.insertar(7);
		mont.insertar(1);
		mont.insertar(9);
		mont.insertar(11);
		mont.insertar(0);
		System.out.println("fin");
	}

}
