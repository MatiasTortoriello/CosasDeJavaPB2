package edu.unlam.progava.triatlon;

public class Salmon implements Nadador {

	public void nadar() {
		
	}
	
}
