
public abstract class Entidad {

}
