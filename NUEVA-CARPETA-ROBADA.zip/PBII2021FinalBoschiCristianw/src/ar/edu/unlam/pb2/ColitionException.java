package ar.edu.unlam.pb2;

public class ColitionException extends Exception {
	public ColitionException(){
		super("ColitionException");
	}
}
