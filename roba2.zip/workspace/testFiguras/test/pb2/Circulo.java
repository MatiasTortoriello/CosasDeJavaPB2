package pb2;

public class Circulo extends Figura {
	private Double radio;
	private final Double pi=3.14;
 
	public Circulo(String nombre, Double radio) {
		super(nombre);
		this.radio = radio;
	}

	@Override
	public double calcularArea() {
		Double area=this.pi*(this.radio*this.radio);
		return area;
	}

}
