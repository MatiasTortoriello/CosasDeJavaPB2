package EjercicioCarrito;

import java.util.LinkedList;
import java.util.List;

public abstract class Pack implements Vendible{
	
	protected List<Articulo> articulos = new LinkedList<Articulo>();
	protected double precio;
	
	public double getPrecio(){
		return precio;
	}
	
	public abstract void agregarArticulo(Articulo articulo);
	
}
