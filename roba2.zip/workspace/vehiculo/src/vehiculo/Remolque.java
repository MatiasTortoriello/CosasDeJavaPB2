package vehiculo;

public class Remolque {
	private int peso;
	
	public Remolque() {
		this.peso = 100;
	}

	@Override
	public String toString() {
		return "Remolque [peso=" + peso + "]";
	}
	
	
	
	
}
