package Guerra;

public class app {

	public static void main(String[] args) {
		Guerrero g1 = new Guerrero(2,2);
		Guerrero g2 = new Guerrero(4,1);
		g1.atacar(g2);
		g1.atacar(g2);
		g1.atacar(g2);
		System.out.println("salud: " + g1.getSalud() + " danio: " + g1.getDanio());
		System.out.println("salud: " + g2.getSalud() + " danio: " + g2.getDanio());
	}
}
