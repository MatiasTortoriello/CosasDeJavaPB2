
public class CerraduraDeCombinacionACerraduraDigitalAdapter extends CerraduraDigital {
	CerraduraDeCombinacion cerraduraDeCombinacion;

	public CerraduraDeCombinacionACerraduraDigitalAdapter(CerraduraDeCombinacion cerraduraDeCombinacion) {
		super(0, 0, 0);
		this.cerraduraDeCombinacion = cerraduraDeCombinacion;
	}

	public void ingresarClave(int a, int b, int c) {
		for (int i = 0; i < a + 10; i++) {
			cerraduraDeCombinacion.izquierda();
		}
		for (int i = 0; i < b + 10; i++) {
			cerraduraDeCombinacion.derecha();
		}
		for (int i = 0; i < c + 10; i++) {
			cerraduraDeCombinacion.izquierda();
		}
	}

	public boolean presionarOk() {
		return cerraduraDeCombinacion.abrir();
	}
}
