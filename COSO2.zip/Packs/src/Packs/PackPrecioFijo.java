package Packs;

public class PackPrecioFijo extends Pack {

}
