
public enum UnidadesDeMedida {
	METRO, KILOMETRO, MILLA, PIES;
}
