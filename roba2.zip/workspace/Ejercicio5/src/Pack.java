import java.util.List;

public abstract class Pack {
	
	public List<Articulo>listaArticulos;
}


