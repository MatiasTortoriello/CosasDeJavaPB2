package ar.edu.unlam.pb2;

public class FlojoDePapelesException extends Exception {
	public FlojoDePapelesException() {
		super("FlojoDePapelesException");
	}
}
