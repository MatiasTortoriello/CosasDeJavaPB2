package ar.edu.unlam.pb2;

import java.util.ArrayList;

public class Secretaria {

	private String nombre;
	private ArrayList <Habitante> habitantes;
	
	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public Secretaria(String nombre) {
		this.nombre = nombre; 
		this.habitantes = new ArrayList <>();
	}
	
	public Integer obtenerCantidadDeHabitantes() {
		return habitantes.size();
	}
	
	public void agregarHabitante (Habitante habitante) {
		habitantes.add(habitante);
	}

	public ArrayList<Habitante> getHabitantes() {
		return habitantes;
	}
}
