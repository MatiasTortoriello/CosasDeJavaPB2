package edu.unlam.progava.triatlon;

public class Pato implements Nadador, Corredor, Volador {

	@Override
	public void correr() {
		// ...
	}
	
	@Override
	public void nadar() {
		// ...
	}
	
	@Override
	public void volar() {
		// ...
	}
	
}
