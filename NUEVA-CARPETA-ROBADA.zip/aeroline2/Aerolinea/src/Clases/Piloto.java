package Clases;

public class Piloto extends Personal{

	String tipoAvionQuePilota;
	
	public Piloto(Integer identificador, String nombre, String tipoPiloto, String tipoAvionQuePilota) {
		super(identificador, nombre, tipoPiloto);
		this.tipoAvionQuePilota = tipoAvionQuePilota;
	}
	
	public String getTipoAvionQuePilota() {
		return this.tipoAvionQuePilota;
	}
	
	@Override
	public String toString() {
		return super.toString() + " Tipo avion que pilota:" + this.getTipoAvionQuePilota();
	}
	
	
}
