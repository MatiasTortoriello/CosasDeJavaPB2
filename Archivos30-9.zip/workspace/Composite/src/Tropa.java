import java.util.ArrayList;
import java.util.List;

public class Tropa extends Unidad {
	private List<Unidad> formacion = new ArrayList<Unidad>();

	public boolean agregarATropa(Unidad unidad) { // metodo delegado
		return this.formacion.add(unidad);
	}

	public void daniar(Unidad o) {
		this.formacion.get(0).daniar(o);
	}

	public void recibirDanio(int danio) {
		if (this.estaVivo()) { //alguien vivo en la tropa
			Unidad victima = this.formacion.get((int) Math.random() * this.formacion.size());
			victima.recibirDanio(danio);
			if (!victima.estaVivo()) {
				this.formacion.remove(victima);
			}
		}
	}

	@Override
	public String toString() {
		return "Tropa [formacion=" + formacion + "]";
	}

	@Override
	public boolean estaVivo() {
		for (Unidad unidad : formacion) {
			if (unidad.estaVivo()) {
				return true;
			}
		}
		return false;
	}

}
