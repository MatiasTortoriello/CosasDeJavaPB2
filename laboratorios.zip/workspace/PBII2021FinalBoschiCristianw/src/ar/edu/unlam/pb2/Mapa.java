package ar.edu.unlam.pb2;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class Mapa {

	
	private String nombre;
	private List<MedioTransporte>vehiculos;
	private List<Auto>listaAutos;
	public Mapa(String nombre) {
		// TODO Auto-generated constructor stub
		this.nombre=nombre;
		this.vehiculos=new ArrayList<>();
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	

	public Object getCantidadDeVehiculos() {
		// TODO Auto-generated method stub
		return this.vehiculos.size();
	}

	public boolean hayCoalici�n() throws ColitionException {
		
		Integer i=0;
		
		for (MedioTransporte medioTransporte : vehiculos) {
			if(medioTransporte.equals(vehiculos.get(i))){
				throw new ColitionException();
			}
			else{
				i++;
			}
		}
		return false;
		
	}
	public void agregarVehiculo(MedioTransporte medio){
		// TODO Auto-generated method stub
		/*if(!hayCoalici�n()){
			this.vehiculos.add(medioTransporte);	
		} else {
			throw new ColitionException();
		}*/
		
		if(medio instanceof Auto){
			this.vehiculos.add((Auto) medio);
		}
			
		
		
		
	}
/*
	MedioTransporte a=(MedioTransporte)b;
	if(a instanceof MedioTransporte){
		this.vehiculos.add(a);	
	}
	throw new ColitionException();
	*/

	public List<MedioTransporte> getVehiculos() {
		return vehiculos;
	}

	public void setVehiculos(List<MedioTransporte> vehiculos) {
		this.vehiculos = vehiculos;
	}

	public List<Auto> getListaAutos() {
		return listaAutos;
	}

	public void setListaAutos(List<Auto> listaAutos) {
		this.listaAutos = listaAutos;
	}
	
	
	
}
