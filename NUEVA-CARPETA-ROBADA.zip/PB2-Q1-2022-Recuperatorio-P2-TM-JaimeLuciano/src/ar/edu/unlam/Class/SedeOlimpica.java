package ar.edu.unlam.Class;

import java.time.LocalDate;
import java.util.*;

public class SedeOlimpica {

	private String nombreSede;
	private HashSet<Complejo> sedes;

	public SedeOlimpica(String nombreSede) {
		this.nombreSede = nombreSede;
		sedes = new HashSet<Complejo>();
	}

	// CREACION DE COMPLEJOS
	public Boolean crearComplejo(Complejo gimnasio) {
		Boolean validacion = false;
		if (sedes.add((Polideportivo) gimnasio) == true) {
			validacion = true;
		}
		return validacion;
	}

	private Complejo buscarComplejo(Complejo c) throws ComplejoNoEncontrado {
		Complejo encontrado = null;
		for (Complejo complejo : sedes) {
			if (complejo.getId().equals(c.getId())) {
				encontrado = complejo;
			}
		}
		if (encontrado == null) {
			throw new ComplejoNoEncontrado();
		}
		return encontrado;

	}

	// ----------------------------------------------------------------
	// CREACION DE AREAS EN COMPLEJO COMPUESTO (POLIDEPORTIVO)
	public Boolean crearAreaEnPolideportivo(Complejo c, Integer idArea, String ubicacion)
			throws ComplejoNoEncontrado, AreaDuplicada {
		Boolean seCreo = false;
		Polideportivo encontrado = (Polideportivo) buscarComplejo(c);
		if (encontrado.getAreasDeportivas().add(new Areas(idArea, ubicacion))) {
			seCreo = true;
		} else {
			throw new AreaDuplicada();
		}
		return seCreo;

	}

	// CREACION DE EVENTOS EN LA SEDE QUE SE EFECTUAN EN UN AREA DE UN COMPLEJO
	public void crearEvento(Complejo c, Integer idArea, Integer idevento, String nombreEvento, LocalDate fechaEvento,
			Double duracion) throws ComplejoNoEncontrado {
		Polideportivo encontrado = (Polideportivo) buscarComplejo(c);
		TreeSet<Areas> areasObtenidas = encontrado.getAreasDeportivas();
		Areas areaEncontrada = buscarAreaEnComplejo(idArea, areasObtenidas);
		areaEncontrada.getListaEventos().add(new Eventos(idevento, nombreEvento, fechaEvento, duracion));
	}

	private Areas buscarAreaEnComplejo(Integer idArea, TreeSet<Areas> obtenidas) {
		Areas encontrado = null;
		for (Areas areas : obtenidas) {
			if (areas.getIdArea().equals(idArea)) {
				encontrado = areas;
			}
		}

		return encontrado;
	}

	public Eventos buscarEvento(Integer idEvento, Complejo c, Integer idArea) {
		Eventos eventoEncontrado = null;
		Polideportivo poliEncontrado = null;
		try {
			poliEncontrado = (Polideportivo) buscarComplejo(c);
		} catch (ComplejoNoEncontrado e) {
			System.out.println("complejo no encontrado");
		}

		Areas areaEncontrada = poliEncontrado.buscarArea(idArea);
		eventoEncontrado = areaEncontrada.buscarEvento(idEvento);
		return eventoEncontrado;
	}

	public void agregarComisarioAEvento(Comisario juez, Integer idEvento, Complejo c, Integer idArea)
			throws ComisarioDuplicado {
		Eventos encontrado = buscarEvento(idEvento, c, idArea);
		if (!encontrado.getListaComisarios().add(juez)) {
			throw new ComisarioDuplicado();
		}

	}

	public Comisario buscarComisarioEnEvento(Eventos e, Integer dniComisario) throws ComisarioInexistente {
		Comisario encontrado = null;
		TreeSet<Comisario> nuevaLista = e.getListaComisarios();
		for (Comisario comisario : nuevaLista) {
			if (comisario.getDni().equals(dniComisario)) {
				encontrado = comisario;
			}
		}
		if (encontrado == null) {
			throw new ComisarioInexistente();
		}
		return encontrado;

	}

	public Boolean agregarParticipantesAComplejoSimple(Complejo c, Participantes p) {
		Boolean seAgrego = false;
		ComplejoSimple encontrado = null;
		try {
			encontrado = (ComplejoSimple) buscarComplejo(c);
		} catch (ComplejoNoEncontrado e) {
			System.out.println("No encontrado");
		}
		if (encontrado.listaParticipantes.add(p)) {
			seAgrego = true;
		}
		return seAgrego;
	}

	public TreeMap<String,String> crearMapa(Complejo c,Integer idArea) {
		TreeMap<String, String> mapaNuevo = new TreeMap<String, String>();
		Polideportivo encontrado=null;
		try {
			encontrado=(Polideportivo) buscarComplejo(c);
		} catch (ComplejoNoEncontrado e) {
			System.out.println("");
		}
		TreeSet<Areas> encontradas=encontrado.getAreasDeportivas();
		for (Areas areas : encontradas) {
			mapaNuevo.put(encontrado.getNombre(),areas.getUbicacion());
		}
		return mapaNuevo;
		
		
		

	}

}
