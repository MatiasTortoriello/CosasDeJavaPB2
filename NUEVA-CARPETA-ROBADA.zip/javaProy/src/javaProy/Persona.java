package javaProy;

public class Persona {

}
