package ar.edu.unlam.Class;

import java.util.*;

public class Areas implements Comparable<Areas> {
	private Integer idArea;
	private String ubicacion;
	private TreeSet<Eventos> listaEventos = new TreeSet<Eventos>();

	public Areas(Integer idArea, String ubicacion) {
		this.idArea = idArea;
		this.ubicacion = ubicacion;

	}

	public Eventos buscarEvento(Integer idEvento) {
		Eventos encontrado = null;
		for (Eventos eventos : listaEventos) {
			if (eventos.getIdevento().equals(idEvento)) {
				encontrado = eventos;
			}
		}
		return encontrado;
	}
	// GETTERS AND SETTERS

	public Integer getIdArea() {
		return idArea;
	}

	public TreeSet<Eventos> getListaEventos() {
		return listaEventos;
	}

	public void setListaEventos(TreeSet<Eventos> listaEventos) {
		this.listaEventos = listaEventos;
	}

	public void setIdArea(Integer idArea) {
		this.idArea = idArea;
	}

	public String getUbicacion() {
		return ubicacion;
	}

	public void setUbicacion(String ubicacion) {
		this.ubicacion = ubicacion;
	}

	// OVERRIDES
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((idArea == null) ? 0 : idArea.hashCode());
		result = prime * result + ((ubicacion == null) ? 0 : ubicacion.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Areas other = (Areas) obj;
		if (idArea == null) {
			if (other.idArea != null)
				return false;
		} else if (!idArea.equals(other.idArea))
			return false;
		if (ubicacion == null) {
			if (other.ubicacion != null)
				return false;
		} else if (!ubicacion.equals(other.ubicacion))
			return false;
		return true;
	}

	@Override
	public int compareTo(Areas o) {

		return this.idArea - o.getIdArea();
	}

}
