package code;

import java.util.List;

public abstract class Transporte {

	
	protected List<Paquete> paquetes;
	
	public abstract boolean cargarPaquete(Paquete p); 
	
}
