package unlam.practicame;

public class CambioDeContrasenia extends Transaccion implements Monitoreable {

	@Override
	public void monitorear() {
		TipoTransaccion tipo = TipoTransaccion.NO_MONETARIA;
		
	}

}
