package ar.unlam;

public enum Area {
	LIMPIEZA, AZAFATA

}
