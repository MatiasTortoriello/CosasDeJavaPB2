package ar.edu.unlam.interfaz;

public class Veterinaria {
	private String nombreVeterinaria;
	private int cantidadMaximaAtenciones;

		public Veterinaria(String nombreVeterinaria, int cantidadMaximaAtenciones) {
		this.nombreVeterinaria = nombreVeterinaria;
	}
	
		

	
	

}
