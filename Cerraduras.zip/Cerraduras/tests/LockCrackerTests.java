import static org.junit.Assert.*;

import org.junit.Test;

public class LockCrackerTests {

	@Test
	public void puedoCrearla() {
		new LockCracker();
	}

	@Test
	public void puedoAbrirla() {
		int[] actual = { 5, 8, 9 };
		LockCracker lc = new LockCracker();
		CerraduraDigital cd = new CerraduraDigital(actual[0], actual[1], actual[2]);

		int[] expected = lc.abrir(cd);

		assertArrayEquals(expected, actual);
	}

	@Test
	public void puedoAbrirlasTODAS() {
		LockCracker lc = new LockCracker();

		for (int i = 9; i >= 0; i--) {
			for (int j = 9; j >= 0; j--) {
				for (int k = 9; k >= 0; k--) {
					CerraduraDigital cd = new CerraduraDigital(i, j, k);
					int[] expected = lc.abrir(cd);

					assertArrayEquals(expected, new int[] { i, j, k });
				}
			}
		}
	}

	@Test
	public void puedoAbrirlaCombinacion() {
		int[] actual = { 5, 8, 9 };
		LockCracker lc = new LockCracker();
		CerraduraDeCombinacion cc = new CerraduraDeCombinacion(actual[0], actual[1], actual[2]);

		CerraduraDeCombinacionACerraduraDigitalAdapter cca =
				new CerraduraDeCombinacionACerraduraDigitalAdapter(cc);

		int[] expected = lc.abrir(cca);

		assertArrayEquals(expected, actual);
	}

	@Test
	public void puedoAbrirlasTODASCombinacion() {
		LockCracker lc = new LockCracker();

		for (int i = 9; i >= 0; i--) {
			for (int j = 9; j >= 0; j--) {
				for (int k = 9; k >= 0; k--) {
					CerraduraDeCombinacion cc = new CerraduraDeCombinacion(i, j, k);
					CerraduraDeCombinacionACerraduraDigitalAdapter cca = new CerraduraDeCombinacionACerraduraDigitalAdapter(cc);
					int[] expected = lc.abrir(cca);

					assertArrayEquals(expected, new int[] { i, j, k });
				}
			}
		}
	}
}
