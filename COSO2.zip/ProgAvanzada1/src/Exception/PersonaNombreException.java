package Exception;

public class PersonaNombreException extends Exception {

	public PersonaNombreException(String mensaje) {
		super(mensaje);
	}
}
