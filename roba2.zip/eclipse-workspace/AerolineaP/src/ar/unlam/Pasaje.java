package ar.unlam;

public class Pasaje {

	private Vuelo vuelo;
	private Pasajero pasajero;
	private Double precio;

	public Pasaje(Vuelo vuelo, Pasajero pasajero) {
		this.vuelo = vuelo;
		this.pasajero = pasajero;
		this.precio = calcularPrecio(vuelo,pasajero);
	}

	private Double calcularPrecio(Vuelo vuelo2, Pasajero pasajero) {
		Double precioPasaje = vuelo.getPrecio();
		Double descuento = 0.0;
		if(pasajero instanceof Pasajero)
			descuento = precioPasaje * 0.1;
		return precioPasaje - descuento;
	}

	public Double getPrecio() {
		// TODO Auto-generated method stub
		return null;
	}

}
