package pb2;

public class Figura {
	private String nombre;
	private Double area;
	private Double perimetro;
	

}
