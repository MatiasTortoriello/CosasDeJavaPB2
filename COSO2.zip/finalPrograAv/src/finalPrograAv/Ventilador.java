package finalPrograAv;

public class Ventilador implements ArtefactoElectronico{

	private int nivelDePotencia;
	private int consumoExtraXNivel = 3;
	private int consumoBase = 50;
	
	
	public Ventilador(int nivelDePotencia) {

		this.nivelDePotencia = nivelDePotencia;
	}


	@Override
	public int getConsumo() {
		
		int consumoTotal = (this.consumoExtraXNivel * this.nivelDePotencia) * this.consumoBase;
		return consumoTotal;
	}
}
