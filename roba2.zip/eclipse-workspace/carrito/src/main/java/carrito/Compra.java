package carrito;

import java.sql.Date;
import java.util.List;

public class Compra {

	List<Item> li;
	double total;
	double totalConDescuento;
	Date fecha;
	public Compra() {
		// TODO Auto-generated constructor stub
	}

}
