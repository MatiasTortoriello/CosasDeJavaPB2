package ar.edu.unlam.dominio;

public enum TipoUnidad {

	HDD,USB;
}
