package rpg;

public class ConAmuleto {

	public ConAmuleto() {
		// TODO Auto-generated constructor stub
	}

}
