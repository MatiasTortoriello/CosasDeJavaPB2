import java.util.ArrayList;

public class Tropa extends Unidad {
	private ArrayList<Unidad> armada;

	public Tropa() {
		this.armada = new ArrayList<Unidad>();
	}

	public void agregarGuerrero(Unidad unidad) {
		this.armada.add(unidad);
	}

	@Override
	public void atacar(Unidad ente) {
		this.armada.get(0).atacar(ente);
	}

	@Override
	public void recibirDanio(int danio) {
		int i = (int) Math.random() * this.armada.size();

		this.armada.get(i).recibirDanio(danio);

	}
}
