package EjercicioCarrito;

public interface Vendible {
	
	public double getPrecio();
}
