import java.util.ArrayList;

public class Habitacion implements ArtefactoElectronico {
	private ArrayList<ArtefactoElectronico> bombillas = new ArrayList<ArtefactoElectronico>();

	@Override
	public int getConsumo() {
		
		return 0;
	}

	@Override
	public void setConsumo() {
		// TODO Auto-generated method stub
		
	}

}
