package ar.unlam.edu.pb2.TestAnillo;

import static org.junit.Assert.*;

import org.junit.Test;

public class TestCuentaGanado {

	@Test
	public void queSePuedaCrearUnCuentaGanado() {
		CuentaGanado cuentaGanado = new CuentaGanado();
		assertNotNull(cuentaGanado);

	}

	@Test
	public void queSePuedaCrearUnCuentaGanadoConElContadorEn0() {

		CuentaGanado cuentaGanado = new CuentaGanado();
		Integer valorEsperado = 0;
		Integer valorObtenido = cuentaGanado.getContador();
		assertEquals(valorEsperado, valorObtenido);

	}

	@Test
	public void queSePuedaSumarUnoAlContador() {

		CuentaGanado cuentaGanado = new CuentaGanado();

		cuentaGanado.incrementarContador();

		Integer valorEsperado = 1;
		Integer valorObtenido = cuentaGanado.getContador();
		assertEquals(valorEsperado, valorObtenido);

	}

	@Test
	public void queSeAlLlegarAlMaximoSeIncrementaEnUnoPaseACero() {

		CuentaGanado cuentaGanado = new CuentaGanado();

		cuentaGanado.incrementarContador();
		cuentaGanado.incrementarContador();
		cuentaGanado.incrementarContador();
		cuentaGanado.incrementarContador();
		cuentaGanado.incrementarContador();
		cuentaGanado.incrementarContador();
		cuentaGanado.incrementarContador();
		cuentaGanado.incrementarContador();
		cuentaGanado.incrementarContador();
		cuentaGanado.incrementarContador();

		Integer valorEsperado = 0;
		Integer valorObtenido = cuentaGanado.getContador();
		assertEquals(valorEsperado, valorObtenido);

	}

	@Test
	public void queSePuedaResetearElContadorACero() {
		CuentaGanado cuentaGanado = new CuentaGanado();

		cuentaGanado.incrementarContador();
		cuentaGanado.incrementarContador();
		cuentaGanado.incrementarContador();
		cuentaGanado.incrementarContador();

		cuentaGanado.resetContador();

		Integer valorEsperado = 0;
		Integer valorObtenido = cuentaGanado.getContador();
		assertEquals(valorEsperado, valorObtenido);
	}
	
	@Test
	public void x(){
		Double x = 7.0;
		Double y = 3.0;
		Double division = x / y ;
		Double suma = x + y;
		Double valorEsperadoSuma = 10.0;
		Double valorEsperadoDivision = 2.33333;
		
		assertEquals(valorEsperadoSuma,suma);
		
		assertEquals(valorEsperadoDivision, division, 0.01);
		
	}
}
