package PB.Parcial2;

public class Archivo extends FileSystem{

}
