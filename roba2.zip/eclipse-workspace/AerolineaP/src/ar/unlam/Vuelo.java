package ar.unlam;

import java.time.LocalDateTime;
import java.util.Objects;

public class Vuelo {

	private Integer idVuelo;
	private String aeropuertoOrigen;
	private String aeropuertoDestino;
	private LocalDateTime horaDespegue;
	private LocalDateTime horaAterrizaje;
	private double precio;

	public Vuelo(Integer idVuelo, String aeropuertoOrigen, String aeropuertoDestino, LocalDateTime horaDespegue,
			LocalDateTime horaAterrizaje, double precio) {
this.idVuelo = idVuelo;
this.aeropuertoOrigen = aeropuertoOrigen;
this.aeropuertoDestino = aeropuertoDestino;
this.horaDespegue = horaDespegue;
this.horaAterrizaje = horaAterrizaje;
this.precio=precio;
		
	}

	public Integer getIdVuelo() {
		return idVuelo;
	}

	public void setIdVuelo(Integer idVuelo) {
		this.idVuelo = idVuelo;
	}

	public String getAeropuertoOrigen() {
		return aeropuertoOrigen;
	}

	public void setAeropuertoOrigen(String aeropuertoOrigen) {
		this.aeropuertoOrigen = aeropuertoOrigen;
	}

	public String getAeropuertoDestino() {
		return aeropuertoDestino;
	}

	public void setAeropuertoDestino(String aeropuertoDestino) {
		this.aeropuertoDestino = aeropuertoDestino;
	}

	public LocalDateTime getHoraDespegue() {
		return horaDespegue;
	}

	public void setHoraDespegue(LocalDateTime horaDespegue) {
		this.horaDespegue = horaDespegue;
	}

	public LocalDateTime getHoraAterrizaje() {
		return horaAterrizaje;
	}

	public void setHoraAterrizaje(LocalDateTime horaAterrizaje) {
		this.horaAterrizaje = horaAterrizaje;
	}
	
	public double getPrecio() {
		return precio;
	}

	public void setPrecio(double precio) {
		this.precio = precio;
	}

	@Override
	public int hashCode() {
		return Objects.hash(idVuelo);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Vuelo other = (Vuelo) obj;
		return Objects.equals(idVuelo, other.idVuelo);
	}

	

}
