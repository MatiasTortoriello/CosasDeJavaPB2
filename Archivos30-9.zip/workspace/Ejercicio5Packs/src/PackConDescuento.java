
public class PackConDescuento {

}
