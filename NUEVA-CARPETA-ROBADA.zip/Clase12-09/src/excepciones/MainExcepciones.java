package excepciones;

import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class MainExcepciones {

	public static void main(String[] args) {

		int i = 5;
		int j = 0;
		List<Integer> lista = new ArrayList<>();
		
	    String s = null; 
	    
	    Circulo c = new Circulo(-1);
		
		try {
			fileWriter();
		} catch (IOException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		
		try {
			System.out.println(s.toCharArray());
			lista.add(3, 10);
			System.out.println(i / j);
			System.out.println("no se va a ver");
			
		} catch (ArithmeticException e) {
			// e.printStackTrace();
			System.err.println("No se puede dividir por cero");
		} catch (IndexOutOfBoundsException e) {
			// e.printStackTrace();
			// previamente se podria guardar informacion sobre la excepcion (en que linea de codigo 
			// sucedio, etc)
			System.err.println("Indice fuera de rango");
		} catch (Exception e) {
			// e.printStackTrace();
			System.err.println("Otra excepcion");
		} finally {
			System.out.println("finally");
		}

		System.out.println("fin");

	}
	
	public static void fileWriter() throws IOException{
		throw new IOException("El archivo no pudo ser encontrado");
	}

}
