import java.util.LinkedList;
import java.util.List;

public class Tropa extends Unidad{
	List<Unidad> tropas = new LinkedList<Unidad>();
	
	public void atacar(Unidad otra) {
		int dano=10;
		otra.recibir(dano);
		
	}
	public void recibir(int dano) {
		int index=(int)(Math.floor(Math.random()*tropas.size()+1)); //random
		tropas.get(index).recibir(dano);
	}
	
	
}
