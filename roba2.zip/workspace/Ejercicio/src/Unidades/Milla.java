package Unidades;

public class Milla extends UnidadDeLongitud {
	
	//private BigDecimal valor;

	public Milla(double valor) {
		super(valor);
		this.valor = valor;
	}
	
	@Override
	public Milla toMilla() {
		return this;
	}

	@Override
	public Metro toMetro() {
		return new Metro(this.valor * 1609);
	}
	
	@Override
	public Pie toPie() {
		return new Pie(this.valor * 5208);
	}
	
	@Override
	public Kilometro toKilometro() {
		return new Kilometro(this.valor * 1.609);
	}
	
	@Override
	public String toString() {
		return this.valor + " Millas";
	}
	
	@Override
	public Milla Sumar(UnidadDeLongitud otra) {
		return new Milla(this.valor + otra.toMilla().valor);
	}

}
