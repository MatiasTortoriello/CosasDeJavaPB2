
public class Pie extends UnidadDeLongitud {
	
	Pie(double cantidad){
		this.cantidad = cantidad;
	}
	
	public double aMetro(){
		return this.cantidad * 0.3048;
	}
		
	public double aMilla(){
		return this.cantidad * 0.000189394;
	}
	
	public double aKm(){
		return this.cantidad * 0.0003048;
	}
	
	public double aPie(){
		return this.cantidad;
	}
}
