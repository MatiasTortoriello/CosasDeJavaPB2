import java.util.LinkedList;
import java.util.List;

public class Arrays_vs_Lists {
	public static void main(String[] args) {
		List<String> list = new LinkedList<String>();
		// THEN DO THIS AGAIN AND CHANGE LINKEDLIST TO ARRAYLIST
		
		// ARRAYLIST AND LINKEDLIST DO THE SAME (theyre polimorphic) BUT THEY BEHAVE DIFFERENT UNDER THE HOOD
		System.out.println(list);
		
		list.add("Cow");
		System.out.println(list);
		list.add("Dog");
		System.out.println(list);
		list.add("Flamenco");
		System.out.println(list);
		list.add("Zebra");
		System.out.println(list);
		
		list.add(3, "Squid");
		System.out.println(list);
		
		String thirdAnimal = list.get(2); // Should return Dog.
		System.out.println(thirdAnimal);
		System.out.println(list);
		
		System.out.println(list.remove(0)); // Removes Cow and should return Cow.
		System.out.println(list);
		
		System.out.println(list.size()); // Should return 4.
		System.out.println(list);

		// IS IT THERE?
		System.out.println(list.contains("Giraffe")); // Should return false.
		System.out.println(list.contains("Squid")); // Should return true.
		System.out.println(list);
		
		// GET INDEX
		// TRAVERSE
		// PRINT
		// EMPTY
		// IS EMPTY?
	}
}
