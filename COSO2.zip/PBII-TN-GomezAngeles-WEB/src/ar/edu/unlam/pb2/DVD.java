package ar.edu.unlam.pb2;

import java.util.ArrayList;
import java.util.List;

public class DVD extends UnidadAlmacenamiento{

	private Boolean cerrado;
	List <DVD> dvd;
	
	public DVD(Double capacidadMaxima, Character letra, Boolean cerrado) {
		super(capacidadMaxima, letra);
		
		this.dvd = new ArrayList<DVD>();
	}

	public Boolean estaCerrado(){
		Boolean resultado = false;
		if(this.getCerrado()){
			resultado=true;
		}
		return resultado;
	}
	
	@Override
	public void agregarArchivo(Archivo archivo) {
		if(!this.estaCerrado()){
			
		}
		
	}

	public Boolean getCerrado() {
		return cerrado;
	}

	public void setCerrado(Boolean cerrado) {
		this.cerrado = cerrado;
	}
	
}
