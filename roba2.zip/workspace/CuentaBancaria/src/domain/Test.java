package domain;

import static org.junit.Assert.*;

public class Test {

	@org.junit.Test
	public void lala() {
		CajaDeAhorro caja = new CajaDeAhorro(1234, "nombre", "apellido", 123, "tipo");
	}

}
