package ar.edu.unlam.pb2;

import java.util.ArrayList;
import java.util.HashSet;

public class Secretaria {
	
	private ArrayList <Habitante> habitantes;
	private ArrayList <Vivienda> viviendas;
	private ArrayList <PropietarioVivienda> propietarios;

	public Secretaria (){
		this.habitantes = new ArrayList <Habitante>() ;
		this.viviendas = new ArrayList <Vivienda>() ;
		this.propietarios = new ArrayList <PropietarioVivienda>();
	}
	
	public void agregarHabitante(Habitante habitante) {
		habitantes.add(habitante);
	}

	public Integer obtenerCantidadDeHabitantes() {		
		return this.habitantes.size();
	}

	public void agregarVivienda(Vivienda vivienda) {
		viviendas.add(vivienda);
	}

	public Integer obtenerCantidadDeViviendas() {
		return viviendas.size();
	}

	public Boolean comprarVivienda(Habitante habitante, Vivienda vivienda, Double porcentaje) {
		Double porcentajeVivienda = obtenerPorcentajeTotalDeUnaVivienda(vivienda);
		if(porcentajeVivienda+porcentaje <= 100){
			PropietarioVivienda propietario = new PropietarioVivienda(habitante, vivienda, porcentaje, this.crearId());
			propietarios.add(propietario);
			return true;
		}
		return false;
		
	}
	private Double obtenerPorcentajeTotalDeUnaVivienda(Vivienda vivienda) {
		Double total = 0.0;
		for (int i = 0; i < propietarios.size(); i++){
			if(propietarios.get(i).getVivienda().equals(vivienda)){
				total += propietarios.get(i).getPorcentaje();
			}
		}
		return total;
	}

	//Busco el ultimo id y le sumo 1
	private Integer crearId() {
		Integer size = propietarios.size();
		if(size == 0){
			return 1;
		}else {
			Integer id = propietarios.get(size-1).getId()+1;
			return id;
		}
	}

	public Integer obtenerCantidadDePropietarios() {
		return propietarios.size();
	}

	public HashSet<Vivienda> obtenerViviendasCuyoPorcentajeEsMenorAlCien() {
		HashSet <Vivienda> viviendasMenorAlCien = new HashSet<>();
		for (PropietarioVivienda propietario : propietarios) {
			if(this.obtenerPorcentajeTotalDeUnaVivienda(propietario.getVivienda())<100.0){
				viviendasMenorAlCien.add(propietario.getVivienda());
			}
		}
		return viviendasMenorAlCien;
	}


	
	
	
}
