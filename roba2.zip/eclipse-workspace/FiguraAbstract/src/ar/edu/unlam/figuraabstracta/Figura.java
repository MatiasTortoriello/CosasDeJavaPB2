package ar.edu.unlam.figuraabstracta;

public abstract class Figura {
	private String color;
	
	Figura(String color) {
		this.color = color;
	}
	
	public abstract Double calcularArea();
	public abstract String getTipo();
	
	public String getColor() {
		return color;
	}

	public void setColor(String color) {
		this.color = color;
	}

	@Override
	public String toString() {
		return "Figura [color=" + color + "]";
	}
	
	
}
