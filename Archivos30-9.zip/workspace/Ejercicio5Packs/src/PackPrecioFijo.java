
public class PackPrecioFijo {

}
