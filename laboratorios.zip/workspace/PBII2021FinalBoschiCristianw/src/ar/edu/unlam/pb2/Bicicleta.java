package ar.edu.unlam.pb2;

public class Bicicleta extends MedioTransporte {

	public Bicicleta(double latitud, double longitud) {
		super(latitud, longitud);
		// TODO Auto-generated constructor stub
	}



	
	

}
