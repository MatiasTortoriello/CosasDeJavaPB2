
public class conItem extends Inicio {
	protected static Inicio equipables;
	int da�oTotal=0;
	
	public conItem(Inicio pj) {
	}

	@Override
	public int getDa�o() {
		return equipables.getDa�o();
	}

}
