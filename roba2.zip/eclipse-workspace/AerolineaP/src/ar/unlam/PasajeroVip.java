package ar.unlam;

public class PasajeroVip extends Pasajero {

	private Integer dni;

	public PasajeroVip(Integer dni) {
		this.dni = dni;
	}

}
