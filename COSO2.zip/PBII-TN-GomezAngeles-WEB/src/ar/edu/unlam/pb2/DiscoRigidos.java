package ar.edu.unlam.pb2;

import java.util.ArrayList;
import java.util.List;

public class DiscoRigidos extends UnidadAlmacenamiento{
	
	private List archivos;

	public DiscoRigidos(Double capacidadMaxima, Character letra) {
		super(capacidadMaxima, letra);
		
		this.archivos = new ArrayList<Archivo>();
	}

	@Override
	public void agregarArchivo(Archivo archivo) {
		
		
	}

}
