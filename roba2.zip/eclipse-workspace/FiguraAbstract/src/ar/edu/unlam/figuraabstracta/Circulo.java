package ar.edu.unlam.figuraabstracta;

public class Circulo extends Figura {

	private Double radio;

	public Circulo(String color, Double radio) {
		super(color);
		this.radio = radio;
	}

	@Override
	public Double calcularArea() {
		// TODO Auto-generated method stub
		return this.radio * radio * Math.PI;
	}

	public Double getRadio() {
		return radio;
	}

	public void setRadio(Double radio) {
		this.radio = radio;
	}

	@Override
	public String toString() {
		return "soy Circulo y tengo [radio=" + radio + "] y de color "+ getColor();
	}

	@Override
	public String getTipo() {
		return "Circulo";
	}

	
}
