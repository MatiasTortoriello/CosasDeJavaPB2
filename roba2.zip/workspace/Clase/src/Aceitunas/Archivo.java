package Aceitunas;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Comparator;
import java.util.Scanner;

public class Archivo {
	
	public static ListaTiros leerArchivo(String nombreArch) {
			
			File file = null;
			Scanner scanner = null;
			
			ListaTiros lista = null;
		
			try {
				
				file = new File (nombreArch + ".in");
				scanner = new Scanner(file);
				
				int cantTiros = scanner.nextInt();
				lista = new ListaTiros(cantTiros);
				
				while(scanner.hasNextLine()) {
					
					int x = scanner.nextInt();
					int y = scanner.nextInt();
					Tiro tiro = new Tiro(new Punto(x,y));
					lista.tiros.add(tiro);
				}
				
			} catch (Exception e) {
				e.printStackTrace();
			} finally {
				scanner.close();
			}
			
			//Collections.sort(lista.listaInicial,Collections.reverseOrder());
			lista.tiros.sort(Comparator.comparing(Tiro::getDist).reversed());
			
			return lista;
		}
		
		public static void guardarArchivo(String nombreArch, double radio) {
				
				FileWriter file = null;
				PrintWriter printwritter = null;
				
				try {
					
					file = new FileWriter (nombreArch + ".out");
					printwritter = new PrintWriter(file);
					
					printwritter.println(radio*radio);
					
				} catch (Exception e) {
					e.printStackTrace();
				} finally {
					if(file != null) {
						try {
							file.close();
						}
						catch (IOException e) {
							e.printStackTrace();
						}
					}
				}
	
			}

}
