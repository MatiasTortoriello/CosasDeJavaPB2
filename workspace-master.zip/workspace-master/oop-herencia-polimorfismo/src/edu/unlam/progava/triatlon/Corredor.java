package edu.unlam.progava.triatlon;

public interface Corredor {

	public void correr();
	
}
