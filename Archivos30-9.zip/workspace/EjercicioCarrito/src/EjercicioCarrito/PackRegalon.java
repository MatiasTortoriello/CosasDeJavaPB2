package EjercicioCarrito;

public class PackRegalon extends Pack{
	private boolean regalo;
	
	public PackRegalon(){
		regalo = true;
	}

	@Override
	public void agregarArticulo(Articulo articulo) {
		
		
	}

}
