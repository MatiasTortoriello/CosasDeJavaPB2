package Dominio.figuras;

public class Triangulo extends Figura{
	private Double lado;
	
	public Triangulo(String nombre, Double area, Integer perimetro, Double lado) {
		super(nombre, area, perimetro);
		this.lado = lado;
	}

	@Override
	public Double calcularArea(Double radio) {
		
		return null;
	}

}
