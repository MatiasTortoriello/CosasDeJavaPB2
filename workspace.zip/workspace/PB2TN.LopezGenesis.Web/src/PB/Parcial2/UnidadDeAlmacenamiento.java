package PB.Parcial2;

import java.util.Set;

public class UnidadDeAlmacenamiento extends FileSystem{
	
	Set<Archivo> archivos;
	Double capacidadMaxima;
	Character letra;
	
	
	public void agregarArchivo(){
	}	
	public Set<Archivo> obtenerListaDeArchivosTipoJpgOrdenadosPorNombre(){
		return null;
		
	}
	public Double calcularEspacioAlmacenado(){
		return null;
	}
	}

