package unlam.practicame;

public class PC extends Dispositivo {

	public PC( String so, String ip, String localidad) {
		super(so, ip, localidad);
		
	}

}
