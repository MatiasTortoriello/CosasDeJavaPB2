package unlam.practicame;

public class PagosQR extends Transaccion  implements Rechazable, Alertable{

	public PagosQR(){
		TipoTransaccion tipo = TipoTransaccion.MONETARIA;
	}
	
	@Override
	public void marcarComoCasoSospechoso() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void confirmarSiFueFraude(Boolean fueFraude) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public Boolean monitorear() throws FraudeException {
		// TODO Auto-generated method stub
		return null;
	}

}
