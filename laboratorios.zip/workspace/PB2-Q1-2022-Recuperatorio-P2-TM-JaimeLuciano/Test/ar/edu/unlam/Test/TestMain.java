package ar.edu.unlam.Test;

import static org.junit.Assert.*;

import java.time.LocalDate;
import java.util.TreeMap;

import org.junit.Test;

import ar.edu.unlam.Class.AreaDuplicada;
import ar.edu.unlam.Class.Comisario;
import ar.edu.unlam.Class.ComisarioDuplicado;
import ar.edu.unlam.Class.ComisarioInexistente;
import ar.edu.unlam.Class.Complejo;
import ar.edu.unlam.Class.ComplejoNoEncontrado;
import ar.edu.unlam.Class.ComplejoSimple;
import ar.edu.unlam.Class.Eventos;
import ar.edu.unlam.Class.Juez;
import ar.edu.unlam.Class.Participantes;
import ar.edu.unlam.Class.Polideportivo;
import ar.edu.unlam.Class.SedeOlimpica;

public class TestMain {

	@Test
	public void queSePuedaCrearUnComplejoSimpleEnUnaSedeOlimpica() {

		// ATRIBUTOS DE LA SEDE
		String nombreSede = "olimpiadas";
		SedeOlimpica juegosOlimpicos = new SedeOlimpica(nombreSede);
		// ATRIBUTOS DE COMPLEJO SIMPLE
		String nombre = "Diego Armando";
		Double areaOcupada = 20.00;
		Complejo gimnasio = new ComplejoSimple(1, nombre, areaOcupada);

		Boolean ve = true;
		Boolean vo = juegosOlimpicos.crearComplejo(gimnasio);
		assertEquals(ve, vo);
	}

	@Test
	public void queSePuedaCrearUnComplejoPolideportivoConUnAreaEnUnaSedeOlimpica() {
		// ATRIBUTOS DE LA SEDE
		String nombreSede = "olimpiadas";
		SedeOlimpica juegosOlimpicos = new SedeOlimpica(nombreSede);
		// INSTANCIA DE COMPLEJO POLIDEPORTIVO
		String nombre = "Diego Armando";
		Double areaOcupada = 20.00;
		Complejo polideportivo = new Polideportivo(2, nombre, areaOcupada);
		juegosOlimpicos.crearComplejo(polideportivo);
		// CREACION DE AREAS EN POLIDEPORTIVO (LA EXCEPTION ES POR SI NO
		// ENCUENTRA UN COMPLEJO)
		Integer idArea = 1;
		String ubicacion = "Area Norte";
		Boolean ve = true;
		Boolean vo = false;
		try {
			try {
				vo = juegosOlimpicos.crearAreaEnPolideportivo(polideportivo, idArea, ubicacion);
			} catch (AreaDuplicada e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		} catch (ComplejoNoEncontrado e) {
			System.out.println("No existe el polideportivo seleccionado");
		}
		assertEquals(ve, vo);

	}

	@Test
	public void queSePuedaCrearUnComplejoPolideportivoConUnAreaYUnEventoEnUnaSedeOlimpica() {
		// ATRIBUTOS DE LA SEDE
		String nombreSede = "olimpiadas";
		SedeOlimpica juegosOlimpicos = new SedeOlimpica(nombreSede);
		// INSTANCIA DE COMPLEJO POLIDEPORTIVO
		String nombre = "Diego Armando";
		Double areaOcupada = 20.00;
		Complejo polideportivo = new Polideportivo(2, nombre, areaOcupada);
		juegosOlimpicos.crearComplejo(polideportivo);
		// CREACION DE AREAS EN POLIDEPORTIVO (LA EXCEPTION ES POR SI NO
		// ENCUENTRA UN COMPLEJO)
		Integer idArea = 1;
		String ubicacion = "Pista carreras";

		try {
			try {
				juegosOlimpicos.crearAreaEnPolideportivo(polideportivo, idArea, ubicacion);
			} catch (AreaDuplicada e) {
				System.out.println("Area Duplicada");
			}
		} catch (ComplejoNoEncontrado e) {
			System.out.println("No existe el polideportivo seleccionado");
		}
		Integer idevento = 1;
		String nombreEvento = "Carrera";
		LocalDate fechaEvento = LocalDate.parse("2022-07-13");
		Double duracion = 30.00;
		try {
			juegosOlimpicos.crearEvento(polideportivo, idArea, idevento, nombreEvento, fechaEvento, duracion);
		} catch (ComplejoNoEncontrado e) {
			System.out.println("Complejo no encontrado");
		}

		Integer ve = idevento;
		Eventos eventoEncontrado = juegosOlimpicos.buscarEvento(idevento, polideportivo, idArea);
		Integer vo = eventoEncontrado.getIdevento();
		assertEquals(ve, vo);

	}

	@Test(expected = AreaDuplicada.class)
	public void queAlAgregarUnAreaAUnPolideportivoConIndicadorYaExistenteLanceUnaExcepcionIndicadorAreaException()
			throws AreaDuplicada {
		// ATRIBUTOS DE LA SEDE
		String nombreSede = "olimpiadas";
		SedeOlimpica juegosOlimpicos = new SedeOlimpica(nombreSede);
		// INSTANCIA DE COMPLEJO POLIDEPORTIVO
		String nombre = "Diego Armando";
		Double areaOcupada = 20.00;
		Complejo polideportivo = new Polideportivo(2, nombre, areaOcupada);
		Complejo polideportivo1 = new Polideportivo(2, "OLIMPIA", 100.00);
		juegosOlimpicos.crearComplejo(polideportivo);
		// CREACION DE AREAS EN POLIDEPORTIVO (LA EXCEPTION ES POR SI NO
		// ENCUENTRA UN COMPLEJO)
		Integer idArea = 1;
		String ubicacion = "Pista carreras";

		try {
			juegosOlimpicos.crearAreaEnPolideportivo(polideportivo, idArea, ubicacion);
			juegosOlimpicos.crearAreaEnPolideportivo(polideportivo1, 1, "Lucha libre");
		} catch (ComplejoNoEncontrado e) {
			System.out.println("No existe el polideportivo seleccionado");
		}
	}

	@Test
	public void queSePuedaAgregarUnComisarioJuezAUnEvento() throws ComisarioInexistente {

		// INSTANCIA DE COMISARIO DE TIPO JUEZ
		Integer dni = 41007231;
		String nombre = "Lucho";
		Integer edad = 24;
		Comisario juez = new Juez(dni, nombre, edad);

		// ATRIBUTOS DE LA SEDE
		String nombreSede = "olimpiadas";
		SedeOlimpica juegosOlimpicos = new SedeOlimpica(nombreSede);
		// INSTANCIA DE COMPLEJO POLIDEPORTIVO
		String nombreComplejo = "Diego Armando";
		Double areaOcupada = 20.00;
		Complejo polideportivo = new Polideportivo(2, nombreComplejo, areaOcupada);
		juegosOlimpicos.crearComplejo(polideportivo);
		// CREACION DE AREAS EN POLIDEPORTIVO (LA EXCEPTION ES POR SI NO
		// ENCUENTRA UN COMPLEJO)
		Integer idArea = 1;
		String ubicacion = "Pista carreras";

		try {
			try {
				juegosOlimpicos.crearAreaEnPolideportivo(polideportivo, idArea, ubicacion);
			} catch (AreaDuplicada e) {
				System.out.println("Area Duplicada");
			}
		} catch (ComplejoNoEncontrado e) {
			System.out.println("No existe el polideportivo seleccionado");
		}
		Integer idEvento = 1;
		String nombreEvento = "Carrera";
		LocalDate fechaEvento = LocalDate.parse("2022-07-13");
		Double duracion = 30.00;
		try {
			juegosOlimpicos.crearEvento(polideportivo, idArea, idEvento, nombreEvento, fechaEvento, duracion);
		} catch (ComplejoNoEncontrado e) {
			System.out.println("Complejo no encontrado");
		}

		try {
			juegosOlimpicos.agregarComisarioAEvento(juez, idEvento, polideportivo, idArea);
		} catch (ComisarioDuplicado e) {
			System.out.println("Comisario Duplicado");
		}
		Eventos eventoNuevo = juegosOlimpicos.buscarEvento(idEvento, polideportivo, idArea);

		Comisario encontrado = null;
		encontrado = juegosOlimpicos.buscarComisarioEnEvento(eventoNuevo, dni);
		Integer ve = dni;
		Integer vo = encontrado.getDni();

		assertEquals(ve, vo);

	}

	@Test(expected = ComisarioInexistente.class)
	public void queAlAgregarUnComisarioJuezInexistenteLanceUnaExcepcionComisarioException()
			throws ComisarioInexistente {
		// INSTANCIA DE COMISARIO DE TIPO JUEZ
		Integer dni = 41007231;
		String nombre = "Lucho";
		Integer edad = 24;
		Comisario juez = new Juez(dni, nombre, edad);

		// ATRIBUTOS DE LA SEDE
		String nombreSede = "olimpiadas";
		SedeOlimpica juegosOlimpicos = new SedeOlimpica(nombreSede);
		// INSTANCIA DE COMPLEJO POLIDEPORTIVO
		String nombreComplejo = "Diego Armando";
		Double areaOcupada = 20.00;
		Complejo polideportivo = new Polideportivo(2, nombreComplejo, areaOcupada);
		juegosOlimpicos.crearComplejo(polideportivo);
		// CREACION DE AREAS EN POLIDEPORTIVO (LA EXCEPTION ES POR SI NO
		// ENCUENTRA UN COMPLEJO)
		Integer idArea = 1;
		String ubicacion = "Pista carreras";

		try {
			try {
				juegosOlimpicos.crearAreaEnPolideportivo(polideportivo, idArea, ubicacion);
			} catch (AreaDuplicada e) {
				System.out.println("Area Duplicada");
			}
		} catch (ComplejoNoEncontrado e) {
			System.out.println("No existe el polideportivo seleccionado");
		}
		Integer idEvento = 1;
		String nombreEvento = "Carrera";
		LocalDate fechaEvento = LocalDate.parse("2022-07-13");
		Double duracion = 30.00;
		try {
			juegosOlimpicos.crearEvento(polideportivo, idArea, idEvento, nombreEvento, fechaEvento, duracion);
		} catch (ComplejoNoEncontrado e) {
			System.out.println("Complejo no encontrado");
		}

		// try {
		// juegosOlimpicos.agregarComisarioAEvento(juez, idEvento,
		// polideportivo, idArea);
		// } catch (ComisarioDuplicado e) {
		// System.out.println("Comisario Duplicado");
		// }
		Eventos eventoNuevo = juegosOlimpicos.buscarEvento(idEvento, polideportivo, idArea);

		Comisario encontrado = juegosOlimpicos.buscarComisarioEnEvento(eventoNuevo, dni);
	}

	@Test
	public void queSePuedaCalcularElTotalDeParticipantesDeLosEventosDeUnComplejoSimple() {
		// ATRIBUTOS DE LA SEDE
		String nombreSede = "olimpiadas";
		SedeOlimpica juegosOlimpicos = new SedeOlimpica(nombreSede);
		// ATRIBUTOS DE COMPLEJO SIMPLE
		String nombre = "Diego Armando";
		Double areaOcupada = 20.00;
		Complejo gimnasio = new ComplejoSimple(1, nombre, areaOcupada);

		Participantes p = new Participantes(41007231, "Luciano", 24);
		Participantes p1 = new Participantes(54887145, "Andres", 40);
		Participantes p2 = new Participantes(41007231, "German", 29);

		juegosOlimpicos.crearComplejo(gimnasio);

		juegosOlimpicos.agregarParticipantesAComplejoSimple(gimnasio, p1);
		juegosOlimpicos.agregarParticipantesAComplejoSimple(gimnasio, p2);
		juegosOlimpicos.agregarParticipantesAComplejoSimple(gimnasio, p);

	}

	@Test
	public void queSePuedaCalcularElPromedioDeEdadDeLosComisariosObservadoresDeUnEventoEspecifico() {
		// INSTANCIA DE COMISARIO DE TIPO JUEZ
		Integer dni = 41007231;
		String nombre = "Lucho";
		Integer edad = 24;
		Comisario juez = new Juez(dni, nombre, edad);
		Comisario juez1 = new Juez(87778954, nombre, 40);
		Comisario juez2 = new Juez(54887499, nombre, 25);

		// ATRIBUTOS DE LA SEDE
		String nombreSede = "olimpiadas";
		SedeOlimpica juegosOlimpicos = new SedeOlimpica(nombreSede);
		// INSTANCIA DE COMPLEJO POLIDEPORTIVO
		String nombreComplejo = "Diego Armando";
		Double areaOcupada = 20.00;
		Complejo polideportivo = new Polideportivo(2, nombreComplejo, areaOcupada);
		juegosOlimpicos.crearComplejo(polideportivo);
		// CREACION DE AREAS EN POLIDEPORTIVO (LA EXCEPTION ES POR SI NO
		// ENCUENTRA UN COMPLEJO)
		Integer idArea = 1;
		String ubicacion = "Pista carreras";

		try {
			try {
				juegosOlimpicos.crearAreaEnPolideportivo(polideportivo, idArea, ubicacion);
			} catch (AreaDuplicada e) {
				System.out.println("Area Duplicada");
			}
		} catch (ComplejoNoEncontrado e) {
			System.out.println("No existe el polideportivo seleccionado");
		}
		Integer idEvento = 1;
		String nombreEvento = "Carrera";
		LocalDate fechaEvento = LocalDate.parse("2022-07-13");
		Double duracion = 30.00;
		try {
			juegosOlimpicos.crearEvento(polideportivo, idArea, idEvento, nombreEvento, fechaEvento, duracion);
		} catch (ComplejoNoEncontrado e) {
			System.out.println("Complejo no encontrado");
		}

		try {
			juegosOlimpicos.agregarComisarioAEvento(juez, idEvento, polideportivo, idArea);
			juegosOlimpicos.agregarComisarioAEvento(juez1, idEvento, polideportivo, idArea);
			juegosOlimpicos.agregarComisarioAEvento(juez2, idEvento, polideportivo, idArea);

		} catch (ComisarioDuplicado e) {
			System.out.println("Comisario Duplicado");
		}
		Eventos eventoNuevo = juegosOlimpicos.buscarEvento(idEvento, polideportivo, idArea);
		Integer vo=eventoNuevo.calcularPromedioEdad();
		Integer ve=29;
		assertEquals(ve,vo);
	}
	
	@Test
	public void queSePuedaObtenerUnMapaDeUnComplejoPolideportivoConNombreDeComplejoYUbicacion(){
		// INSTANCIA DE COMISARIO DE TIPO JUEZ
				Integer dni = 41007231;
				String nombre = "Lucho";
				Integer edad = 24;
				Comisario juez = new Juez(dni, nombre, edad);
				Comisario juez1 = new Juez(87778954, nombre, 40);
				Comisario juez2 = new Juez(54887499, nombre, 25);

				// ATRIBUTOS DE LA SEDE
				String nombreSede = "olimpiadas";
				SedeOlimpica juegosOlimpicos = new SedeOlimpica(nombreSede);
				// INSTANCIA DE COMPLEJO POLIDEPORTIVO
				String nombreComplejo = "Diego Armando";
				Double areaOcupada = 20.00;
				Complejo polideportivo = new Polideportivo(2, nombreComplejo, areaOcupada);
				juegosOlimpicos.crearComplejo(polideportivo);
				// CREACION DE AREAS EN POLIDEPORTIVO (LA EXCEPTION ES POR SI NO
				// ENCUENTRA UN COMPLEJO)
				Integer idArea = 1;
				String ubicacion = "Pista carreras";

				try {
					try {
						juegosOlimpicos.crearAreaEnPolideportivo(polideportivo, idArea, ubicacion);
					} catch (AreaDuplicada e) {
						System.out.println("Area Duplicada");
					}
				} catch (ComplejoNoEncontrado e) {
					System.out.println("No existe el polideportivo seleccionado");
				}
				Integer idEvento = 1;
				String nombreEvento = "Carrera";
				LocalDate fechaEvento = LocalDate.parse("2022-07-13");
				Double duracion = 30.00;
				try {
					juegosOlimpicos.crearEvento(polideportivo, idArea, idEvento, nombreEvento, fechaEvento, duracion);
				} catch (ComplejoNoEncontrado e) {
					System.out.println("Complejo no encontrado");
				}
				
				TreeMap<String,String> nuevo=juegosOlimpicos.crearMapa(polideportivo,idArea);
				
				System.out.println(nuevo);
	}

}
