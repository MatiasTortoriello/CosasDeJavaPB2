package ar.unlam.edu.pb2.TestAnillo;

public class CuentaGanado {
	
	private Integer contador;
	private Integer limite;

	public CuentaGanado() {
	this.contador = 0;
	this.limite = 9;
	}

	public Integer getContador() {
		return this.contador;
	}

	public void incrementarContador() {
		if (this.contador < limite) {
				this.contador++;
		}else {
			this.contador = 0;
		}
		
		
	}

	public void resetContador() {
		this.contador = 0;
		
	}
	
	

}
