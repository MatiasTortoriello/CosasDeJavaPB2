package ar.edu.unlam.pb2.eva03;


import java.util.HashSet;

public class CompaniaDeSeguro {
	private String nombre;
	private HashSet<Poliza> polizasExistentes=new HashSet<Poliza>();
	
	public CompaniaDeSeguro(String nombre) {
		// TODO Auto-generated constructor stub
		this.nombre=nombre;
	}
	public void agregarPoliza(Poliza polizaAAgregar) {
		// TODO Auto-generated method stub
		polizasExistentes.add(polizaAAgregar);
		
	}
	public Integer obtenerLaCantidadDePolizasEmitidas(){
		return polizasExistentes.size();
	}
	public Poliza getPoliza(Integer nroPoliza){
		Poliza aBuscar=null;
		for (Poliza poliza : polizasExistentes) {
			if (poliza.getNumeroDePoliza().equals(nroPoliza)) {
				aBuscar=poliza;
			}
		}
		return aBuscar;
	}
	public void denunciarSiniestro(Integer nroPoliza) throws PolizaInexistente {
		if (polizasExistentes.contains(new Poliza(nroPoliza, new Persona("", 0, 0), 0.0, 0.0))) {
			if (getPoliza(nroPoliza) instanceof PolizaDeAuto) {
				((PolizaDeAuto)getPoliza(nroPoliza)).setFueRobado(true);	
			}else{
				if (getPoliza(nroPoliza) instanceof PolizaAccidentesPersonales) {
					((PolizaAccidentesPersonales)getPoliza(nroPoliza)).setTuvoAlgunAccidente(true);
				}else{
					
				}
				
			}
			
			return;
		}
		throw new PolizaInexistente();
		
	}
	public String getNombre() {
		return nombre;
	}
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}
	public HashSet<Poliza> getPolizasExistentes() {
		return polizasExistentes;
	}
	public void setPolizasExistentes(HashSet<Poliza> polizasExistentes) {
		this.polizasExistentes = polizasExistentes;
	}

}
