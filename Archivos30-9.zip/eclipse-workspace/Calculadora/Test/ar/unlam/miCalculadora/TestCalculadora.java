package ar.unlam.miCalculadora;

import static org.junit.Assert.assertEquals;

import org.junit.Test;

public class TestCalculadora {
 
	@Test
	public void QueSePuedanSumarDosNumeros() {
		/* si te da un test rojo pueden ser 2 cosas puede ser que no sea lo esperado o tenes un error en tiempos de ejecucion
		*/
		assertEquals(0, 0);
		// Preparacion
		Integer operando1 = 2;
		Integer operando2 = 3;
		Calculadora micalculadora = new Calculadora();
		
		//Ejecucion
		Integer resultado =  micalculadora.sumar(operando1,operando2);
		
		//Comprobacion
		Integer	valorEsperado = 5;
		assertEquals(valorEsperado, resultado);
	}
	
	@Test
	public void QueSePuedanDividirDosNumeros() {
		/* si te da un test rojo pueden ser 2 cosas puede ser que no sea lo esperado o tenes un error en tiempos de ejecucion
		*/
		assertEquals(0, 0);
		// Preparacion
		Double numerador = 10.0;
		Double denominador = 2.0;
		Calculadora micalculadora = new Calculadora();
		
		//Ejecucion
		Double resultado =  micalculadora.dividir(numerador,denominador);
		
		//Comprobacion
		Double	valorEsperado = 5.0;
		assertEquals(valorEsperado, resultado);
	}
	
	@Test
	public void obtenerPorcentajeDeUnNumero() {
		/* si te da un test rojo pueden ser 2 cosas puede ser que no sea lo esperado o tenes un error en tiempos de ejecucion
		*/
		assertEquals(0, 0);
		// Preparacion
		Double numero = 100.0;
		Double porcentaje = 20.0;
		Calculadora micalculadora = new Calculadora();
		
		//Ejecucion
		Double resultado =  micalculadora.porcentaje(numero,porcentaje);
		
		//Comprobacion
		Double	valorEsperado = 20.0;
		assertEquals(valorEsperado, resultado);
	}
	
	@Test
	public void QueSePuedaMultiplicar() {
		/* si te da un test rojo pueden ser 2 cosas puede ser que no sea lo esperado o tenes un error en tiempos de ejecucion
		*/
		assertEquals(0, 0);
		// Preparacion
		Double operador1 = 100.0;
		Double operador2 = 20.0;
		Calculadora micalculadora = new Calculadora();
		
		//Ejecucion
		Double resultado =  micalculadora.multiplicar(operador1,operador2);
		
		//Comprobacion
		Double	valorEsperado = 20.0;
		assertEquals(valorEsperado, resultado);
	}
	
	
}
