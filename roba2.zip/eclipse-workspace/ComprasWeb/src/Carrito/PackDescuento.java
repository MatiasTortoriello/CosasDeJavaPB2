package Carrito;

public class PackDescuento extends Pack {

	private double descuento;
	private double precioTotal;
	
	public PackDescuento (double descuento) {
		this.descuento = descuento;
		this.precioTotal = 0;
	}

	public void agregar(Articulo art) {
		this.precioTotal += art.precio * (1 - (this.descuento / 100));
	}
	
}
