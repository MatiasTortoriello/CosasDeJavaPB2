package ar.edu.unlam.figuraabstracta;

public class Rectangulo extends Figura {

	private Double lado;
	private Double base;

	public Rectangulo(String color, Double lado, Double base) {
		super(color);
		this.lado = lado;
		this.base = base;
	}

	@Override
	public Double calcularArea() {
		
		return lado * base;
	}//Recordar que estoy obligado a sobreescribir.

	@Override
	public String toString() {
		return "Soy un Rectangulo [lado=" + lado + ", base=" + base + "] y mi color es" + getColor();
	}

	public Double getLado() {
		return lado;
	}

	public void setLado(Double lado) {
		this.lado = lado;
	}

	public Double getBase() {
		return base;
	}

	public void setBase(Double base) {
		this.base = base;
	}

	@Override
	public String getTipo() {
		return "Rectangulo";
	}
	
	
	
	
}
