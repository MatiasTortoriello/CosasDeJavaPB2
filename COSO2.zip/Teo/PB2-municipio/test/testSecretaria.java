import static org.junit.Assert.*;

import org.junit.Test;

import ar.edu.unlam.pb2.dominio.Habitante;
import ar.edu.unlam.pb2.dominio.Municipio;
import ar.edu.unlam.pb2.dominio.Secretaria;
import ar.edu.unlam.pb2.dominio.Vivienda;

public class testSecretaria {

	@Test
	public void queSePuedaCrearUnaSecretaria() {
		Secretaria secretaria = new Secretaria("Cordoba");
		assertNotNull(secretaria);
	}
	
	@Test
	public void queSePuedaAgregarUnHabitanteALaSecretaria(){
		Integer dni = 5;
		String nombre = "Juan";
		String calle = "Varela";
		Integer numero = 1900;
		Integer numMunicipio = 1;
		String nombreMunicipio = "San Justo";
		Municipio municipio = new Municipio(numMunicipio, nombreMunicipio);
		Vivienda vivienda = new Vivienda(calle, numero, municipio);
		Habitante habitante = new Habitante(dni, nombre, vivienda);
		Secretaria secretaria = new Secretaria("Cordoba");
		secretaria.agregarHabitante(habitante);
		Integer valorEsperado = 1;
		Integer valorObtenido = secretaria.obtenerCantidadDeHabitantes();
		//Integer valorObtenido = secretaria.getHabitantes().size();
		assertEquals(valorEsperado, valorObtenido);
	}

}
