package pb2;

import static org.junit.Assert.*;

import java.util.ArrayList;

import org.junit.Test;

public class test {


	@Test
	public void queSePuedaCrearUnObjetoCirculo() {
		Figura circulo=new Circulo("lol",34.0);
		assertNotNull(circulo);
		
	}
	
	@Test
	public void queSePuedaCalcularElAreaDelObjetoCirculo(){
		Double radio=3.0;
		String nombre="circuloo";
		Figura circulo=new Circulo(nombre,radio);
		Double resultadoDeseado=28.26;
		Double resultadoObtenido=circulo.calcularArea();
		System.out.println(resultadoObtenido);
		assertEquals(resultadoDeseado,resultadoObtenido);
		
	}
	
	@Test
	public void quesePuedaObtenerUnListaDeFiguras(){
		Caja caja= new Caja();
		Double radio=3.0;
		String nombre="circuloo";
		Figura circulo=new Circulo(nombre,radio);
		caja.agregarFigura(circulo);
		Integer cantidadDeseada=1;
		Integer cantidadObtenida=caja.cantidadFigurasGuardas();
		assertEquals(cantidadDeseada,cantidadObtenida);
		
		
	}
	
	@Test 
	public void queSePuedanObtenerFigurasConAreaMayorADiezDesdeUnaListaDeFiguras(){
		Caja caja= new Caja();
		
		Double radio=3.0;
		String nombre="circuloo";
		Figura circulo=new Circulo(nombre,radio);
		
		Double radioB=1.0;
		String nombreB="circuloo";
		Figura circuloB=new Circulo(nombreB,radioB);
		
		caja.agregarFigura(circulo);
		caja.agregarFigura(circuloB);
		
		Figura figuDeseada=circulo;
		Figura figuObtenida=caja.obtenerFiguraConAreaMayoraDiez();
		assertEquals(figuDeseada,figuObtenida);	
		
	}

}
