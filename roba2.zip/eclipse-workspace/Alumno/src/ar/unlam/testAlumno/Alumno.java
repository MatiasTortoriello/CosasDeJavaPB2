package ar.unlam.testAlumno;

public class Alumno {	
		private String nombre;
		private String apellido;
		private int dni;
		private boolean estado;
		private int legajo;

		public Alumno() {

		}

		public Alumno crear(String nombre, String apellido, Integer legajo, Integer dni, Boolean estado) {
			// TODO Auto-generated method stub
			
			
			return ;
			
	
		public void setNombre(String nombre) {
			this.nombre = nombre;
		}

		

		public void setApellido(String apellido) {
			this.apellido = apellido;
		}

		

		public void setDni(int dni) {
			this.dni = dni;
		}

		public boolean isEstado() {
			return estado;
		}

		public void setEstado(boolean estado) {
			this.estado = estado;
		}

		

		public void setLegajo(int legajo) {
			this.legajo = legajo;
		}

		
		}

	}

