package Clases;

import static org.junit.Assert.*;

import java.time.LocalDateTime;

import org.junit.Test;

public class TestVuelo {

	@Test
	public void queSePuedaCrearUnaAerolinea() {
		String nombre = "Argentina";
		Aerolinea aerolinea = new Aerolinea(nombre);
		
		String resultadoEsperado = "Argentina";
		assertEquals(resultadoEsperado, aerolinea.getNombre());
	}
	
	@Test 
	public void agregarPilotoALaAerolinea() {
		String nombre = "Argentina";
		Aerolinea aerolinea = new Aerolinea(nombre);
		
		Personal personal = new Piloto(1, "piloto");
		aerolinea.agregarPersona(personal);
		
		Integer cantPersonal = 1;
		
		assertEquals(cantPersonal, aerolinea.obtenerCantPersonal());
	}
	
	@Test
	public void queSePuedaCrearUnVueloEnUnaAerolinea() {
		String nombre = "Argentina";
		Aerolinea aerolinea = new Aerolinea(nombre);
		
		Vuelo vuelo = new Vuelo(1, "Buenos Aires", "Bariloche", LocalDateTime.now());
		aerolinea.agregarVuelo(vuelo);
		
		Integer cantVuelo = 1;
		
		assertEquals(cantVuelo, aerolinea.obtenerCantVuelos());
	}
	
	@Test
	public void agregarPilotoAlVuelo(){
		String nombre = "Argentina";
		Aerolinea aerolinea = new Aerolinea(nombre);
		
		Personal personal = new Piloto(1, "piloto");
		aerolinea.agregarPersona(personal);
		
		Vuelo vuelo = new Vuelo(1, "Buenos Aires", "Bariloche", LocalDateTime.now());
		aerolinea.agregarVuelo(vuelo);
		
		Integer idPiloto = 1;
		Integer idVuelo = 1;
		aerolinea.agregarPersonalAlVuelo(idPiloto , idVuelo);
		
		assertEquals(idPiloto, personal.getId());
		assertEquals(idVuelo, vuelo.getId());
	}
	
	@Test
	public void queNoSePuedaAgregarMasDeDosPilotosAlVuelo() {
		String nombre = "Argentina";
		Aerolinea aerolinea = new Aerolinea(nombre);
		
		Personal personal1 = new Piloto(1, "piloto");
		aerolinea.agregarPersona(personal1);
		Personal personal2 = new Piloto(2, "piloto");
		aerolinea.agregarPersona(personal2);
		Personal personal3 = new Piloto(3, "piloto");
		aerolinea.agregarPersona(personal3);
		
		Vuelo vuelo = new Vuelo(1, "Buenos Aires", "Bariloche", LocalDateTime.now());
		aerolinea.agregarVuelo(vuelo);
		
		Integer idPiloto = 1;
		Integer idVuelo = 1;
		aerolinea.agregarPersonalAlVuelo(idPiloto , idVuelo);
		Integer idPiloto2 = 2;
		aerolinea.agregarPersonalAlVuelo(idPiloto2 , idVuelo);
		Integer idPiloto3 = 3;
		aerolinea.agregarPersonalAlVuelo(idPiloto3 , idVuelo);
		
		Integer cantidadPilotos = 2;
		
		assertEquals(cantidadPilotos, aerolinea.getCantPilotos());
		System.out.println(aerolinea.getCantPilotos());
		
	}
	
	
}
