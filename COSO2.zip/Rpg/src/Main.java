
public class Main {
	public static void main(String[] args) {
		Inicio pj= new Personaje();
		System.out.println(pj.getDa�o());
		
		pj= new espada(pj);
		System.out.println(pj.getDa�o());
		
		pj= new conAmuleto(pj);
		System.out.println(pj.getDa�o());
		
	}
}
