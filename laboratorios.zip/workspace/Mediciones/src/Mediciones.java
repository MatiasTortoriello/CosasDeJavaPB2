
public class Mediciones {

	private double medida;
	private UnidadesDeMedida tipo;

	Mediciones(double medida, UnidadesDeMedida tipo) {
		this.medida = medida;
		this.tipo = tipo;
	}

	public void aKm(String tipo) {
		
		tipo.toLowerCase();
		if (tipo == "mts") {
			this.medida /= 1000;
			this.tipo = "km";
		}
		
	}

	public void aMTS(String tipo) {
		
		tipo.toLowerCase();
		if (tipo == "km") {
			this.medida *= 1000;
			this.tipo = "mts";
		}
	}

	public void aPie(String tipo) {
		// una milla 5280 pies
		tipo.toLowerCase();
		if (tipo == "milla") {
			this.medida *= 5280;
			this.tipo = "pies";
		}
	}

	public void aMilla(String tipo) {
		// una milla 5280 pies
		tipo.toLowerCase();
		if (tipo == "pies") {
			this.medida /= 5280;
			this.tipo = "milla";
		}
	}

	@Override
	public String toString() {
		return "Mediciones [medida=" + medida + " " + tipo + "]";
	}

	public static void main(String[] args) {
		Mediciones med = new Mediciones(10.0, "km");

		med.aMTS("km");
		System.out.println(med);

		med.aKm("mts");
		System.out.println(med);
		
		Mediciones med2 = new Mediciones(10.0, "pies");

		med2.aMilla("pies");
		System.out.println(med2);
		
		med2.aPie("milla");
		System.out.println(med2);

	}
}
