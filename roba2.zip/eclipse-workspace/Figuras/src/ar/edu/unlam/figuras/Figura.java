package ar.edu.unlam.figuras;

public abstract class Figura {
	
	protected String nombre;
	protected String color;
	
	public Figura(String nombre) {
		this.nombre = nombre;
	}
	
	public Figura(String nombre, String color) {
		this.nombre = nombre;
		this.color = color;
	}
	
	
	public String obtenerNombre() {
		return this.nombre;
	}

	public String obtenerColor() {
		return this.color;
	}

	public abstract Double calcularArea();


	
}
