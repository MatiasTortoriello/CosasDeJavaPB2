import java.io.File;
import java.io.IOException;
import java.io.PrintWriter;
import java.io.RandomAccessFile;
import java.util.Scanner;

public class Japoneses {
	
	
	void resolucion(String nombreArchivoEntrada, String nombreArchivoSalida)
	{
		try
		{

			File archivoIn = new File(nombreArchivoEntrada);
			RandomAccessFile archivo = new RandomAccessFile(archivoIn, "r");
			File archivoOut = new File(nombreArchivoSalida);
			PrintWriter writer = new PrintWriter(archivoOut);
			
			Luchador luchadorAnalizado = new Luchador();
			Luchador sigLuchador = new Luchador();
			
			int cantLuchadores = archivo.readInt();
			int luchadoresQueDomina = 0;
			long posSigLuchador;
			
			for( int i = 0 ; i < cantLuchadores ; i++ )
			{	
				
				luchadorAnalizado.setAltura(archivo.readInt());
				luchadorAnalizado.setPeso(archivo.readInt());
				posSigLuchador = archivo.getFilePointer();
				
				
				for( int j = 0 ; j < cantLuchadores ; j++)
				{	
					archivo.seek(Integer.BYTES);
					sigLuchador.setAltura(archivo.readInt());
					sigLuchador.setPeso(archivo.readInt());
					if( i != j )
					{
						if( luchadorAnalizado.dominaA(sigLuchador) > 0 )
						{
							luchadoresQueDomina++;
						}
					}
				}
				
				writer.println(luchadoresQueDomina);
				luchadoresQueDomina = 0;
				
				archivo.seek(posSigLuchador);
				
			}
			archivo.close();
			writer.close();
		}
		catch(IOException e)
		{
			e.printStackTrace();
		}
		
		
	}
	
}
