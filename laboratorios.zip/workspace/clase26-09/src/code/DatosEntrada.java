package code;

import java.util.ArrayList;

public class DatosEntrada {

	private ArrayList<Personaje> personajes;
	private ArrayList<Objeto> objetos;
	private int distanciaObjetivo;

	public DatosEntrada(ArrayList<Personaje> personajes, ArrayList<Objeto> objetos, int distanciaObjetivo) {
		this.personajes = personajes;
		this.objetos = objetos;
		this.distanciaObjetivo = distanciaObjetivo;
	}

	public ArrayList<Personaje> getPersonajes() {
		return personajes;
	}

	public ArrayList<Objeto> getObjetos() {
		return objetos;
	}

	public int getDistanciaObjetivo() {
		return distanciaObjetivo;
	}

}
