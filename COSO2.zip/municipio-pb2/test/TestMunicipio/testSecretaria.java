package TestMunicipio;

import static org.junit.Assert.*;

import java.util.ArrayList;

import org.junit.Test;

import ar.edu.unlam.pb2.dominio.Habitante;
import ar.edu.unlam.pb2.dominio.Municipio;
import ar.edu.unlam.pb2.dominio.Secretaria;
import ar.edu.unlam.pb2.dominio.Vivienda;

public class testSecretaria {

	@Test
	public void queSePuedaCrearUnaSecretaria() {
		Secretaria secretaria = new Secretaria("Cordoba");
		assertNotNull(secretaria);
	}
	
	@Test
	public void queSePuedaAgregarUnHabitanteALaSecretaria(){
		Integer dni = 5;
		String nombre = "Juan";
		String apellido = "Lopez";
		String calle = "Varela";
		Integer numero = 1900;
		Integer numMunicipio = 1;
		String nombreMunicipio = "San Justo";
		Municipio municipio = new Municipio(numMunicipio, nombreMunicipio);
		Vivienda vivienda = new Vivienda(calle, numero, municipio);
		Habitante habitante = new Habitante(dni, nombre, vivienda, apellido);
		Secretaria secretaria = new Secretaria("Cordoba");
		secretaria.agregarHabitante(habitante);
		Integer valorEsperado = 1;
		Integer valorObtenido = secretaria.obtenerCantidadDeHabitantes();
		//Integer valorObtenido = secretaria.getHabitantes().size();
		assertEquals(valorEsperado, valorObtenido);
	}
	
	@Test
	public void queSePuedaAgregarUnaVivienda(){
		Integer dni = 5;
		String nombre = "Juan";
		String apellido = "Lopez";
		String calle = "Varela";
		Integer numero = 1900;
		Integer id = 1;
		Integer numMunicipio = 1;
		String nombreMunicipio = "San Justo";
		Municipio municipio = new Municipio(numMunicipio, nombreMunicipio);
		Secretaria secretaria = new Secretaria("Cordoba");
		Vivienda vivienda = new Vivienda(calle, numero, municipio, id);
		Habitante habitante = new Habitante(dni, nombre, vivienda, apellido);
		secretaria.agregarVivienda(vivienda);
		Integer valorEsperado = 1;
		Integer valorObtenido = secretaria.obtenerCantidadVivienda();
		assertEquals(valorEsperado, valorObtenido);
	}
	
	@Test
	public void queSePuedaComprarPorcentajeDeUnaCasaParaUnHabitante(){
		Integer dni = 5;
		String nombre = "Juan";
		String apellido = "Lopez";
		String calle = "Varela";
		Integer numero = 1900;
		Integer id = 1;
		Integer numMunicipio = 1;
		String nombreMunicipio = "San Justo";
		Municipio municipio = new Municipio(numMunicipio, nombreMunicipio);
		Secretaria secretaria = new Secretaria("Cordoba");
		Vivienda vivienda = new Vivienda(calle, numero, municipio, id);
		Habitante habitante = new Habitante(dni, nombre, vivienda, apellido);	
		secretaria.comprarVivienda(habitante, vivienda, 60.0);
		Integer valorEsperado = 1;
		Integer valorObtenido = secretaria.obtenerCantidadCompras();
		assertEquals(valorEsperado, valorObtenido);
	}
	
	@Test
	public void quePuedaRegistrarDosUsuariosParaUnaMismaVivienda(){
		Integer dni = 5;
		String nombre = "Juan";
		String apellido = "Lopez";
		String calle = "Varela";
		Integer numero = 1900;
		Integer id = 1;
		Integer numMunicipio = 1;
		String nombreMunicipio = "San Justo";
		Municipio municipio = new Municipio(numMunicipio, nombreMunicipio);
		Secretaria secretaria = new Secretaria("Cordoba");
		Vivienda vivienda = new Vivienda(calle, numero, municipio, id);
		Habitante habitante1 = new Habitante(dni, nombre, vivienda, apellido);
		Habitante habitante2 = new Habitante(23455871, nombre, vivienda, apellido);	
		secretaria.comprarVivienda(habitante1, vivienda, 60.0);
		secretaria.comprarVivienda(habitante2, vivienda, 40.0);
		Integer valorEsperado = 2;
		Integer valorObtenido = secretaria.obtenerCantidadCompras();
		assertEquals(valorEsperado, valorObtenido);
	}
	
	@Test
	public void queNoSePuedanRegistrarPropietariosSiElPorcentajeEsCien(){
		Integer dni = 5;
		String nombre = "Juan";
		String apellido = "Lopez";
		String calle = "Varela";
		Integer numero = 1900;
		Integer id = 1;
		Integer numMunicipio = 1;
		String nombreMunicipio = "San Justo";
		Municipio municipio = new Municipio(numMunicipio, nombreMunicipio);
		Secretaria secretaria = new Secretaria("Cordoba");
		Vivienda vivienda = new Vivienda(calle, numero, municipio, id);
		Habitante habitante1 = new Habitante(dni, nombre, vivienda, apellido);
		Habitante habitante2 = new Habitante(23455871, nombre, vivienda, apellido);	
		Habitante habitante3 = new Habitante(24455871, nombre, vivienda, apellido);	
		assertTrue(secretaria.comprarVivienda(habitante1, vivienda, 60.0));
		//secretaria.comprarVivienda(habitante2, vivienda, 40.0);
		//assertTrue(secretaria.comprarVivienda(habitante3, vivienda, 50.0));
	}
	
	@Test
	public void queSePuedaObtenerUnaListaDeViviendasCuyoPorcentajeNoSupereElCienPorciento(){
		Integer dni = 5;
		String nombre = "Juan";
		String apellido = "Lopez";
		String calle = "Varela";
		Integer numero = 1900;
		Integer id = 1;
		Integer numMunicipio = 1;
		String nombreMunicipio = "San Justo";
		Municipio municipio = new Municipio(numMunicipio, nombreMunicipio);
		Secretaria secretaria = new Secretaria("Cordoba");
		Vivienda vivienda1 = new Vivienda(calle, 132, municipio, id);
		Vivienda vivienda2 = new Vivienda(calle, 321, municipio, id);
		Vivienda vivienda3 = new Vivienda(calle, 123, municipio, id);
		Habitante habitante1 = new Habitante(dni, nombre, vivienda1, apellido);
		Habitante habitante2 = new Habitante(23455871, nombre, vivienda2, apellido);	
		Habitante habitante3 = new Habitante(24455871, nombre, vivienda3, apellido);	
		secretaria.comprarVivienda(habitante1, vivienda1, 60.0);
		secretaria.comprarVivienda(habitante2, vivienda1, 35.0);
		secretaria.comprarVivienda(habitante2, vivienda2, 30.0);
		secretaria.comprarVivienda(habitante2, vivienda3, 100.0);
		HashSet<Vivienda> viviendas = secretaria.obtenerViviendaCuyoPorcentajeEsMenorACien();
		Integer valorEsperado = 2;
		Integer valorObtenido = viviendas.size();
		assertEquals(valorEsperado, valorObtenido);
	}
	
	
	@Test
	public void generarIdAutomaticamente(){
		Integer dni = 5;
		String nombre = "Juan";
		String apellido = "Lopez";
		Habitante habitante = new Habitante(dni, nombre, apellido);
		Secretaria secretaria = new Secretaria("Cordoba");
		secretaria.generarId();
	}
	
	

}
