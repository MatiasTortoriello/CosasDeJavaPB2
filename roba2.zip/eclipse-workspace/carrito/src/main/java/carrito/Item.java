package carrito;

public interface Item {

}
