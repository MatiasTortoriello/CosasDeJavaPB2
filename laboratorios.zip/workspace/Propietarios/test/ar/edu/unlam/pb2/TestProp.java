package ar.edu.unlam.pb2;

import static org.junit.Assert.*;

import java.util.ArrayList;
import java.util.HashSet;

import org.junit.Test;

public class TestProp {

	@Test
	public void queSePuedaAgregarHabitanteAUnaSecretaria(){
		Habitante habitante = new Habitante("Luca", "Modic", 4488);
		Secretaria secretaria = new Secretaria();
		secretaria.agregarHabitante(habitante);
		Integer valorEsperado = 1;
		Integer valorObtenido = secretaria.obtenerCantidadDeHabitantes();
		assertEquals(valorEsperado, valorObtenido);
	}
	
	@Test 
	public void queSePuedaAgregarUnaViviendaALaSecretaria(){
		Integer id = 1;
		Integer numero = 2;
		String calle = "Lol";
		Vivienda vivienda = new Vivienda(id, numero, calle);
		Secretaria secretaria = new Secretaria();
		secretaria.agregarVivienda(vivienda);
		Integer valorEsperado = 1;
		Integer valorObtenido = secretaria.obtenerCantidadDeViviendas();
		assertEquals(valorEsperado, valorObtenido);
	}
	
	@Test
	public void queSePuedaComprarElPorcentajeDeUnaCasaParaUnHabitante(){
		Habitante habitante = new Habitante("Luca", "Modic", 4488);
		Secretaria secretaria = new Secretaria();
		Vivienda vivienda = new Vivienda(1, 2, "Lol");
		secretaria.comprarVivienda(habitante, vivienda, 100.00);
		Integer valorEsperado = 1;
		Integer valorObtenido = secretaria.obtenerCantidadDePropietarios();
		assertEquals(valorEsperado, valorObtenido);
	}
	
	@Test
	public void queDosPersonasPuedanComprarUnaVivienda(){
		Habitante habitante1 = new Habitante("Luca", "Modic", 4488);
		Habitante habitante2 = new Habitante("Lucas", "Modica", 4487);
		Secretaria secretaria = new Secretaria();
		Vivienda vivienda = new Vivienda(1, 2, "Lol");
		secretaria.comprarVivienda(habitante1, vivienda, 50.00);
		secretaria.comprarVivienda(habitante2, vivienda, 50.00);
		Integer valorEsperado = 2;
		Integer valorObtenido = secretaria.obtenerCantidadDePropietarios();
		assertEquals(valorEsperado, valorObtenido);
	}
	
	@Test
	public void queNoSePuedanAgregarCompradoresSiElPorcentajeEsMayorQueCienPorciento(){
		Habitante habitante1 = new Habitante("Luca", "Modic", 4488);
		Habitante habitante2 = new Habitante("Lucas", "Modica", 4487);
		Secretaria secretaria = new Secretaria();
		Vivienda vivienda = new Vivienda(1, 2, "Lol");
		assertTrue(secretaria.comprarVivienda(habitante1, vivienda, 60.00));
		assertFalse(secretaria.comprarVivienda(habitante2, vivienda, 50.00));
		
	}
	
	@Test
	public void queSePuedaObtenerUnaListaDeViviendasCuyoPorcentajeSeaMenorAlCien(){
		Habitante habitante1 = new Habitante("Luca", "Modic", 4488);
		Habitante habitante2 = new Habitante("Lucas", "Modica", 4487);
		Secretaria secretaria = new Secretaria();
		Vivienda vivienda = new Vivienda(1, 2, "Lol");
		Vivienda vivienda2 = new Vivienda(3, 1, "Lol");
		Vivienda vivienda3 = new Vivienda(2, 4, "Lol");
		secretaria.comprarVivienda(habitante1, vivienda, 100.00);
		secretaria.comprarVivienda(habitante2, vivienda2, 30.00);
		secretaria.comprarVivienda(habitante1, vivienda2, 30.00);
		secretaria.comprarVivienda(habitante2, vivienda3, 10.00);
		HashSet<Vivienda> viviendaMenorAlCien = secretaria.obtenerViviendasCuyoPorcentajeEsMenorAlCien();
		
		Integer valorEsperado = 2;
		Integer valorObtenido = viviendaMenorAlCien.size();
		assertEquals(valorEsperado, valorObtenido);
		
	}
	
	
	
}
