package ar.edu.unlam.Class;

import java.time.LocalDate;
import java.util.*;

public class Eventos implements Comparable<Eventos> {
	private Integer idevento;
	private String nombreEvento;
	private LocalDate fechaEvento;
	private Double duracion;
	private TreeSet<Comisario> listaComisarios;
	private TreeSet<Participantes> listaParticipantes;

	public Eventos(Integer idevento, String nombreEvento, LocalDate fechaevento, Double duracion) {

		this.idevento = idevento;
		this.nombreEvento = nombreEvento;
		this.fechaEvento = fechaevento;
		this.duracion = duracion;
		listaComisarios = new TreeSet<Comisario>();
		listaParticipantes = new TreeSet<Participantes>();
	}

	public Integer calcularPromedioEdad() {
		Integer promedio = 0;
		Integer i = 0;
		for (Comisario comisario : listaComisarios) {
			if (comisario != null) {
				i++;
				promedio += comisario.getEdad();
			}

		}
		return promedio/i;
	}

	public Integer getIdevento() {
		return idevento;
	}

	public void setIdevento(Integer idevento) {
		this.idevento = idevento;
	}

	public String getNombreEvento() {
		return nombreEvento;
	}

	public void setNombreEvento(String nombreEvento) {
		this.nombreEvento = nombreEvento;
	}

	public LocalDate getFechaEvento() {
		return fechaEvento;
	}

	public void setFechaEvento(LocalDate fechaEvento) {
		this.fechaEvento = fechaEvento;
	}

	public Double getDuracion() {
		return duracion;
	}

	public void setDuracion(Double duracion) {
		this.duracion = duracion;
	}

	public TreeSet<Comisario> getListaComisarios() {
		return listaComisarios;
	}

	public void setListaComisarios(TreeSet<Comisario> listaComisarios) {
		this.listaComisarios = listaComisarios;
	}

	public TreeSet<Participantes> getListaParticipantes() {
		return listaParticipantes;
	}

	public void setListaParticipantes(TreeSet<Participantes> listaParticipantes) {
		this.listaParticipantes = listaParticipantes;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((idevento == null) ? 0 : idevento.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Eventos other = (Eventos) obj;
		if (idevento == null) {
			if (other.idevento != null)
				return false;
		} else if (!idevento.equals(other.idevento))
			return false;
		return true;
	}

	@Override
	public int compareTo(Eventos o) {

		return this.idevento - o.getIdevento();
	}

}
