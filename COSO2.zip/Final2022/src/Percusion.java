
public class Percusion extends Instrumento implements Lustrable{

	public Percusion(String name, int tono, String descr) {
		super(name, tono, descr);
		// TODO Auto-generated constructor stub
	}

	public void tocar() {
		 System.out.println("soy un instrumento de viento de percusion y estoy tocando");	
		}

	@Override
	public void lustrar() {
		System.out.println("soy un instrumento de viento de percusion y estoy tocando");
		
	}
}
