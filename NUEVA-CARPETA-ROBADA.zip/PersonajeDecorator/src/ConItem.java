
public abstract class ConItem extends Unidad {
	
	private Unidad unidad;

	@Override
	public abstract void atacar(Unidad otra);

	@Override
	public abstract void recibirDanio(int danio);
}
