package Carrito;

public class Compra {
	
	private double precioTotal;
	protected List<Articulo> articulos = new Linked;

	public Compra() {
		this.precioTotal = 0;
	}
	
	public void agregar(Articulo art) {
		articulos.add(art)
	}

	private double totalizar() {
		this.precioTotal += 
	}
	
}
