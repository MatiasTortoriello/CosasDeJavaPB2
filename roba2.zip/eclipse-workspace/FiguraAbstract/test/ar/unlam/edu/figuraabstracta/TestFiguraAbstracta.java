package ar.unlam.edu.figuraabstracta;

import java.util.ArrayList;
import java.util.List;

import org.hamcrest.core.IsInstanceOf;
import org.junit.Test;

import ar.edu.unlam.figuraabstracta.Circulo;
import ar.edu.unlam.figuraabstracta.Figura;
import ar.edu.unlam.figuraabstracta.Rectangulo;

public class TestFiguraAbstracta {
	@Test

	/*
	 * public void test() { Figura figura = new Rectangulo("Rojo",1.0,2.0); //figura
	 * es una Figura porque solo ve los metodos de Figura.
	 * 
	 * Circulo circulo = new Circulo("Blanco", 6.0);
	 * 
	 * System.out.println(((Rectangulo)figura).getLado());//casteamos a figura.
	 * figura no tiene alcance para ver a get lado
	 * System.out.println(figura.toString());//aca responde figura, adoptando a
	 * rectangulo. responde con los hijos. figura = circulo;
	 * System.out.println(figura.toString());
	 * System.out.println(circulo.getRadio()); //figura.calcularArea usa el metodo
	 * de la clase Rectangulo. //pero usarfigura.getLado no funciona. �por qu�?
	 * polimorfismo }
	 */

	public void test() {

		List<Figura> contenedor = new ArrayList<>();

		Rectangulo rectangulo = new Rectangulo("Rojo", 1.0, 2.0);
		Rectangulo rectangulo2 = new Rectangulo("Azul", 3.0, 6.0);

		Circulo circulo = new Circulo("Blanco", 6.0);

		contenedor.add(rectangulo);
		contenedor.add(rectangulo2);
		contenedor.add(circulo);//no lo puedo castear como Rectangulo, porque es Circulo.

		for (Figura figura : contenedor) {
			figura.getClass().getSimpleName(); //me devuelve un string que puedo usar en el if; devuelve en que instancia esta.
			
			if (figura.getTipo().equals("Rectangulo"))
				System.out.println(((Rectangulo) figura).getLado());
				//es lo mismo que usar instanceof, pero mas prolijo. genero un metodo abstracto en figura
				//y hago que cada elemento del for each llame a el metodo que sobreescribieron.
			
//			if (figura instanceof Rectangulo)
//				System.out.println(((Rectangulo) figura).getLado());
		}
	}

}
