package ar.edu.unlam.Class;

import java.util.*;

public class Polideportivo extends Complejo {

	private TreeSet<Areas> areasDeportivas;

	public Polideportivo(Integer id, String nombre, Double areaOcupada) {
		super(id, nombre, areaOcupada);
		areasDeportivas = new TreeSet<Areas>();
	}

	public Areas buscarArea(Integer idArea) {
		Areas encontrado = null;
		for (Areas areas : areasDeportivas) {
			if (areas.getIdArea().equals(idArea)) {
				encontrado = areas;
			}
		}
		return encontrado;
	}

	public TreeSet<Areas> getAreasDeportivas() {
		return areasDeportivas;
	}

	public void setAreasDeportivas(TreeSet<Areas> areasDeportivas) {
		this.areasDeportivas = areasDeportivas;
	}

}
