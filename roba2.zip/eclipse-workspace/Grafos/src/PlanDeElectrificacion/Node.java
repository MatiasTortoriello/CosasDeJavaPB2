package PlanDeElectrificacion;

class Node {
	
	public int number;
	public double cost;
	
	public Node(int number, double cost) {
		this.number = number;
		this.cost = cost;
	}

}