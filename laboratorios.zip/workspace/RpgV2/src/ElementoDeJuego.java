
public abstract class ElementoDeJuego {
	public abstract Integer getDanio();
}
