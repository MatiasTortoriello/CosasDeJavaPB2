import java.util.HashSet;
import java.util.Set;
import java.util.TreeSet;

public class Main2 {
	public static void main(String[] args) {
		Set <Integer> conj = new HashSet<Integer>();
		Set <Integer> conj2 = new TreeSet<Integer>();
		
		int num1 = 1;
		int num2 = 1;
		int num3 = 3;
		String p1 = "vela";
		String p2 = "bote";
		
		
		conj.add(num1);
		conj.add(num2);
		conj.remove(num1);
		
		conj.add(num3);
		conj.toString();
		conj.size();
		
		System.out.println(conj);
	}

}
