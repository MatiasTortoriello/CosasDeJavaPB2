package Clases;

import java.time.LocalDateTime;
import java.util.ArrayList;

public class Vuelo {

	private Integer id;
	private String origen;
	private String destino;
	private LocalDateTime fechaHora;
	private ArrayList <Personal> personal;
	
	public Vuelo(Integer id, String origen, String destino, LocalDateTime fechaHora) {
		this.id = id;
		this.origen = origen;
		this.destino = destino;
		this.fechaHora = fechaHora;
		this.personal = new ArrayList <Personal>();
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getOrigen() {
		return origen;
	}

	public void setOrigen(String origen) {
		this.origen = origen;
	}

	public String getDestino() {
		return destino;
	}

	public void setDestino(String destino) {
		this.destino = destino;
	}

	public LocalDateTime getFechaHora() {
		return fechaHora;
	}

	public void setFechaHora(LocalDateTime fechaHora) {
		this.fechaHora = fechaHora;
	}

	@Override
	public String toString() {
		return "Vuelo [id=" + id + ", origen=" + origen + ", destino=" + destino + ", fechaHora=" + fechaHora + "]";
	}

	public void agregarPersonal(Personal pilotoEncontrado) {
		this.personal.add(pilotoEncontrado);
	}
	
	

}
