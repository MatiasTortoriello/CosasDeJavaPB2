
public class CerraduraDeCombinacion {
	private int a, b, c;
	private int x, y, z;
	private boolean primerSentido = true;

	public CerraduraDeCombinacion(int x, int y, int z) {
		this.x = x;
		this.y = y;
		this.z = z;
	}

	public void izquierda() {
		if (primerSentido)
			a = ++a % 10;
		else
			c = ++c % 10;
	}

	public void derecha() {
		primerSentido = false;
		b = ++b % 10;
	}

	public boolean abrir() {
		if (a == x && b == y && c == z) {
			return true;
		}
		a = b = c = 0;
		primerSentido = true;
		return false;
	}
}
