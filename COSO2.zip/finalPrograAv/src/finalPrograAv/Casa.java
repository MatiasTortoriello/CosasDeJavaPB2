package finalPrograAv;

import java.util.ArrayList;

public class Casa {
	
	private ArrayList<Habitacion> habitaciones = new ArrayList<Habitacion>();
	
	public Casa(ArrayList<Habitacion> habitaciones) {
		this.habitaciones = habitaciones;
	}
	
	public ArtefactoElectronico artefactoQueMasConsumio(ArrayList<Habitacion> habitaciones){
		
		ArtefactoElectronico consumoMayor = new Velador(0);
		
		for (Habitacion habitacion : habitaciones) {
			
			for (ArtefactoElectronico artefacto : habitacion.getBombillas()) {
				
				if(artefacto.getConsumo() > consumoMayor.getConsumo()){
					consumoMayor = artefacto;
				}
			}
		}
		
		return consumoMayor;
	}
	
	public static void main(String[] args) {
		
		ArtefactoElectronico vel = new Velador(2);
		ArtefactoElectronico vent = new Ventilador(1);
		
		ArrayList<ArtefactoElectronico> artArray = new ArrayList<ArtefactoElectronico>();
		artArray.add(vel);
		artArray.add(vent);
		
		Habitacion hab = new Habitacion(artArray);
		
		
		ArrayList<Habitacion> habitacionesArray = new ArrayList<Habitacion>();
		habitacionesArray.add(hab);		
		
		Casa casa = new Casa(habitacionesArray);
		
		ArtefactoElectronico masConsumio = casa.artefactoQueMasConsumio(habitacionesArray);
		
		System.out.println(masConsumio.toString());
	}

}
