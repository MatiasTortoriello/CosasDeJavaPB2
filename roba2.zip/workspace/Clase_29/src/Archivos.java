import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Locale;
import java.util.Scanner;



public class Archivos {
	private String nombre;

	// constructor
	public Archivos(String nombre) {
		this.nombre = nombre;
	}

	/// metodos
	public int[][] leerArchivo() {
		Scanner scanner = null;
		int[][] datos = null;
		int n;

		try {
			File file = new File(this.nombre + ".in");
			scanner = new Scanner(file);

			scanner.useLocale(Locale.ENGLISH);

			int cant = scanner.nextInt();
			datos = new int[cant][2];
			for (int i = 0; i < cant; i++) {
				n = scanner.nextInt();
				datos[i][0] = n;
				n = scanner.nextInt();
				datos[i][1] = n;
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			scanner.close();
		}

		return datos;
	}
	
	public void guardarArchivo(int[][] datos) {
		FileWriter file = null;
		PrintWriter printerWriter = null;
		
		try {
			file = new FileWriter("sumo.out");
			printerWriter = new PrintWriter(file);
			
			for (int i = 0; i < datos.length; i++) {
				printerWriter.println(datos[i][0]);
			}
			
		}catch (Exception e) {
			e.printStackTrace();
		} finally {
			if (file != null) {
				try {
					file.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		}
		
	}

	
	
	

}
