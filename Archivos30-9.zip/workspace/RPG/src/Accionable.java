
public interface Accionable {
	
	public int getDanio();
}
