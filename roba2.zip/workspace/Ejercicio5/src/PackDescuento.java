
public class PackDescuento extends Pack{
	public float descuento;
	public float precio;
	PackDescuento(){
		
	}
}
