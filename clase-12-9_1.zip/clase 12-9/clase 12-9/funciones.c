#include "funciones.h"
#include <stdio.h>
int creararchivo(char *nombre)
{
    tProductos vector[]=
    {
        {1,"papa",1,250,1},
        {8,"pera",3,350,8},
        {3,"manzana roja",12,950,10},
    };
    FILE *pf;
    pf= fopen(nombre,"wb");
    if(!pf)
    {
        printf("error al iniciar el archivo \n");
        return -1;
    }
    fwrite(vector,sizeof(vector),1,pf);
    fclose(pf);
    return 1;
    return 0;
}


int leerarchivo(char *nombre)
{
    tProductos aux;
    FILE *pf;
    pf=fopen(nombre,"rb");
    if(!pf)
    {
        printf("error al iniciar el archivo\n");
        return -1;
    }
    printf("%-8s %-32s %-12s %-12s %-12s\n","ID","NOMBRE PRODUCTO","CANTIDAD","PRECIO","VOLUMEN PRODUCTO");
    fread(&aux,sizeof(tProductos),1,pf);
    while(!feof(pf))
    {

        printf("%3d     %-31s      %3d         %5.2f        %2d \n",aux.id,aux.nombre,aux.cantidad,aux.precio,aux.volprod);
        fread(&aux,sizeof(tProductos),1,pf);

    }
    fclose(pf);
    return 1;
}

int leertxt(char *archtexto,char *archbin)
{
    tNovedades aux;
    FILE *txt;
    char cad[100];
    txt=fopen(archtexto,"rt");
    if(txt==NULL)
    {
        printf("error al iniciar el arhivo \n");
        return -1;
    }
    while(fgets(cad,sizeof(cad),txt))
    {
        TrozarCamposLongVariable(&aux,cad);
        mostrarAct(&aux);
        actualizararch(archbin,&aux);
    }
    fclose(txt);

    return 0;
}
void TrozarCamposLongVariable(tNovedades *d,char *cad)
{
    char *aux=strchr(cad,'\n');
    *aux='\0';

    aux=strrchr(cad,';');
    sscanf(aux+1,"%c",&d->tipo);
    *aux='\0';
    aux=strrchr(cad,';');
    sscanf(aux+1,"%d",&d->cantidad);
    *aux='\0';
    sscanf(cad,"%d",&d->id);
}
void mostrarAct(tNovedades const *aux)
{
    printf("id del producto      cantidad      tipo movimiento\n");
    printf("%d                   %d             %c \n",aux->id,aux->cantidad,aux->tipo);
}
int actualizararch(const char *archbin,tNovedades *aux)
{
    FILE *bin;
    int cant=0;
    tProductos prod;
    bin=fopen(archbin,"r+b");
    if(!bin)
    {
        printf("error al iniciar el archivo \n");
        return -1;
    }
    fread(&prod,sizeof(tProductos),1,bin);
    while(!feof(bin))
    {
        if(prod.id==aux->id)
        {
            cant++;
            if(aux->tipo=='r')
            {
                prod.cantidad+=aux->cantidad;
                fseek(bin, -cant * sizeof(tProductos), SEEK_CUR);
                fwrite(&prod,sizeof(tProductos),1,bin);
                fseek(bin, 0, SEEK_CUR);
            }
            if(aux->tipo=='v')
            {
                prod.cantidad-=aux->cantidad;
                fseek(bin, -cant * sizeof(tProductos), SEEK_CUR);
                fwrite(&prod,sizeof(tProductos),1,bin);
                fseek(bin, 0, SEEK_CUR);
            }

        }
        fread(&prod,sizeof(tProductos),1,bin);
    }
    fclose(bin);
}
