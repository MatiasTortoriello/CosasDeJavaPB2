
import static org.junit.Assert.*;



import org.junit.Test;

import unlam.Area;
import unlam.AreaDuplicadaException;
import unlam.Comisario;
import unlam.ComisarioDuplicadoException;
import unlam.Complejo;
import unlam.Evento;
import unlam.SedeOlimpica;
import unlam.TipoDeComisario;
import unlam.TipoDeComplejo;

 public class TestSedeOlimpica {
	 @Test 
	 public void queSePuedaCrearUnComplejoSimpleEnUnaSedeOlimpica() {
            Complejo complejo = new Complejo(1 , TipoDeComplejo.Simple, "gimnacio" , 50);
			SedeOlimpica sedeOlimpica = new SedeOlimpica(1 , "RiverPlate");
            sedeOlimpica.agregarComplejo(complejo);
    		Integer cantidadDeComplejosEsp= 1;
    		Integer cantidadDeComplejosObtenidos = sedeOlimpica.cantidadDeComplejosXsede();
             
    		assertEquals(cantidadDeComplejosObtenidos, cantidadDeComplejosObtenidos);
	 }
	 @Test 
	 public void  queSePuedaCrearUnComplejoPolideportivoConUnAreaEnUnaSedeOlimpica() {
		   Complejo complejo = new Complejo(1 , TipoDeComplejo.Polideportivo, "Huracan" , 50);
           SedeOlimpica sedeOlimpica = new SedeOlimpica(1, "Clubcasanova");
			Area area = new Area (1 , "futbol", "centro-izquierda");
		    sedeOlimpica.agregarComplejo(complejo);
		    complejo.agregarArea(area);
			Integer cantidadDeAreasEsp= 1;
    		Integer cantidadDeAreasObtenidas = complejo.cantidadDeAreas();
            assertEquals( cantidadDeAreasEsp, cantidadDeAreasObtenidas);
	 }
	 @Test 
	 public void queSePuedaCrearUnComplejoPolideportivoConUnAreaYUnEventoEnUnaSedeOlimpica(){
		 Complejo complejo = new Complejo(1 , TipoDeComplejo.Polideportivo, "Huracan" , 50);
         SedeOlimpica sedeOlimpica = new SedeOlimpica(1, "Clubcasanova");
			Evento evento = new Evento (1 , "02-02-2024", "00:30", 100 , 10);
		    sedeOlimpica.agregarComplejo(complejo);
		    complejo.agregarEvento(evento);
			Integer cantidadDeEventosEsp= 1;
  		Integer cantidadDeEventosObtenidos = complejo.cantidadDeEventos();
          assertEquals( cantidadDeEventosEsp, cantidadDeEventosObtenidos);
	 }
	@Test 
	public void  queAlAgregarUnAreaAUnPolideportivoConIndicadorYaExistenteLanceUnaExcepcionIndicadorAreaException() throws AreaDuplicadaException{
		   Complejo complejo = new Complejo(1 , TipoDeComplejo.Polideportivo, "Huracan" , 50);
           SedeOlimpica sedeOlimpica = new SedeOlimpica(1, "Clubcasanova");
			Area area = new Area (1 , "futbol", "centro-izquierda");
		    sedeOlimpica.agregarComplejo(complejo);
		    complejo.agregarArea(area);
			 
          
	 }
	
	@Test 
	public void  queSePuedaAgregarUnComisarioJuezAUnEvento(){
		Comisario comisario = new Comisario(1 , 45, TipoDeComisario.Juez ,"pepito");
		Evento evento = new Evento (1 , "02-02-2024", "00:30", 100 , 10);
        evento.agregarComisario(comisario);
    	Integer cantidadDeComisariosEsp= 1;
		Integer cantidadDeCmisariosObtenidos = evento.cantidadDeComisarios();
        assertEquals( cantidadDeComisariosEsp , cantidadDeCmisariosObtenidos);
	}
	@Test 
	public void queAlAgregarUnComisarioJueexistenteLanceUnaExcepcionComisarioException()  throws ComisarioDuplicadoException{
		Comisario comisario = new Comisario(1 , 45, TipoDeComisario.Juez ,"pepito");
		Evento evento = new Evento (1 , "02-02-2024", "00:30", 100 , 10);
         evento.agregarComisario(comisario);
     	Integer cantidadDeComisariosEsp= 1;
		Integer cantidadDeCmisariosObtenidos = evento.cantidadDeComisarios();
       /* assertEquals( cantidadDeComisariosEsp , cantidadDeCmisariosObtenidos); */
         
	}
	 @Test 
	public void  queSePuedaCalcularElTotalDeParticipantesDeLosEventosDeUnComplejoSimple(){
		 
	 }
	 
	 /* 
	
*/
}
