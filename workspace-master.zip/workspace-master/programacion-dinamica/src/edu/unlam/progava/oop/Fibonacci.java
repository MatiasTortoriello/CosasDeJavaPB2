package edu.unlam.progava.oop;

public interface Fibonacci {
	
	long fib(int n);
	
}
