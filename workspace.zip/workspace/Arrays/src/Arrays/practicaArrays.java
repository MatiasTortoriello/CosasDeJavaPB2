package Arrays;

import java.util.Scanner;

public class practicaArrays {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Scanner Teclado= new Scanner(System.in);
		
		int enteros[]=new int[5];
		int i =0, tamanio =5;
		enteros [0]= 40;
		enteros [1]= 38;
		enteros [2]= 14;
		enteros [3]= 19;
		enteros [4]= 22;
		for (i=0; i<tamanio; i++) {
		//MOSTRAR CONTENIDO DEL ARRAY
		System.out.println("Contiene "+enteros[i]);
		//SUMA DE LOS NUMEROS EN EL ARRAY
		//int suma=enteros[0]+=enteros[i];
		//System.out.println(suma);
		if(enteros[0]>=enteros[i]){
			System.out.println(enteros[0]+" es el mayor");
		}else if(enteros[1]>enteros[i]){
			System.out.println("El numero maximo es "+enteros[1]);
		}else if(enteros[2]>enteros[i]){
			System.out.println("El numero maximo es "+enteros[2]);
		}else if(enteros[3]>enteros[i]){
			System.out.println("El numero maximo es "+enteros[3]);
		}else if(enteros[4]>enteros[i]){
			System.out.println("El numero maximo es "+enteros[4]);
		}
		if(enteros[0]<enteros[i]){
			System.out.println(enteros[0]+" es el menor");
		}else if(enteros[1]<enteros[i]){
			System.out.println(+enteros[1]+" es el menor");
		}else if(enteros[2]<enteros[i]){
			System.out.println(enteros[2]+ " es el menor");
		}else if(enteros[3]<enteros[i]){
			System.out.println(enteros[3]+" es el menor");
		}else if(enteros[4]<enteros[i]){
			System.out.println(enteros[4]+" es el menor");
		}
		}
		//MOSTRAR NUMERO MAXIMO
		
	}
	}


