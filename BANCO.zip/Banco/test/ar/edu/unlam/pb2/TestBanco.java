package ar.edu.unlam.pb2;

import static org.junit.Assert.*;

import org.junit.Test;

public class TestBanco {

	@Test
	public void queSePuedaCrearUnaCajaDeAhorro() {
		CajaAhorro cajaAhorro = new CajaAhorro();
		CuentaCorriente cuentaCorriente = new CuentaCorriente();
		cuentaCorriente.extraer(45.50);
	
	}

}
