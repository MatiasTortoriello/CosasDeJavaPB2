
public class Cuerda extends Instrumento implements Afinable{

	public Cuerda(String name, int tono, String descr) {
		super(name, tono, descr);
		// TODO Auto-generated constructor stub
	}
	
	public void tocar() {
		 System.out.println("soy un instrumento de cuerda y estoy tocando");	
		}

	@Override
	public void afinar() {
		System.out.println("soy una cuerda y me estoy afinando");
		
	}

}
