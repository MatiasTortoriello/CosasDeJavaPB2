
public class Espada extends ConItem{
	private Integer danio;
	
	
	
	
	public Espada(ElementoDeJuego pj) {
		super(pj);
	}
	
	
	@Override
	public Integer getDanio() {
		return super.getDanio() + 10;
	}

}
