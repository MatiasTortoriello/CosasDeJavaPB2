package ar.edu.unlam.pb2;

public class CajaAhorro extends Cuenta {
	
	
	
	public CajaAhorro(Integer numCuenta, Integer dni, String nombre, String apellido, String tipo) {
		super(numCuenta, dni, nombre, apellido);

		
		// TODO Auto-generated constructor stub
	}

	

	public String getTipo() {
		return "Caja de ahorro";
	}
	
	
	public Boolean extraer(Double monto) {
		if (getSaldo()>= monto) {
			setSaldo(getSaldo()-monto);
			return true;
		}
		return false;
	}
	
	public void setSaldo(){
		
	}
	
}
