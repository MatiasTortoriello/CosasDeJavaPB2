public class Unidad {	
	public void atacar(Unidad otra) {
	}
	public void recibir(int dano) {
	}	
	public boolean isAlive() {
		return false;
	}
	
}
