package Packs;

import java.util.ArrayList;
import java.util.List;

public class Compra {
	
	private List<Articulo> items;


	public Compra() {
		super();
		items = new ArrayList<Articulo>();
	}

	public List<Articulo> getItems() {
		return items;
	}

	public void setItems(List<Articulo> items) {
		this.items = items;
	}

	public void agregarArticulo(Articulo articulo) {
		items.add(articulo);
	}

	public static void main(String[] args) {
		//Item item = new Item("Choco", 10);
		Articulo articulo2 = new Articulo("Choco2", 102);
		Compra compra = new Compra();
		//compra.agregarArticulo(articulo);
		compra.agregarArticulo(articulo2);
		System.out.println(compra.getItems());

	}

}
