package excepcion;

import java.util.ArrayList;
import java.util.List;

public class Excepciones {

	public static void main(String[] args) {
		int i = 5;
		int j = 0;
		List<Integer> lista = new ArrayList<Integer>();
		
		try{
			//lo que se ejecuto correctamente ya queda asi 
			lista.add(3, 10);
			System.out.println(i/j);//hasta aca se ejecuta el codigo porque aca esta el error
			System.out.println("hola");	//esto no se ejecuta
		} catch(ArithmeticException ae){
			System.err.println("no se puede dividir por cero");
		}catch(IndexOutOfBoundsException io){
			//guardar info
			//procesar info
			System.out.println("holaa2");
			io.printStackTrace();//muestra todo lo del error devulta
			System.exit(1); 	//para salir por io.printSackTrace hace que el codigo siga
		} catch(Exception e){
			//
			System.out.println("hola3");
		}
		finally{
			//se ejecuta despues del try si todo esta bien
		}
		
		System.out.println("el codifgo siguio de largo");
	}
}
