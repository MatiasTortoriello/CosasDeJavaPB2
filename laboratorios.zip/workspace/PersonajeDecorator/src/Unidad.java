public abstract class Unidad {
	private int salud;
	private int danio;
	private int defensa;
	
	public abstract int getDefensa();
	
	public abstract int getDanio();
}
