package excepcion;


import java.util.ArrayList;
import java.util.List;

public class Excepciones2 {

	public static void main(String[] args) {
		int i = 5;
		int j = 0;
		
		
		
		System.out.println("el codifgo siguio de largo");
	}
}
