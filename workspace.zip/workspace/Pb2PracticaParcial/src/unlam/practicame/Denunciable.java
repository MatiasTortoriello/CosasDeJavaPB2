package unlam.practicame;


public interface Denunciable {

	
}
