package ar.edu.unlam.pb2;

public class Vivienda {
	
	private String calle;
	private Integer numero;
	private Municipio municipio;
	
	public Vivienda(String calle, Integer numero, Municipio municipio) {
		this.calle = calle;
		this.numero = numero;
		this.municipio = municipio;
	}

	
	

}
