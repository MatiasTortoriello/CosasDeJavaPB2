package unlam;
import java.util.Set;
import java.util.TreeSet;

public class Evento implements Comparable<Evento> {
	Integer id ;
	String fecha; 
	String duracion;
	Integer participantes;
	Integer jueces;
	private Set<Comisario> comisarios;

	public Evento(Integer id, String fecha, String duracion, Integer participantes, Integer jueces) {
		// TODO Auto-generated constructor stub
		this.id=id ;
		this.fecha=fecha ;
		this.duracion = duracion ;
		this.participantes = participantes ;
		this.jueces = jueces ;
		this.comisarios = new TreeSet<>();
		
	}

 

	public void agregarComisario(Comisario comisario) {
		// TODO Auto-generated method stub
		this.comisarios.add(comisario);
		
	}



	public Integer cantidadDeComisarios() {
		// TODO Auto-generated method stub
		return comisarios.size();
	}



	@Override
	public int compareTo(Evento o) {
		// TODO Auto-generated method stub
		return 0;
	}

}
