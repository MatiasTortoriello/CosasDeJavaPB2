package vehiculo;

public class Vehiculo {
	
	private String matricula;
	public double velocidad;
	
	
	
	
	public Vehiculo(String matricula) {
		this.matricula = matricula;
		this.velocidad = 0;
	}




	public void acelerar(double cantidad) throws DemasiadoRapidoException {
		this.velocidad += cantidad;
	}




	@Override
	public String toString() {
		return "Vehiculo [matricula=" + matricula + ", velocidad=" + velocidad + "]";
	}
	
	
	
}
