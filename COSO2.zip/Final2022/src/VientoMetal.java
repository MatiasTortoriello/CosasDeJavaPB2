
public class VientoMetal extends Viento{

	public VientoMetal(String name, int tono, String descr, int tp) {
		super(name, tono, descr, tp);
		// TODO Auto-generated constructor stub
	}
	
	public void tocar() {
		 System.out.println("soy un instrumento de viento de metal y estoy tocando");	
		}

	@Override
	public void afinar() {
		System.out.println("soy un instrumento de viento de metal y me estoy afinando");
		
	}

	@Override
	public void lustrar() {
		System.out.println("soy un instrumento de viento de metal y me estoy lustrando");
		
	}

}
