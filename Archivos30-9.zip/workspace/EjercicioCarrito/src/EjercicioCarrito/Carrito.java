package EjercicioCarrito;

import java.util.LinkedList;
import java.util.List;

public class Carrito {
	
	//private Vendible<List> vendibles = ;
	private List<Vendible> vendibles = new LinkedList<Vendible>();

	public double calcularTotal(){
		return 0.00;
	}
	
	
}
