
public class Jugable {

}
