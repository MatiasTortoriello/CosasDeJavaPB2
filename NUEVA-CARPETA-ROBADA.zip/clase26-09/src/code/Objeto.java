package code;

public class Objeto {

	private int peso;

	public Objeto(int peso) {
		this.peso = peso;

	}

	public int getPeso() {
		return peso;
	}

	public boolean tienePeso() {
		return this.peso > 0;
	}

}
