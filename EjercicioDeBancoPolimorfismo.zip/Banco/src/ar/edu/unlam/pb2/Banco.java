package ar.edu.unlam.pb2;

import java.util.ArrayList;

public class Banco {

	private ArrayList<Cuenta> cuentas;

	public Banco() {
		this.cuentas = new ArrayList<>();
	}

	public void agregarCuenta(Cuenta cuenta) {
		this.cuentas.add(cuenta);
	}

	public Boolean transferir(Double monto, Cuenta origen, Cuenta destino) {
		if (origen.extraer(monto)){
			destino.depositar(monto);
			return true;
		}
		return false;
	}

	public Boolean transferir(Integer numeroDeCuentaOrigen, Integer numeroDeCuentaDestino, Double monto) {
		Cuenta origen = buscarCuenta(numeroDeCuentaOrigen);
		Cuenta destino = buscarCuenta(numeroDeCuentaDestino);

		return transferir(monto, origen, destino);

	}

	private Cuenta buscarCuenta(Integer numeroDeCuenta) {
		for (Cuenta cuenta : cuentas) {
			if (cuenta.getNumCuenta().equals(numeroDeCuenta)) {
				return cuenta;
			}
		}
		return null;
	}
	
	private Integer obtenerTodosLosPuntos(){
		Integer puntos = 0;
		for (Cuenta cuenta : cuentas) {
			if(cuenta instanceof CuentaCorriente){   //<----- Es casi lo mismo que ".getTipo"
				puntos += ((CuentaCorriente)cuenta).getPuntos();
			}
		}
		return puntos;
	}	
}
