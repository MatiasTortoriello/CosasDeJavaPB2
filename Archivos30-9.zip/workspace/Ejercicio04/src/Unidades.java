
public enum Unidades {
	METROS(1,0,0,0),
	PIES(0,3.2808, 0,0),
	MILLAS(0,0,0.00062137,0),
	KILOMETROS(0,0,0,1/1000);
	
	double metro;
	double pies;
	double millas;
	double kilometros;
	private Unidades(int metro, double pies, double millas, int kilometros){
		this.metro=metro;
		this.pies=pies;
		this.millas=millas;
		this.KILOMETROS=kilometros;
	}
}
