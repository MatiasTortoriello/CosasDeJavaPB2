
public class Guerreros {

	public static void main(String[] args) {
		Alianza ali;
		
		ali.atacar()
	}
}
