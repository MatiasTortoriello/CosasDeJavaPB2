package ar.unlam;

public class Azafata extends Personal {

	public Azafata(Integer id, String nombre, String apellido) {
		super(id, nombre, apellido);
		
	}

}
