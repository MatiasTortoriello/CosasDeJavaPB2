package agustinpackage;

public class UnaClase {
	private static final int POTENCIA = 2;
	
	public static void main(String[] args) {
		//System.out.println("Hola Mundo");
		Integer [] vector = {3,5,2,4};
		//imprimirElevado(vector);  
		mostrarTodosAlCuadrado(POTENCIA, vector);
	}

	private static void mostrarTodosAlCuadrado(final int POTENCIA, Integer[] vector) {
		for(int i=0;i<vector.length;i++){
			System.out.println((int)Math.pow(vector[i], POTENCIA));
		}
	} 
}

/*static void imprimirElevado(Integer [] Vector){
	for(int i=0;i<Vector.length;i++){
		System.out.println(Math.pow(Vector[i], 2));
	}
}*/