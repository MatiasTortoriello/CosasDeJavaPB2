package Clases;

import static org.junit.Assert.assertEquals;

import java.util.ArrayList;
import java.util.List;

import org.junit.Test;

public class TestAerolinea {
	
	@Test
	public void queSePuedaCrearUnaArolinea() {
		Aerolinea aerolinea = new Aerolinea("Argentina");
		
		String resultadoEsperado = "Argentina";
		String resultado = aerolinea.getNombre();
		
		assertEquals(resultadoEsperado, resultado);
		
	}
	
	@Test
	public void queSePuedaCrearUnPasajero() {
		Aerolinea aerolinea = new Aerolinea("Argentina");
		Pasajero nuevoPasajero = aerolinea.crearPasajero(0, "Juan");
		
		Integer resultadoEsperadoIdentificador = 0;
		Integer resultadoIdentificador = nuevoPasajero.getIdentificador();
		
		assertEquals(resultadoEsperadoIdentificador, resultadoIdentificador);
	}

	@Test
	public void queSePuedaCrearUnPersonalTipoPiloto() {
		Aerolinea aerolinea = new Aerolinea("Argentina");
		
		Personal nuevoPersonal = aerolinea.crearPersonal(0 , "Juan", "PILOTO");
		
		String resultadoEsperado = "PILOTO";
		String resultado = nuevoPersonal.getTipoPersonal();
		
		assertEquals(resultadoEsperado, resultado);
	}
	
	@Test
	public void queSePuedaCrearUnPersonalTipoAzafata() {
		Aerolinea aerolinea = new Aerolinea("Argentina");
		
		Personal nuevoPersonal = aerolinea.crearPersonal(0 , "Mara", "AZAFATA");
		
		String resultadoEsperado = "AZAFATA";
		String resultado = nuevoPersonal.getTipoPersonal();
		
		assertEquals(resultadoEsperado, resultado);
	}
	
	@Test
	public void queSePuedaCrearUnAvion() {
		Aerolinea aerolinea = new Aerolinea("Argentina");
		
		Avion avion = aerolinea.crearAvion(0, "B", 100, "Boing");
		
		Integer resultadoEsperadoIdentificador = 0;
		Integer resultadoIdentificador = avion.getIdentificador();
		
		assertEquals(resultadoEsperadoIdentificador, resultadoIdentificador);
	}
	
	@Test
	public void queSePuedaCrearUnVuelo() {
		Aerolinea aerolinea = new Aerolinea("Argentina");
		
		Avion avion = new Avion(0, "B", 100, "Boing");
		
		Vuelo vuelo = aerolinea.crearVuelo(0, "BSAS", "BAR", avion);
		
		Integer resultadoEsperadoIdentificador = 0;
		Integer resultadoIdentificador = vuelo.getIdentificador();
		
		assertEquals(resultadoEsperadoIdentificador, resultadoIdentificador);
	}
	
	@Test
	public void queSePuedaAsignarUnPilotoAlVuelo() {
		Aerolinea aerolinea = new Aerolinea("Argentina");
		
		Piloto piloto1 = new Piloto (0, "Juan", "PILOTO", "Boing");
		
		Avion avion = new Avion(0, "B", 100, "Boing");
		Vuelo nuevoVuelo = new Vuelo (0, "BSAS", "BAR", avion);
		
		Boolean pilotoAgregado = aerolinea.agregarUnPilotoAlVuelo(piloto1, nuevoVuelo, avion);
		Boolean resultadoEsperado = true;
		
		assertEquals(resultadoEsperado, pilotoAgregado);
	}
	
	@Test 
	public void queNoSePuedanAsignarMasDeDosPilotosAlVuelo() {
		Aerolinea aerolinea = new Aerolinea("Argentina");
		
		Piloto piloto1 = new Piloto (0, "Juan", "PILOTO", "Boing");
		
		Avion avion = new Avion(0, "B", 100, "Boing");
		Vuelo nuevoVuelo = new Vuelo (0, "BSAS", "BAR", avion);
		
		Boolean pilotoAgregado1 = aerolinea.agregarUnPilotoAlVuelo(piloto1, nuevoVuelo, avion);
		Boolean pilotoAgregado2 = aerolinea.agregarUnPilotoAlVuelo(piloto1, nuevoVuelo, avion);
		Boolean pilotoAgregado3 = aerolinea.agregarUnPilotoAlVuelo(piloto1, nuevoVuelo, avion);
		
		Boolean resultadoEsperado = false;
		Boolean resultado = pilotoAgregado3;
		
		assertEquals(resultadoEsperado, resultado);
	}
	
	@Test
	public void queSePuedaAsignarUnaAzafataAlVuelo() {
		Aerolinea aerolinea = new Aerolinea("Argentina");
		
		Azafata azafata1 = new Azafata (0, "Juana", "AZAFATA");
		
		Avion avion = new Avion(0, "B", 100, "Boing");
		Vuelo nuevoVuelo = new Vuelo (0, "BSAS", "BAR", avion);
		
		Boolean azafataAgregada = aerolinea.agregarUnaAzafataAlVuelo(azafata1, nuevoVuelo, avion);
		Boolean resultadoEsperado = true;
		
		assertEquals(resultadoEsperado, azafataAgregada);
	}

	@Test 
	public void queNoSePuedanAsignarMasDeCuatroAzafatasAlVuelo() {
		Aerolinea aerolinea = new Aerolinea("Argentina");
		
		Azafata azafata1 = new Azafata (0, "Juana", "AZAFATA");
		
		Avion avion = new Avion(0, "B", 100, "Boing");
		Vuelo nuevoVuelo = new Vuelo (0, "BSAS", "BAR", avion);
		
		Boolean azafataAgregada1 = aerolinea.agregarUnaAzafataAlVuelo(azafata1, nuevoVuelo, avion);
		Boolean azafataAgregada2 = aerolinea.agregarUnaAzafataAlVuelo(azafata1, nuevoVuelo, avion);
		Boolean azafataAgregada3 = aerolinea.agregarUnaAzafataAlVuelo(azafata1, nuevoVuelo, avion);
		Boolean azafataAgregada4 = aerolinea.agregarUnaAzafataAlVuelo(azafata1, nuevoVuelo, avion);
		Boolean azafataAgregada5 = aerolinea.agregarUnaAzafataAlVuelo(azafata1, nuevoVuelo, avion);
		
		Boolean resultadoEsperado = false;
		Boolean resultado = azafataAgregada5;
		
		assertEquals(resultadoEsperado, resultado);
	}
	
	@Test
	public void queSePuedaAsignarUnAsientoAUnPasajero() {
		/*
		 * NECESITO:
		 * 	AEROLINEA
		 * 	AVION
		 * 	ASIENTO
		 * 	PASAJERO
		 * 	DONDE GUARDAR LA RELACION
		 * */
	
		Aerolinea aerolinea = new Aerolinea("Argentina");
		Pasajero nuevoPasajero = aerolinea.crearPasajero(0, "Juan");
		Avion avion = new Avion(0, "B", 100, "Boing");
		Asiento asiento = new Asiento(0);

		Boolean asignacionOk = aerolinea.asignarAsientoAPasajero(nuevoPasajero, asiento, avion);
		
		Boolean resultadoEsperado = true;
		
		assertEquals(resultadoEsperado, asignacionOk);
		System.out.println(avion.getAsignaciones());
	}
	
}
