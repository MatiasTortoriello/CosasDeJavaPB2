package Clases;

public class Azafata extends Personal{

	public Azafata(Integer identificador, String nombre, String tipoAzafata) {
		super(identificador, nombre, tipoAzafata);
	}

}
