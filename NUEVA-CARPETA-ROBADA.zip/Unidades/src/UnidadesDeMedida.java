
public class UnidadesDeMedida {
	public static String pasaje(double cantidad, String unidadOrigen, String unidadDestino) {
		double cantidadResultante = cantidad;
		if (unidadOrigen == "km")
			cantidadResultante *= 1000;
		else if (unidadOrigen == "milla")
			cantidadResultante *= 1609;
		else if (unidadOrigen == "pies")
			cantidadResultante /= 3.281;
		if (unidadDestino == "km")
			cantidadResultante /= 1000;
		else if (unidadDestino == "milla")
			cantidadResultante /= 1609;
		else if (unidadDestino == "pies")
			cantidadResultante *= 3.281;

		String retorno = String.format("%.10f", cantidadResultante) + " " + unidadDestino;

		return retorno;
	}
//public static Medida pasaje(double valor,Medida origen,Medida destino)
//{
//	Medida resultado=destino;
//	
//	return resultado;
//	
//}
	public static void main(String[] args) {
		System.out.println(pasaje(1, "mts", "pies"));
	}

}
