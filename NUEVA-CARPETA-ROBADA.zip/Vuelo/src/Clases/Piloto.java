package Clases;

public class Piloto extends Personal {
	
	Integer idAvionQuePilota;

	public Piloto(Integer id, String tipoDePersonal) {
		super(id, tipoDePersonal);
		this.setIdAvionQuePilota(idAvionQuePilota);
	}

	public Integer getIdAvionQuePilota() {
		return idAvionQuePilota;
	}
	
	public void setIdAvionQuePilota(Integer idAvionQuePilota) {
		this.idAvionQuePilota = idAvionQuePilota;
	}
	
	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return super.toString();
	}
	
}
