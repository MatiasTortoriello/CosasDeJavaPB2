import java.util.Objects;

public class Punto implements Comparable<Punto> {
	
	
	private double x, y;

	public Punto() {
		this(1, 1);
	}

	public Punto(double x, double y) {
		this.x = x;
		this.y = y;
	}

	public double getX() {
		return x;
	}

	public void setX(double x) {
		this.x = x;
	}

	public double getY() {
		return y;
	}

	public void setY(double y) {
		this.y = y;
	}

	@Override
	public String toString() {
		return "Punto [x = " + x + " , y = " + y + "]";
	}

	@Override
	public int hashCode() {
		return Objects.hash(x, y);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Punto other = (Punto) obj;
		if (Double.doubleToLongBits(x) != Double.doubleToLongBits(other.x))
			return false;
		if (Double.doubleToLongBits(y) != Double.doubleToLongBits(other.y))
			return false;
		return true;
	}

	@Override
	protected Punto clone() throws CloneNotSupportedException {
		Punto nuevo = new Punto(this.x, this.y);
		return nuevo;
	}
	
	public double distanciaAlCentro()
	{	
		return Math.hypot(x, y);
	}

	@Override
	public int compareTo(Punto o) {
		double diff = this.distanciaAlCentro() - o.distanciaAlCentro();
		return diff > 0 ? 1 : (diff < 0 ? -1 : 0);
	}
	

}
