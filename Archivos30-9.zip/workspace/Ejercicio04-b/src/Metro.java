
public class Metro extends UnidadDeLongitud {
	
	Metro(double cantidad){
		this.cantidad = cantidad;
	}
			
	public double aPie(){
		return this.cantidad * 3.28084;
	}
	
	public double aMilla(){
		return this.cantidad *0.000621371;
	}
	
	public double aKm(){
		return this.cantidad * 0.001;
	}
	
	public double aMetro(){
		return this.cantidad;
	}
	

}
