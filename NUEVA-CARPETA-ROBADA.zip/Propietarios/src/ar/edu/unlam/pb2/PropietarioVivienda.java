package ar.edu.unlam.pb2;

public class PropietarioVivienda {

	Habitante habitante;
	Vivienda vivienda;
	Double porcentaje;
	Integer id;
	
	public PropietarioVivienda(Habitante habitante, Vivienda vivienda, Double porcentaje, Integer id) {
		
		this.id = id;
		this.porcentaje = porcentaje;
		this.habitante = habitante;
		this.vivienda = vivienda;
	}

	public Integer getId() {
		return id;
	}

	public Vivienda getVivienda() {
		return vivienda;
	}

	public Double getPorcentaje() {
		return porcentaje;
	}

}
