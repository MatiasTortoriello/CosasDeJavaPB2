import java.util.LinkedList;
import java.util.List;
import java.util.Random;

public class Tropa extends Unidad {
	private List<Unidad> tropa = new LinkedList<Unidad>();
	int cantidad;
	
	Tropa(){
		this.cantidad = 0;
	}
	
	public void agregarGuerrero(Guerrero guerreroNuevo){
		this.tropa.add(guerreroNuevo);
		this.cantidad++;
	}
		
	public void recibirDanio(){
		if(!activo){
			Guerrero guerreroElegido = seleccionarGuerrero();
			guerreroElegido.recibirDanio();
			if(!guerreroElegido.activo){
				tropa.remove(guerreroElegido);
			}
		}
	}
	
	public Guerrero seleccionarGuerrero() {
	    Random rand = new Random();
	    Guerrero guerreroRandom = tropa.get(rand.nextInt(tropa.size()));
	    return guerreroRandom;
	}
	
}
