package ar.unlam.figuras;

import ar.unlam.figuras.Figura;

import static org.junit.Assert.*;

import java.util.ArrayList;
import java.util.List;

import org.hamcrest.core.IsInstanceOf;
import org.junit.Test;

public class TestFiguras {

	@Test
	public void test(){
//		Figura figura = new Rectangulo("rojo", 1.0, 2.0);
//		figura = new Circulo("blanco", 6.0);
		
		Rectangulo rectangulo = new Rectangulo ("Rojo", 1.0, 2.0);
		Rectangulo rectangulo2 = new Rectangulo ("Azul", 3.0, 2.0);
		Circulo circulo = new Circulo ("Blanco", 6.8);
		
		List<Figura> figuras = new ArrayList<>();
		
		figuras.add(rectangulo);
		figuras.add(rectangulo2);
		figuras.add(circulo);
		
		for (Figura figura : figuras) {
			if(figura.getTipo().equals("Rectangulo")){
				System.out.println(((Rectangulo)figura).getAltura());	
			}
		}
	
	}
	
}
	
	
	
