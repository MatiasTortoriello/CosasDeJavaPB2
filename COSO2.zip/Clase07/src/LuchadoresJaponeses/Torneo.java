package LuchadoresJaponeses;


public class Torneo {

	private Luchador[] luchadores;

	public Torneo(Luchador[] luchadores) {
		// TODO Auto-generated constructor stub
		this.luchadores = luchadores;
	}
	
	public int[] calcularDominios() {
		int cantDominios;
		int[] dominios = new int[luchadores.length];
		
		for (int i = 0; i < luchadores.length; i++) {
			
			cantDominios = 0;
			
			for (int j = 0; j < luchadores.length; j++) {
				if(i!=j) {
					if(luchadores[i].dominaA(luchadores[j])) {
						cantDominios++;
					}
				}
			}
			
			dominios[i] = cantDominios;
		}
		
		return dominios;
	}
	
}
