package Clases;

public class Personal {
	
	private Integer id;
	private String tipoDePersonal;
	
	public Personal (Integer id, String tipoDePersonal){
		this.id = id;
		this.tipoDePersonal = tipoDePersonal;
	}

	public Integer getId() {
		return id;
	}
	
	public String getTipoDePersonal() {
		return tipoDePersonal;
	}

}


