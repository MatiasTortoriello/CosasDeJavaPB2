package unlam.practicame;

public class Transaccion {

}
