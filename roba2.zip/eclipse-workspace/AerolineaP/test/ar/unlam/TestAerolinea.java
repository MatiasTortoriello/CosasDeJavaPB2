package ar.unlam;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

import java.time.LocalDateTime;

import org.junit.Test;

public class TestAerolinea {
	@Test
	public void queSePuedaAgregarUnVueloAUnaAerolinea() {
		Aerolinea aa = new Aerolinea("aerolineas");
		LocalDateTime horaDespegue = LocalDateTime.of(2022, 07, 30, 12, 15, 00);
		LocalDateTime horaAterrizaje = LocalDateTime.of(2022, 07, 30, 14, 35, 00);
		String aeropuertoOrigen = "AEP";
		String aeropuertoDestino = "BRC";
		Integer idVuelo = 1;
		Vuelo vuelo = new Vuelo(idVuelo, aeropuertoOrigen, aeropuertoDestino, horaDespegue, horaAterrizaje, 5000.0);
		assertTrue(aa.agregar(vuelo));
	}
@Test
public void queSePuedaVenderUnPasajeAUnVuelo() {
	Aerolinea aa = new Aerolinea("aerolineas");
	LocalDateTime horaDespegue = LocalDateTime.of(2022, 07, 30, 12, 15, 00);
	LocalDateTime horaAterrizaje = LocalDateTime.of(2022, 07, 30, 14, 35, 00);
	String aeropuertoOrigen = "AEP";
	String aeropuertoDestino = "BRC";
	Integer idVuelo = 1;
	Vuelo vuelo = new Vuelo(idVuelo, aeropuertoOrigen, aeropuertoDestino, horaDespegue, horaAterrizaje,5000.0);
	Integer dni = 1;	
	Pasajero pasajero = new PasajeroVip(dni);
	Pasaje pasaje = new Pasaje(vuelo,pasajero);
	
	assertTrue(aa.agregar(vuelo));
	assertNotNull(pasaje);
	assertEquals(4500,pasaje.getPrecio(),0.01);
	
}
}
