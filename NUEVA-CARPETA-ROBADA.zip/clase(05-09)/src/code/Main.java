package code;

public class Main {

	public static void main(String[] args) {
		
		Paquete p1 = new Paquete(0.4, 5, "Rosario");
		Paquete p2 = new Paquete(0.2, 25, "Rosario");
		Paquete p3 = new Paquete(0.4, 15, "Rosario");
		
		Bici bici1 = new Bici();
		System.out.println(bici1.cargarPaquete(p1));
		
		Moto moto1 = new Moto();
		System.out.println(moto1.cargarPaquete(p1));
		System.out.println(moto1.cargarPaquete(p2));
		System.out.println(moto1.cargarPaquete(p3));
	}

}
