package Unidades;

public class Metro extends UnidadDeLongitud {

	//private BigDecimal valor;

	public Metro(BigDecimal valor) {
		super(valor);
		this.valor = valor;
	}
	
	@Override
	public Metro toMetro() {
		return this;
	}
	
	@Override
	public Kilometro toKilometro() {
		return new Kilometro(this.valor / 1000);
	}
	
	@Override
	public Pie toPie() {
		return new Pie(this.valor * 3.281);
	}
	
	@Override
	public Milla toMilla() {
		return new Milla(this.valor / 1609);
	}

	@Override
	public String toString() {
		return this.valor + " Metros";
	}
	
	@Override
	public Metro Sumar(UnidadDeLongitud otra) {
		return new Metro(this.valor + otra.toMetro().valor);
	}

	@Override
	public UnidadDeLongitud crear(BigDecimal valor) {
		return new Metro(valor);
	}

	@Override
	public UnidadDeLongitud pasarAMiUnidad(UnidadDeLongitud otra) {
		return otra.toMetro();
	}
	
}
