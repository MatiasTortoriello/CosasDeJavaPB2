package edu.unlam.progava.triatlon;

public class Galgo implements Corredor {

	@Override
	public void correr() {
		
	}
	
}
