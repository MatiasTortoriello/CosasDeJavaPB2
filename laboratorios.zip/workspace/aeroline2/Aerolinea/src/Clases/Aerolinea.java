package Clases;

public class Aerolinea {
	
	private String nombre;

	public Aerolinea(String nombre) {
		this.nombre = nombre;
	}

	public String getNombre() {
		return this.nombre;
	}

	public Pasajero crearPasajero(int identificadorPasajero, String nombrePasajero) {
		Pasajero pasajero = new Pasajero (identificadorPasajero, nombrePasajero);
		return pasajero;
	}

	public Personal crearPersonal(Integer identificador, String nombrePersonal, String tipoPersonal) {
		Personal nuevoPersonal = null;
		if(tipoPersonal.toUpperCase().equals("PILOTO")) {
			Personal nuevoPiloto = new Piloto(identificador, nombrePersonal, tipoPersonal, "Boing");
			nuevoPersonal = nuevoPiloto;
		} if (tipoPersonal.toUpperCase().equals("AZAFATA")) {
			Personal nuevaAzafata = new Azafata(identificador, nombrePersonal, tipoPersonal);
			nuevoPersonal = nuevaAzafata;
		}
		return nuevoPersonal;
	}

	public Avion crearAvion(Integer identificador, String modelo, Integer capacidad, String tipoAvion) {
		Avion nuevoAvion = new Avion(identificador, modelo, capacidad, tipoAvion);
		return nuevoAvion;
	}

	public Vuelo crearVuelo(Integer identificador, String ciudadOrigen, String ciudadDestino, Avion avion) {
		Vuelo nuevoVuelo = new Vuelo (identificador, ciudadOrigen, ciudadDestino, avion);
		return nuevoVuelo;
	}

	public Boolean agregarUnPilotoAlVuelo(Piloto piloto1, Vuelo nuevoVuelo, Avion avion) {
		boolean registroExitoso = false;
		if(piloto1.getTipoAvionQuePilota().equals(avion.getTipoAvion()) && nuevoVuelo.getCantidadPilotos() < 2) {
			nuevoVuelo.agregarPilotoAlAvion(piloto1);
			registroExitoso = true;
		}
		return registroExitoso;
	}

	public Boolean agregarUnaAzafataAlVuelo(Azafata azafata1, Vuelo nuevoVuelo, Avion avion) {
		boolean registroExitoso = false;
		if(nuevoVuelo.getCantidadAzafatas() < 4) {
			nuevoVuelo.agregarAzafataAlAvion(azafata1);
			registroExitoso = true;
		}
		return registroExitoso;
	}

	public Boolean asignarAsientoAPasajero(Pasajero nuevoPasajero, Asiento asiento, Avion avion) {
		boolean asignacion = false; 
		Asignacion nuevaAsignacion = new Asignacion(nuevoPasajero, asiento);
		if((nuevaAsignacion.getNuevoPasajero().getIdentificador() == nuevoPasajero.getIdentificador()) 
				&& (nuevaAsignacion.getAsiento().getIdentificador() == asiento.getIdentificador())) {
			nuevaAsignacion.getAsiento().setVacio(false);
			avion.agregarAsignacion(nuevaAsignacion);
			asignacion = true;
		}
		return asignacion;
	}


}
