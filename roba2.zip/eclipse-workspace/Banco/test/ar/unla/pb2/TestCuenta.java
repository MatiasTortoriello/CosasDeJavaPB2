package ar.unla.pb2;

import static org.junit.Assert.*;

import org.junit.Test;
public class TestCuenta {

	@Test
	public void queDadaUnaCuentaConSaldoMilAlExtraer300SuSaldoSera700() {
		Integer id = 1;
		Cliente cliente = new Cliente(5, "Juana");
		Double monto = 1000.0;
		Cuenta cuenta = new Cuenta(id, cliente, monto);
		Boolean extraccionExitosa = cuenta.extraer(300.0);
		Double valorEsperado = 700.0;
		Double valorObtenido = cuenta.getSaldoInicial();
		assertEquals(valorEsperado, valorObtenido);
		
	}

}
