package unlam;
 
import java.util.Set;
import java.util.TreeSet;

 
 

public class SedeOlimpica implements Comparable<SedeOlimpica> {
	private Integer id ; 
	String nombre;
	private Set<Complejo> complejos;

	public SedeOlimpica(Integer id, String nombre) {
		// TODO Auto-generated constructor stub
		this.id = id; 
		this.nombre = nombre;
		this.complejos = new TreeSet<>();
	}

	public void agregarComplejo(Complejo complejo) {
		// TODO Auto-generated method stub
		this.complejos.add(complejo);
 
	}

	public Integer cantidadDeComplejosXsede() {
		// TODO Auto-generated method stub
		return complejos.size();
	}

	@Override
	public int compareTo(SedeOlimpica o) {
		// TODO Auto-generated method stub
		return 0;
	}

 
 
 

}
