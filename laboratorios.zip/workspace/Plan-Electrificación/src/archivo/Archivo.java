package archivo;

import java.io.File;
import java.util.Scanner;


public class Archivo {
	
	private String nombre;
	public Archivo(String nombre) {
		this.nombre = nombre;
	}
	
	public void leerArchivo() {
		File file = null;
		Scanner scanner = null;
		
		try {
			
			file = new File("src/in/" + this.nombre + ".in");
			scanner = new Scanner(file);
			
	
		} catch(Exception e) {
			e.printStackTrace();
		} finally {
			scanner.close();
		}
	}
	
}