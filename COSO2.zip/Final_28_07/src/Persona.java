
public class Persona {
	private String nombre;
	private Double peso;
	private Double altura;
	private Double 
}
