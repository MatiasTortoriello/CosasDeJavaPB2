package Aceitunas;

public class Tiro {
	
	private Punto punto;
	private double dist;
	
	public Tiro(Punto punto) {
		super();
		this.punto = punto;
		this.dist = punto.getDistancia();
	}

	public double getDist() {
		return dist;
	}
	
	public int jugador () {
		if(this.punto.getX() > 0)
			return 1;
		else return 2;
	}

}
