package luchador;

public class Luchador {
	private int peso;
	private int altura;
	private int cantSuperados;
	
	
	public Luchador(int peso, int altura, int cantSuperados) {
		super();
		this.peso = peso;
		this.altura = altura;
		this.cantSuperados = cantSuperados;
	}

	public boolean superaA(Luchador otro) {
		if(this.peso > otro.peso && this.altura > otro.altura)
			return true;
		if(this.peso == otro.peso && this.altura > otro.altura)
			return true;		
		if(this.peso > otro.peso && this.altura == otro.altura)
			return true;
		
		return false;
	}
	
}
