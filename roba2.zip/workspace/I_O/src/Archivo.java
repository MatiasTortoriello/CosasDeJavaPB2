import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Locale;
import java.util.Scanner;

public class Archivo {

	private String nombre;

	// Constructor
	public Archivo(String nombre)A {

		this.nombre = nombre; // modifico el atributo nombre del objeto Archivo
	}

	public double[] leerArchivo() {

		Scanner scanner = null; // obejto tipo scanner
		double[] datos = null;

		try {
			File file = new File(this.nombre + ".in"); // obejeto tipo file
			scanner = new Scanner(file); // leo archivo

			// Especifica la configuraci�n regional que se va a utilizar
			// Para la configuraci�n regional de Argentina, utilizar:
			// scanner.useLocale(new Locale("es_AR"));
			scanner.useLocale(Locale.ENGLISH);

			int cant = scanner.nextInt(); // next te dice que lees
			datos = new double[cant];

			if (cant == 0) {
				return 0;
			}

			double n = scanner.nextDouble();
			double max = n;
			double min = n;
			double suma = n;

			while (scanner.nextDouble()) { // terminar
				double n = scanner.nextDouble();
				datos[i] = n;

				if (n > max)
					max = n;
				if (n < min)
					min = n;
				suma += n;
			}

			for (int i = 0; i < cant; i++) {
				System.out.println(datos[i]);
			}

		} catch (Exception e) {
			e.printStackTrace(); // muestra errores enlistados

		} finally {
			// Cerrar el archivo, eso es mucho muy importante
			scanner.close();
		}

		return datos;
	}

	/*
	 * public double[] leerArchivo() {
	 * 
	 * Scanner scanner = null; //obejto tipo scanner double[] datos = null;
	 * 
	 * try { File file = new File(this.nombre + ".in"); //obejeto tipo file
	 * scanner = new Scanner(file); // leo archivo
	 * 
	 * // Especifica la configuraci�n regional que se va a utilizar // Para la
	 * configuraci�n regional de Argentina, utilizar: // scanner.useLocale(new
	 * Locale("es_AR")); scanner.useLocale(Locale.ENGLISH);
	 * 
	 * int cant = scanner.nextInt(); //next te dice que lees datos = new
	 * double[cant]; for (int i = 0; i < cant; i++) { double n =
	 * scanner.nextDouble(); datos[i] = n; }
	 * 
	 * for (int i = 0; i < cant; i++) { System.out.println(datos[i]); }
	 * 
	 * } catch (Exception e) { e.printStackTrace(); //muestra errores enlistados
	 * 
	 * } finally { // Cerrar el archivo, eso es mucho muy importante
	 * scanner.close(); }
	 * 
	 * 
	 * 
	 * return datos; }
	 * 
	 * public void guardarArchivo(double[] datos) { FileWriter file = null;
	 * //creo objeto para poder escribir PrintWriter printerWriter = null;
	 * //hago que se escriba con print
	 * 
	 * try { file = new FileWriter(this.nombre + ".out"); printerWriter = new
	 * PrintWriter(file);
	 * 
	 * for (int i = 0; i < datos.length; i++) { // Imprime los datos y hace un
	 * salto de linea printerWriter.println(datos[i]); //metodo de PrintWritter
	 * }
	 * 
	 * } catch (Exception e) { e.printStackTrace();
	 * 
	 * } finally { if (file != null) { try { file.close(); } catch (IOException
	 * e) { e.printStackTrace(); } } } }
	 * 
	 * public double[] calculos(double[] numeros) {
	 * 
	 * if(numeros.length == 0) { return numeros; }
	 * 
	 * double max = numeros[0]; double min = numeros[0]; double suma
	 * =numeros[0]; for (int i = 1; i < numeros.length; i++) { if (numeros[i] >
	 * max) max = numeros[i]; if (numeros[i] < min) min = numeros[i]; suma+=
	 * numeros[i]; }
	 * 
	 * //double[] resultados = new doule[3]
	 * 
	 * double[] resultados = {max, min, suma/numeros.length}; return resultados;
	 * }
	 */
	public static void main(String[] args) {
		Archivo a = new Archivo("uno");
		double[] datos = a.leerArchivo();
		double[] resultados = a.calculos(datos);
		a.guardarArchivo(resultados);
	}

}
