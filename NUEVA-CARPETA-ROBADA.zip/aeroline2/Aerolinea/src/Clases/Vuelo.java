package Clases;

import java.util.ArrayList;
import java.util.List;

public class Vuelo {
	
	private Integer identificador;
	private String ciudadOrigen;
	private String ciudadDestino;
	private List <Personal> personal;
	private Avion avion;

	public Vuelo(Integer identificador, String ciudadOrigen, String ciudadDestino, Avion avion) {
		this.identificador = identificador;
		this.ciudadOrigen = ciudadOrigen;
		this.ciudadDestino = ciudadDestino;
		this.personal = new ArrayList <Personal>();
		this.avion = avion;
	}
	
	public Integer getCantidadPilotos() {
		Integer cantidadPilotos = 0;
		for (Personal personal : personal) {
			if(personal.getTipoPersonal().equals("PILOTO")) {
				cantidadPilotos++;
			}
		}
		return cantidadPilotos;
	}
	
	public Integer getCantidadAzafatas() {
		Integer cantidadAzafatas = 0;
		for (Personal personal : personal) {
			cantidadAzafatas++;
		}
		return cantidadAzafatas;
	}

	public Integer getIdentificador() {
		return identificador;
	}

	public void setIdentificador(Integer identificador) {
		this.identificador = identificador;
	}

	public String getCiudadOrigen() {
		return ciudadOrigen;
	}

	public void setCiudadOrigen(String ciudadOrigen) {
		this.ciudadOrigen = ciudadOrigen;
	}

	public String getCiudadDestino() {
		return ciudadDestino;
	}

	public void setCiudadDestino(String ciudadDestino) {
		this.ciudadDestino = ciudadDestino;
	}

	public List<Personal> getPersonal() {
		return personal;
	}

	public void setPersonal(List<Personal> personal) {
		this.personal = personal;
	}

	public Avion getAvion() {
		return avion;
	}

	public void setAvion(Avion avion) {
		this.avion = avion;
	}

	public void agregarPilotoAlAvion(Piloto piloto1) {
		personal.add(piloto1);
	}

	public void agregarAzafataAlAvion(Azafata azafata1) {
		personal.add(azafata1);
	}
	
	

}
