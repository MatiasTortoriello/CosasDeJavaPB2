package graph.coloring.order;

public class Order {
	
	private int[] order;
	
	public Order(int size) {
		order = new int[size];
	}
	
	public int[] getOrder() {
		return order;
	}

}
