package ejer0;

public class ejer0 {

	public boolean comprobarDiagonal()
	{
		return true;
	}
}
