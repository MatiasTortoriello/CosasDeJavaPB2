public abstract class Unidad {
	public abstract void atacar(Unidad ente);
	public abstract void recibirDanio(int danio);
}
