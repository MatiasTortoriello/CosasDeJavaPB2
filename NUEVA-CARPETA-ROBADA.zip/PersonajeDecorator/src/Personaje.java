
public class Personaje extends Unidad{
	
	public Personaje(){
		this.salud = 100;
		this.danio = 20;
	}

	
}
