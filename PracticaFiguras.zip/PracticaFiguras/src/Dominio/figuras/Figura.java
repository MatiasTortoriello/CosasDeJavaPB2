package Dominio.figuras;

public abstract class Figura {
	private String nombre;
	private Double area;
	private Integer perimetro;
	
	public Figura(String nombre, Double area, Integer perimetro) {
		this.nombre = nombre;
		this.area = area;
		this.perimetro = perimetro;
	}
	public String getNombre() {
		return nombre;
	}
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}
	public Double getArea() {
		return area;
	}
	public void setArea(Double area) {
		this.area = area;
	}
	public Integer getPerimetro() {
		return perimetro;
	}
	public void setPerimetro(Integer perimetro) {
		this.perimetro = perimetro;
	}

	public abstract Double calcularArea();
	
}
