package carrito;

public class PackDescuento extends Pack {
	double porcDescuento;
	public PackDescuento() {
		// TODO Auto-generated constructor stub
	}

}
