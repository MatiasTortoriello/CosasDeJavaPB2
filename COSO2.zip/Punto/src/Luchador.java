
public class Luchador {
	
	int altura, peso;
	
	public Luchador()
	{
		this.altura = this.peso = 0;
	}
	public Luchador(int altura, int peso)
	{
		this.altura = altura;
		this.peso = peso;
	}
	public int getAltura() {
		return altura;
	}
	public void setAltura(int altura) {
		this.altura = altura;
	}
	public int getPeso() {
		return peso;
	}
	public void setPeso(int peso) {
		this.peso = peso;
	}
	
	int dominaA(Luchador otro)
	{	
		int resAltura = this.altura - otro.altura;
		int resPeso = this.peso - otro.peso;
		
		if( resAltura > 0 && resPeso > 0 )
		{
			return 1;
		}
		else if( resAltura == resPeso )
		{
			return 0;
		}
		else if ( resAltura == 0 || resPeso == 0 )	
		{
			if( resAltura == 0 )
			{
				return resPeso;
			}
			else
			{
				return resAltura;
			}
		}
		else
		{
			return -1;
		}
	}
}
