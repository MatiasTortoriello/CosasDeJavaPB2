package Dominio.figuras;

public class Paralelepipedo extends Figura{

}
