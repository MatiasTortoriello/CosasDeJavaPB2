package ar.edu.unlam.pb2.eva03;

public class Poliza {
	

	private Integer numeroDePoliza;
	private Persona asegurado;
	private Double sUMA_ASEGURADA;
	private Double prima;
	private Double premio;
	
	public Poliza(Integer nUMERO_DE_POLIZA, Persona asegurado, Double sUMA_ASEGURADA, Double pRIMA){
		this.numeroDePoliza=nUMERO_DE_POLIZA;
		this.asegurado=asegurado;
		this.sUMA_ASEGURADA=sUMA_ASEGURADA;
		this.prima=pRIMA;
		this.premio=this.prima+(((prima*20))/100);
	}
	


	public Integer getNumeroDePoliza() {
		return numeroDePoliza;
	}

	public void setNumeroDePoliza(Integer numeroDePoliza) {
		this.numeroDePoliza = numeroDePoliza;
	}

	public Persona getAsegurado() {
		return asegurado;
	}

	public void setAsegurado(Persona asegurado) {
		this.asegurado = asegurado;
	}

	public Double getsUMA_ASEGURADA() {
		return sUMA_ASEGURADA;
	}

	public void setsUMA_ASEGURADA(Double sUMA_ASEGURADA) {
		this.sUMA_ASEGURADA = sUMA_ASEGURADA;
	}

	public Double getPrima() {
		return prima;
	}

	public void setPrima(Double prima) {
		this.prima = prima;
	}

	public Double getPremio() {
		return premio;
	}

	public void setPremio(Double premio) {
		this.premio = premio;
	}



	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((numeroDePoliza == null) ? 0 : numeroDePoliza.hashCode());
		return result;
	}



	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (!(obj instanceof Poliza))
			return false;
		Poliza other = (Poliza) obj;
		if (numeroDePoliza == null) {
			if (other.numeroDePoliza != null)
				return false;
		} else if (!numeroDePoliza.equals(other.numeroDePoliza))
			return false;
		return true;
	}




	
}
