package ar.unlam.calculadora;

public class Calculadora {

	public Integer sumar(Integer operador1, Integer operador2) {
		return operador1 + operador2;
	}

	public Double dividir(Double operador1, Double operador2) {
		return (double) (operador1 / operador2);
	}

	public Double porcentaje(Double numero, Double porcentaje) {
		return this.dividir(numero*porcentaje, (double) 100);
	}

	public Double multiplicar(Double operador1, Double operador2) {
		return operador1 * operador2;
	}

	
}
