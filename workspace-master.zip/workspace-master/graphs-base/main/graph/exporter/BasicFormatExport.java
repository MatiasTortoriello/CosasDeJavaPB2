package graph.exporter;

import java.io.File;

import graph.Graph;

public class BasicFormatExport implements Exporter {

	@Override
	public void export(Graph graph, File file) {
		
		// TODO: Implement me!
		
	}

}
