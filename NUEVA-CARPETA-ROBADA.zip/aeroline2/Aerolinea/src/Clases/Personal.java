package Clases;

import java.util.ArrayList;
import java.util.List;

public class Personal extends Persona{

	String tipoPersonal;
	
	List <Piloto> pilotos = new ArrayList <Piloto>();
	List <Azafata> azafatas = new ArrayList <Azafata>();
	
	public Personal(Integer identificador, String nombrePersonal, String tipoPersonal) {
		super(identificador, nombrePersonal);
		this.tipoPersonal = tipoPersonal;
	}
	
	public String getTipoPersonal() {
		return this.tipoPersonal;
	}
	
	public void setTipoPersonal(String tipoPersonal) {
		this.tipoPersonal = tipoPersonal;
	}


	
	/***** AZAFATA ******/

	public void setAzafatas(List<Azafata> azafatas) {
		this.azafatas = azafatas;
	}
	
	public List<Azafata> getAzafatas() {
		return azafatas;
	}
	
	public Integer getCantidadAzafatas() {
		return this.azafatas.size();
	}
	
	/***** PILOTO ******/
	
	public void setPilotos(List<Piloto> pilotos) {
		this.pilotos = pilotos;
	}
	
	public List<Piloto> getPilotos() {
		return pilotos;
	}
		
	public Integer getCantidadPilotos() {
		return this.pilotos.size();
	}
}
