package archivo;

import java.io.File;
import java.util.Scanner;

import luchador.Luchador;

public class Archivo {
	private String nombre;

	public Archivo(String nombre) {
		super();
		this.nombre = nombre;
	}
	
	public Luchador[] leerArchivo() {
		Scanner scanner = null;
		Luchador[] luchadores = null;
		
		try {
			File file = new File(this.nombre + ".in");
			scanner = new Scanner(file);
			
			int cantReg = scanner.nextInt();
			luchadores = new Luchador[cantReg];
			
			for(int i=0; i < cantReg; i++) {
				int peso = scanner.nextInt();
				int altura = scanner.nextInt();
				luchadores[i] = new Luchador(peso, altura, 0);
			}
		}catch(Exception e) {
			e.printStackTrace();
		}finally {
			scanner.close();
		}
		
		return luchadores;
	}
	
	
}
