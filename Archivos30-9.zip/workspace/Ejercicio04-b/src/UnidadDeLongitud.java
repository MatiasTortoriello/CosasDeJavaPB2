
public abstract class UnidadDeLongitud {
	
	protected double cantidad;
		
	public abstract double aMetro();
	
	public abstract double aPie();
	
	public abstract double aMilla();
	
	public abstract double aKm();
	
	public double sumar(String objeto, double cantidad){
		if(objeto.equals("Metro")){
			this.cantidad += 
		}else if (objeto.equals("Pie")){
		
		}else if (objeto.equals("Kilometro")){
		
		}else if (objeto.equals("Milla")){
			
		}
	}
	
	
	
}
