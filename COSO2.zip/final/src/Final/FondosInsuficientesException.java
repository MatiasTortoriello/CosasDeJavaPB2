package Final;

public class FondosInsuficientesException extends Exception{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	
	public FondosInsuficientesException(){
		
	}


	public String getMessage(double cantidad) {
		return "Fondos Insuficientes" + cantidad;
		
	}

}
