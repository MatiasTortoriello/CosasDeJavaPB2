package finalPrograAv;

public class Velador implements ArtefactoElectronico{
	
	private int cantHorasEncendido;
	private int consumoXHora = 100;S

	public Velador(int cantHorasEncendido) {
		
		this.cantHorasEncendido = cantHorasEncendido;
	}

	@Override
	public int getConsumo() {
		
		int consumoTotal = this.consumoXHora * this.cantHorasEncendido;
		return consumoTotal;
	}
	
	
}
