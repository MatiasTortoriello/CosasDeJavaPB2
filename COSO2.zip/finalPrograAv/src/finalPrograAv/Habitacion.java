package finalPrograAv;

import java.util.ArrayList;

public class Habitacion {
	
	public Habitacion(ArrayList<ArtefactoElectronico> bombillas) {
		this.setBombillas(bombillas);
	}

	public ArrayList<ArtefactoElectronico> getBombillas() {
		return bombillas;
	}

	public void setBombillas(ArrayList<ArtefactoElectronico> bombillas) {
		this.bombillas = bombillas;
	}

	private ArrayList<ArtefactoElectronico> bombillas = new ArrayList<ArtefactoElectronico>();
}
