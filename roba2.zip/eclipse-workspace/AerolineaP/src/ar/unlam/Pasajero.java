package ar.unlam;

public class Pasajero {

}
