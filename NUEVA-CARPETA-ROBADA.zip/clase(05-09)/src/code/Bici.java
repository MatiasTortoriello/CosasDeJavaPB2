package code;

import java.util.ArrayList;

public class Bici extends Transporte{

	private final int paquetesMax = 1;
	private final double pesoMax = 10;
	private final double dimensionMax = 1;
	
	public Bici() {
		paquetes = new ArrayList<Paquete>();
	}
	
	@Override
	public boolean cargarPaquete(Paquete p) {
		
		if(paquetes.size() < paquetesMax && p.getPeso() <= pesoMax && p.getTam() <= dimensionMax ){
			paquetes.add(p);
			return true;
		}
		return false;
		
	}

}
