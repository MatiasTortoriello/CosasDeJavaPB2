package excepcion;

import java.io.IOException;

public class Circulo {

	double radio;
	
//	public Circulo(double radio) throws RadioNegativoException, IOException{
//		//aca es recomendable usar expecciones porque no puedo poner otra cosa que no sea la que me pide el usuario
//		if(radio < 0){
//			throw new RadioNegativoException();
//		}
//		throw new IOException();
//	}
	
	public Circulo(double radio) throws RadioNegativoException{
		//aca es recomendable usar expecciones porque no puedo poner otra cosa que no sea la que me pide el usuario
		setRadio(radio);
	}
	
	public void setRadio(double radio) throws RadioNegativoException {
		if(radio < 0){
			throw new RadioNegativoException();
		}
		
		this.radio = radio;			
		
	}
}
