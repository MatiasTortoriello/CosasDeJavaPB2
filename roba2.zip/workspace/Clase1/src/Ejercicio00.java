
public class Ejercicio00 {

		public boolean comprobarDiagonal(int [][] matriz){
			int sum=matriz[0][0];
			for(int i=1;i<matriz.length;i++){
				if(matriz[i][i]==sum)
					sum = sum+matriz[i][i];
				else
					return false;
			}
			return true;
		}
		 public static void main(String[] args) {
			int [][] matrix = {{1,2,3},{4,1,6},{7,8,2}};
			Ejercicio00 miEjercicio = new Ejercicio00();
			System.out.println(miEjercicio.comprobarDiagonal(matrix));
		}
}


