package unlam.practicame;

public class Cliente {
	int cuit;
	String nombre;
	Dispositivo dispositivo;

	public Cliente (int cuit, String nombre, Dispositivo dispositivo){
	this.cuit = cuit;
	this.nombre= nombre;
	this.dispositivo= dispositivo;
	}

}
