package domain;

public class CuentaCorriente extends Cuenta {

	public Double limiteDescubierto;
	
	public CuentaCorriente(Integer nroCuenta, String nombre, String apellido, Integer dni, Double limite) {
		super(nroCuenta, nombre, apellido, dni);
		this.limiteDescubierto = limite;
	}

	public Double getLimiteDescubierto() {
		return limiteDescubierto;
	}

	public void setLimiteDescubierto(Double limiteDescubierto) {
		this.limiteDescubierto = limiteDescubierto;
	}

	public Boolean extraer(Double monto){
		if(monto <= getSaldo() + limiteDescubierto){
			setSaldo(getSaldo() - monto);
			return true;
		}
		return false;
	}
	
}
