package ar.unlam.edu.pb2.interfaz;

public class CuentaGanado {

	private Integer contador;
	private Integer limite=9;

	public CuentaGanado() {
		this.contador=0;
	}

	public Integer getContador() {
		
		return this.contador;
	}
	
	public void sumar(){
		if(contador< limite) {
			contador++;
		} else {
			contador=0;
		}
	}

	public void reset() {
     if(contador!=0){
    	 
     }
		
	}

}
