
public abstract class Viento  extends Instrumento implements Afinable,Lustrable{
	
	private int tipoViento;
	
	public Viento(String name, int tono, String descr,int tp) {
		super(name, tono, descr);
		this.tipoViento=tp;
		
	}
	
	

}
