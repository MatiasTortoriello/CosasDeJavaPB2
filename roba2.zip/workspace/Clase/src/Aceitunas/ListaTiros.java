package Aceitunas;

import java.util.ArrayList;
import java.util.List;

public class ListaTiros {
	
	List<Tiro> tiros;

	public ListaTiros(int tam) {
		super();
		this.tiros = new ArrayList<Tiro>(tam);
	}
	
	public double getRadioMenor () {
		int puntos = 0;
		for (int i = 0; i < tiros.size() && puntos <= 0; i++) {
			if (tiros.get(i).jugador() == 1)
				puntos ++;
			else 
				puntos --;
		}
		return puntos > 0 ? puntos : 0; 
	}

}
