package Clases;

public class Persona {
	
	protected Integer identificador;
	protected String nombre;
	
	public Persona(Integer identificador, String nombre) {
		this.identificador = identificador;
		this.nombre = nombre;
	}

	public Integer getIdentificador() {
		return this.identificador;
	}
	
	public String getNombre() {
		return this.nombre;
	}
	
	@Override
	public String toString() {
		return "Identificador: " + this.getIdentificador() + " Nombre: " + this.getNombre();
	}
}
