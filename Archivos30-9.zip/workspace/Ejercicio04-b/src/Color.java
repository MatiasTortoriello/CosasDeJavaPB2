
public enum Color {
	ROJO,
	AZUL,
	AMARILLO,
	VERDE,
	BLANCO,
	NEGRO,
	GRIS_CLARO,
	GRIS_OSCURO
}
