package ar.edu.unlam.pb2;

public class mascotaDuplicadaException extends Exception {
	private String mensaje;

	public mascotaDuplicadaException(String mensaje) {
		this.mensaje = mensaje;
	}
	
	

}
