package ar.unla.pb2;

import java.util.ArrayList;

public class Banco {

	private String nombreBanco;
	private ArrayList<Cuenta> cuentas; // new Arraylist<>();

	public Banco(String nombreBanco) {
		// TODO Auto-generated constructor stub
		this.nombreBanco = nombreBanco;
		this.cuentas = new ArrayList<>();
	}

	public void agregarCuenta(Cuenta cuenta) {
		// TODO Auto-generated method stub
		this.cuentas.add(cuenta);

	}

	public Integer obtenerCantidadDeCuentas() {
		// TODO Auto-generated method stub

		return this.cuentas.size();
	}

	public Cuenta buscarCuentaPorId(Integer idCliente) {
		
		// TODO Auto-generated method stub
		for (int i = 0; i < cuentas.size(); i++) {
			if (this.cuentas.get(i).getIdCuenta().equals(idCliente))
				return this.cuentas.get(i);
		}
		for (Cuenta cuenta : cuentas) {
			if(cuenta.getIdCuenta().equals(idCliente))
				return cuenta;
		}
		return null;
	}
	
}
