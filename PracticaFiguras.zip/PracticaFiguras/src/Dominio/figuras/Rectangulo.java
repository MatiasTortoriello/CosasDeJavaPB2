package Dominio.figuras;

public class Rectangulo extends Figura{
	private Double base;
	private Double altura;
	
	public Rectangulo(String nombre, Double area, Integer perimetro,Double base, Double altura) {
		super(nombre, area, perimetro);
		this.base = base;
		this.altura = altura;
	}

	@Override
	public Double calcularArea() {
		Double area = 0.0;
		area = this.base * this.altura;
		return area;
	}


}
