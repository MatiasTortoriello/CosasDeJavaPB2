import java.util.HashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Set;
import java.util.TreeSet;

public class Sets {
	public static void main(String[] args) {
		// SETS HAVE 1. NO REPEATED ELEMENTS AND 2. NO ORDER BETWEEN ELEMENTS
		
		Set<String> set = new HashSet<String>();
		// THEN DO THIS AGAIN AND CHANGE TREESET TO HASHSET
		
		// ARRAYLIST AND LINKEDLIST DO THE SAME (theyre polimorphic) BUT THEY BEHAVE DIFFERENT UNDER THE HOOD
		System.out.println(set);
		
		set.add("Cow");
		System.out.println(set);
		set.add("Cow");
		System.out.println(set);
		set.add("Dog");
		System.out.println(set);
		set.add("Flamenco");
		System.out.println(set);
		set.add("Zebra");
		System.out.println(set);
		
//		set.add(3, "Squid");
//		System.out.println(set);
		
		//String thirdAnimal = list.get(2); // Should return Dog.
		//System.out.println(thirdAnimal);
		System.out.println(set);
		
		System.out.println(set.remove("Cow")); // Removes Cow and should return Cow.
		System.out.println(set);
		
		System.out.println(set.size()); // Should return 4.
		System.out.println(set);

		System.out.println(set.contains("Giraffe")); // Should return false.
		System.out.println(set.contains("Squid")); // Should return true.
		System.out.println(set);
		
		// GET INDEX
		// TRAVERSE
		for (String x : set)
			System.out.println(x);
		
		// PRINT
		System.out.println(set);
		
		// EMPTY
		set.clear();
		System.out.println(set);
		
		// IS EMPTY?
		System.out.println(set.isEmpty());
	}
}
