package main;

import java.util.Collection;
import java.util.HashMap;
import java.util.Set;

public class App {

	public static void main(String[] args) {
		HashMap<String, String> mapa = new HashMap<String, String>();
		mapa.put("Argentina", "CABA");
		mapa.put("Brasil", "Brasilia");
		mapa.put("Francia", "Par�s");
		mapa.put("Uruguay", "Montevideo"); 
		mapa.put("Per�", "Lima");
		
		Set<String> set = mapa.keySet();
		boolean contiene = set.contains("Argentina");
		System.out.println(contiene);

		Collection<String> collection = mapa.values();
		boolean contiene2 = collection.contains("Lima");
		System.out.println(contiene2);
		
		System.out.println(mapa.remove("Argentina"));
		System.out.println(mapa.get("Brasil"));
		
		Set<String> set2 = mapa.keySet();
		boolean contiene3 = set2.contains("Argentina");
		System.out.println(contiene3);

		for(String i : set2) {
			System.out.println(i);
		}
		
		
//		HashMap<String, String> mapa2 = new HashMap<>(mapa);
//		Set<String> set3 = mapa2.keySet();
//		boolean contiene4 = set3.contains("Brasil");
//		System.out.println(contiene4);
//		
		
		
	}

}
