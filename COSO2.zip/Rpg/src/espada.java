
public class espada extends conItem {
	int da�o = 20;
	int da�oTotal;

	public espada(Inicio pj) {
		super(equipables);
	}

	public int getDa�o() {
		return super.getDa�o() + da�o;
	}
}
