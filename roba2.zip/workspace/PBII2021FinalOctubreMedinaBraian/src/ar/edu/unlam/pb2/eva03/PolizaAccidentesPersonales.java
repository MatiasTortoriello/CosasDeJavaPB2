package ar.edu.unlam.pb2.eva03;

import java.awt.List;
import java.util.ArrayList;

public class PolizaAccidentesPersonales extends Poliza implements SegurosDeVida {
	private ArrayList<Persona>beneficiarios=new ArrayList();
	private Boolean tuvoAlgunAccidente;
	


	public PolizaAccidentesPersonales(Integer nUMERO_DE_POLIZA, Persona asegurado, Double sUMA_ASEGURADA,
			Double pRIMA) {
		// TODO Auto-generated constructor stub
		super(nUMERO_DE_POLIZA, asegurado, sUMA_ASEGURADA, pRIMA);
	}

	@Override
	public void agregarBeneficiario(Persona hijo, TipoDeBeneficiario hijo2) {
		// TODO Auto-generated method stub
		hijo.setTipo(hijo2);
		beneficiarios.add(hijo);
	}
	@Override
	public Integer obtenerCantidadDeBeneficiarios(){
		return beneficiarios.size();
	}
	public ArrayList<Persona> getBeneficiarios() {
		return beneficiarios;
	}

	public void setBeneficiarios(ArrayList<Persona> beneficiarios) {
		this.beneficiarios = beneficiarios;
	}

	public Boolean TuvoAlgunAccidente() {
		return tuvoAlgunAccidente;
	}

	public void setTuvoAlgunAccidente(Boolean tuvoAlgunAccidente) {
		this.tuvoAlgunAccidente = tuvoAlgunAccidente;
	}


}
