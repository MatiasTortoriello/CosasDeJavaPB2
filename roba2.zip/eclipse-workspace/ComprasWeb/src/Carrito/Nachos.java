package Carrito;

public class Nachos extends Articulo {

	public Nachos(double precio) {
		super(precio);
		// TODO Auto-generated constructor stub
	}

}
