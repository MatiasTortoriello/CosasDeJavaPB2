package ar.unlam.calculadora;

import static org.junit.Assert.*;

import org.junit.Test;

public class TestCalculadora {

	@Test
	public void queSePuedanSumarDosNumeros() {
		// Preparacion
		Integer operador1 = 7;
		Integer operador2 = 4;
		Calculadora miCalculadora = new Calculadora();
		// Ejecucion
		Integer resultado = miCalculadora.sumar(operador1,operador2);
		//Verificacion
		Integer valorEsperado = 11;
		assertEquals(valorEsperado, resultado);
	}
	
	@Test
	public void queSePuedanDividirDosNumeros() {
		// Preparacion
		Double operador1 = 10.0;
		Double operador2 = 2.0;
		Calculadora miCalculadora = new Calculadora();
		// Ejecucion
		Double resultado = miCalculadora.dividir(operador1,operador2);
		//Verificacion
		Double valorEsperado = 5.0;
		assertEquals(valorEsperado, resultado);
	}
	
	@Test
	public void obtenerPorcentajeDeUnNumero() {
		// Preparacion
		Double numero = 100.0;
		Double porcentaje = 20.0;
		Calculadora miCalculadora = new Calculadora();
		// Ejecucion
		Double resultado = miCalculadora.porcentaje(numero,porcentaje);
		//Verificacion
		Double valorEsperado = 20.0;
		assertEquals(valorEsperado, resultado);
	}
	
	@Test
	public void queSePuedanMultiplicarDosNumeros() {
		// Preparacion
		Double operador1 = 100.0;
		Double operador2 = 20.0;
		Calculadora miCalculadora = new Calculadora();
		// Ejecucion
		Double resultado = miCalculadora.multiplicar(operador1,operador2);
		//Verificacion
		Double valorEsperado = 2000.0;
		assertEquals(valorEsperado, resultado);
	}
	
}
