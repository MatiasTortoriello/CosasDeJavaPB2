package ar.edu.unlam.pb2;

public class CapacidadExcedidaException extends Exception {

	public CapacidadExcedidaException(){
		super("Capacidad maxima alcanzada");
	}
}
