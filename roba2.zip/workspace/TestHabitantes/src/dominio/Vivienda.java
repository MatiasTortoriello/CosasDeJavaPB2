package dominio;

public class Vivienda {
	
	private String direccion;
	private Integer numero;
	private String municipio;
	private Integer id;

	public Vivienda(String direccion, Integer numero, String municipio, Integer id) {
		this.direccion = direccion;
		this.numero = numero;
		this.municipio = municipio;
		this.id = id;
	}

}
