
public class Carrito {
	
	productoQueNoSeSuma;
	pructosAgregadosAlPack = 0;
	precioTotal = 0;
	
	
	constructor( float productoQueNoSeSuma){
		this.productoQueNoSeSuma = productoQueNoSeSuma;
		
	}
	
	agregarProducto ( producto prod){
		if(pructosAgregadosAlPack != productoQueNoSeSuma){
			precioTotal += prod.precio;
		}
		pructosAgregadosAlPack++;
	}
}
