package ar.unlam.testAlumno;

import org.junit.Test;

public class TestAlumno {
	@Test	
	public void queSePuedaCrearAlumno() {
		String nombre;
		String apellido;
		Integer dni;
		Boolean estado;
		Integer legajo;	
		
		
		Alumno alu = new Alumno();		
		Alumno aluRes =alu.crear(nombre,apellido,legajo,dni,estado);
		
		a
	}
	
	
	
}
