package LuchadoresJaponeses;

public class Luchador {
	
	private int peso, altura, cantDominados;

	public Luchador(int peso, int altura) {
		super();
		this.peso = peso;
		this.altura = altura;
		this.cantDominados = 0;
	}
	
	public int domina (Luchador oponente) {
		if (this.altura >= oponente.altura && this.peso >= oponente.peso)
			return 1;
		if (this.altura <= oponente.altura && this.peso <= oponente.peso)
			return -1;
		return 0;
	}
	
	public void aumentar() {
		this.cantDominados++;
	}

	@Override
	public String toString() {
		return "Luchador [peso=" + peso + ", altura=" + altura + ", cantDominados=" + cantDominados + "]";
	}

	public int getCantDominados() {
		return cantDominados;
	}

}
