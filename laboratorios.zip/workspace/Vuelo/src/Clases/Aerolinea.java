package Clases;

import java.util.ArrayList;

public class Aerolinea {

	private String nombre;
	private ArrayList <Personal> personal;
	private ArrayList <Vuelo> vuelos;
	
	public Aerolinea(String nombre) {
		this.nombre = nombre;
		this.setPersonal(new ArrayList <Personal>());
		this.setVuelo(new ArrayList <Vuelo>());
	}

	public String getNombre() {
		return nombre;
	}

	public Personal crearPersonalTipoPiloto(Integer id, String tipoPersonal) {
		Personal personal = new Piloto (id, tipoPersonal);
		return personal;
	}

	public ArrayList <Personal> getPersonal() {
		return personal;
	}

	public void setPersonal(ArrayList <Personal> personal) {
		this.personal = personal;
	}

	public void agregarPersona(Personal personal2) {
		this.personal.add(personal2);
	}

	public Integer obtenerCantPersonal() {
		return this.personal.size();
	}

	public void agregarVuelo(Vuelo vuelo) {
		this.vuelos.add(vuelo);
	}
	
	public Integer obtenerCantVuelos() {
		return this.vuelos.size();
	}

	public ArrayList <Vuelo> getVuelo() {
		return vuelos;
	}

	public void setVuelo(ArrayList <Vuelo> vuelo) {
		this.vuelos = vuelo;
	}

	public void agregarPersonalAlVuelo(Integer idPersonal, Integer idVuelo) {
		Personal personalEncontrado = buscarPersonal(idPersonal);
		Vuelo vueloEncontrado = buscarVuelo(idVuelo);
		
		if (personalEncontrado != null && vueloEncontrado != null) {
			vueloEncontrado.agregarPersonal(personalEncontrado);	
		}
	}

	private Vuelo buscarVuelo(Integer idVuelo) {
		for (Vuelo vuelo : vuelos) {
			if(vuelo.getId().equals(idVuelo)){
				return vuelo;
			}
		}
		return null;
	}

	private Personal buscarPersonal(Integer idPersonal) {
		for (Personal personal : personal) {
			if(personal.getId().equals(idPersonal)){
				return personal;
			}
		}
		return null;
	}

	public Integer getCantPilotos() {
		Integer contador = 0;
		for (Personal personal2 : personal) {
			if(personal2 instanceof Piloto){
				contador++;
			}
		}
		return contador;
	}


	

}
