package dominio;

public class RegistroPropiedad {
	
	private Vivienda vivienda;
	private Habitante habitante;
	private Double porcentaje;
	private Integer id;

	public RegistroPropiedad(Integer id, Vivienda vivienda, Habitante habitante, Double porcentaje) {
		this.vivienda = vivienda;
		this.habitante = habitante;
		this.porcentaje = porcentaje;
		this.id = id;
	}

	public Vivienda getVivienda() {
		return vivienda;
	}

	public void setVivienda(Vivienda vivienda) {
		this.vivienda = vivienda;
	}

	public Habitante getHabitante() {
		return habitante;
	}

	public void setHabitante(Habitante habitante) {
		this.habitante = habitante;
	}

	public Double getPorcentaje() {
		return porcentaje;
	}

	public void setPorcentaje(Double porcentaje) {
		this.porcentaje = porcentaje;
	}
	
	

	
}
