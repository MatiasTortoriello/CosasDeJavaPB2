import java.util.TreeSet;
	

public class TreeSetPrueba implements Comparable<TreeSetPrueba> {
	
	private int nroDocumento;
	private double sueldo;
	private String Nombre;
	
	public TreeSetPrueba(int documento, double numero, String nombre) {
		
		nroDocumento = documento;
		sueldo = numero; 
		Nombre= nombre;
	}
	

	
	public static void main(String[] args) {
		
			TreeSetPrueba test = new TreeSetPrueba(1, 230, "ruben carlos");
			TreeSetPrueba test2 = new TreeSetPrueba(2, 1402, "elMarquitos");
			TreeSetPrueba test3 = new TreeSetPrueba(3, 403, "asdafas");

		
		
		TreeSet<TreeSetPrueba> tree = new TreeSet<TreeSetPrueba>();
		
		
		
			tree.add(test);
			tree.add(test2);
			tree.add(test3);
		
			System.out.println(tree);
			System.out.println(tree.contains(test));
		
			
	}
	
	



	@Override
	public String toString() {
		return "nroDocumento=" + nroDocumento + ", sueldo=" + sueldo + ", Nombre=" + Nombre ;
	}



	@Override
	public int compareTo(TreeSetPrueba o) {
		
		return Integer.compare(this.nroDocumento, o.nroDocumento);
	}
	
}