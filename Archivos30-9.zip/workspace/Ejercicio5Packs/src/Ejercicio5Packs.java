
public class Ejercicio5Packs {

	public static void main(String[] args) {
		

	}

}
