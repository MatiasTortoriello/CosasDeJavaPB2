package UnidadesRes;

public class App {
	public static void main(String[] args) {
		
		Metro a = new Metro(10);
		
		System.out.println(a);
		
		System.out.println(a.toPie());
		System.out.println(a.toMilla());
		System.out.println(a.toKilometro());
		
		
		Metro metro1 = new Metro(100);
		Kilometro k = new Kilometro(100);
		Milla m = new Milla(100);
		Pie p = new Pie(100);
		Metro metro2 = new Metro(100);
		
		UnidadDeLongitud[] medidas = {metro1, metro2, k, m,p};
		
		for (UnidadDeLongitud medida : medidas) {
			System.out.println(medida.toMetro());
		}
		
		
		
	}

}
