package ar.edu.unlam.pb2.dominio;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;


public class Secretaria {

	private String nombre;
	private ArrayList<Habitante> habitantes;
	private ArrayList<Vivienda> viviendas;
	private ArrayList<RegistroPropiedades> propietariosViviendas;

	public Secretaria(String nombre) {
		this.nombre = nombre;
		this.habitantes = new ArrayList<Habitante>();
		this.viviendas = new ArrayList<Vivienda>();
		this.propietariosViviendas = new ArrayList<RegistroPropiedades>();
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public void agregarHabitante(Habitante habitante) {
		this.habitantes.add(habitante);
	}

	public Integer obtenerCantidadDeHabitantes() {
		return habitantes.size();
	}

	public ArrayList<Habitante> getHabitantes() {
		return habitantes;
	}

	public void setHabitantes(ArrayList<Habitante> habitantes) {
		this.habitantes = habitantes;
	}

	public void agregarVivienda(Vivienda vivienda) {
		this.viviendas.add(vivienda);
	}

	public Integer obtenerCantidadVivienda() {
		return this.viviendas.size();
	}

	public Boolean comprarVivienda(Habitante habitante, Vivienda vivienda, Double porcentaje) {
		Double porcentajeDeVivienda = obtenerElPorcentajeDeCompraDeUnaVivienda(vivienda);
		if(porcentajeDeVivienda + porcentaje <= 100.0){
			RegistroPropiedades propietarioVivienda = new RegistroPropiedades (habitante, vivienda, porcentaje);
			this.propietariosViviendas.add(propietarioVivienda);
			return true;
		}
		return false;
		
	}

	private Double obtenerElPorcentajeDeCompraDeUnaVivienda(Vivienda vivienda) {
		Double porcentaje = 0.0;
		for (int i = 0; i < this.propietariosViviendas.size(); i++) {
			if(this.propietariosViviendas.get(i).getVivienda().equals(vivienda)){
				porcentaje = this.propietariosViviendas.get(i).getPorcentaje();
			}
		}
		return porcentaje;
	}

	public Integer obtenerCantidadCompras() {
		return this.propietariosViviendas.size();
	}

	
	
	
	
	public void generarId() {
		
	}

	public HashSet<Vivienda> obtenerViviendaCuyoPorcentajeEsMenorACien() {
		HashSet<Vivienda> viviendasMenorAlCien = new HashSet<Vivienda>();
		for (RegistroPropiedades propietarioVivienda : propietariosViviendas) {
			if(this.obtenerElPorcentajeDeCompraDeUnaVivienda(RegistroPropiedades.getVivienda()) < 100){
				viviendaMenorAlCien
			}
			}
		
	}
	
	

}
