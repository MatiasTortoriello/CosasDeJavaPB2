import static org.junit.Assert.*;

import org.junit.Test;

public class MonticuloTest {

	@Test
	public void agregarUnElemento() {
		Monticulo monticulo = new Monticulo();
		
		monticulo.poner(90);
		
		assertEquals(90, monticulo.sacar());
		
	}

	@Test
	public void agregarElementos() {
		Monticulo monticulo = new Monticulo();
		
		monticulo.poner(90);
		monticulo.poner(120);
		monticulo.poner(50);
		monticulo.poner(100);
		
		assertEquals(120, monticulo.sacar());
		assertEquals(100, monticulo.sacar());
		
	}
	
}
