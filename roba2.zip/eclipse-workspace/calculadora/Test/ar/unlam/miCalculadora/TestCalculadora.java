package ar.unlam.miCalculadora;

import static org.junit.Assert.assertEquals;

import org.junit.Test;

public class TestCalculadora {
	@Test

	public void queSePuedanSumar2numeros() {
		// assertEquals(1 ,0);//primero esperado, segundo obtenido
		// Preparaci�n
		Integer operando1 = 3;
		Integer operando2 = 2;
		Calculadora miCalculadora = new Calculadora();
		//Ejecuci�n
		Integer resultado =  miCalculadora.sumar(operando1,operando2);
		//Comprobaci�n
		Integer valorEsperado = 5;
		assertEquals(valorEsperado, resultado);
	}
	@Test 
	public void queSePuedaDividir2numeros() {
	
	Double numerador = 10.0;
	Double  denominador = 2.0;
	Calculadora miCalculadora = new Calculadora();
	//Ejecuci�n
	Double resultado =  miCalculadora.dividir(numerador,denominador);
	//Comprobaci�n
	Double valorEsperado = 5.0;
	assertEquals(valorEsperado, resultado);
	}
	@Test
	public void obtenerPorcentajeDeUnNumero() {
		Double numero = 100.0;
		Double  porcentaje = 20.0;
		Calculadora miCalculadora = new Calculadora();
		//Ejecuci�n
		Double resultado =  miCalculadora.porcentaje(numero,porcentaje);
		//Comprobaci�n
		Double valorEsperado = 20.0;
		assertEquals(valorEsperado, resultado);
	}	
	
	@Test
	public void queSePuedaMultiplicar() {
		Double operador1 = 10.0;
		Double  operador2 = 2.0;
		Calculadora miCalculadora = new Calculadora();
		//Ejecuci�n
		Double resultado =  miCalculadora.multiplicar(operador1,operador2);
		//Comprobaci�n
		Double valorEsperado = 20.0;
		assertEquals(valorEsperado, resultado);	
		
	}	
	
}
