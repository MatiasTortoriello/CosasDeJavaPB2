package ar.edu.unlam.Class;

public class Juez extends Comisario {

	public Juez(Integer dni, String nombre, Integer edad) {
		super(dni, nombre, edad);
		// TODO Auto-generated constructor stub
	}

}
