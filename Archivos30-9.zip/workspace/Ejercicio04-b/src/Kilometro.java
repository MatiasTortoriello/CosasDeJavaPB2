
public class Kilometro extends UnidadDeLongitud{

	
	Kilometro(double cantidad){
		this.cantidad = cantidad;
	}
	
	public double aMetro(){
		return this.cantidad * 1000;
	}
	
	public double aPie(){
		return this.cantidad * 3280.84;
	}
	
	public double aMilla(){
		return this.cantidad * 0.621371;
	}
	
	public double aKm(){
		return this.cantidad;
	}
		
}
