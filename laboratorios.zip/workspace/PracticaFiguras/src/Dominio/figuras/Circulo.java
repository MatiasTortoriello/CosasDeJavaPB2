package Dominio.figuras;

public class Circulo extends Figura{
	private Double radio;
	private final Double PI = 3.14;
	
	
	public Circulo(String nombre, Double area, Integer perimetro,Double radio){
		super(nombre,area,perimetro);
		this.radio = radio;
	}
	
	
	@Override
	public Double calcularArea(){
		Double area = 0.0;
		area = PI * (this.radio * this.radio);
		return area;
	}


	public Double getRadio() {
		return radio;
	}


	public void setRadio(Double radio) {
		this.radio = radio;
	}


	public Double getPI() {
		return PI;
	}



	
	
}
