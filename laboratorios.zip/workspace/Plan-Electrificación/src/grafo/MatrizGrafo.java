package grafo;

public class MatrizGrafo extends Grafo{
	
	private int[][] grafo;
		
	public MatrizGrafo(int tam){
		this.grafo = new int [tam][tam];
	}
	
	@Override
	public int getNodos() {
		return this.grafo.length;
	}

	@Override
	public int getArista(int desde, int hasta) {
		return this.grafo[desde][hasta];
	}

	@Override
	public void setArista(int desde, int hasta, int costo) {
		this.grafo[desde][hasta] = costo;
		this.grafo[hasta][desde] = costo;
	}

	
	
	 
	
}
