package vehiculo;

public class Camion extends Vehiculo {
	
	private Remolque remolque;
	
	
	public Camion(String matricula, Remolque remolque) {
		super(matricula);
		this.remolque = null;
	}

	public void acelerar(double cantidad) throws DemasiadoRapidoException {
		if (this.velocidad + cantidad > 100 && this.remolque != null ) {
			throw new DemasiadoRapidoException();
		}
		else {
			this.velocidad += cantidad;
		}
	}
	
	public void ponRemolque(Remolque remolque) {
		this.remolque = new Remolque();
	}
	
	public void quitaRemolque(Remolque remolque) {
		this.remolque = null;
	}

}
