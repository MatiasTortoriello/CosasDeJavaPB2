
public class Guerrero extends Unidad{
	private int salud;
	private int danio;
	
	
	public Guerrero(int salud, int danio) {
		super();
		this.salud = salud;
		this.danio = danio;
	}
	
	public void daniar(Unidad otro) {
		otro.recibirDanio(this.danio);
	}
	
	public void recibirDanio(int danio) {
		this.salud -= danio;
//		if(this.salud < 0) {
//			this.salud = 0;
//		}
	}
	

	@Override
	public boolean estaVivo() {
		return this.salud > 0;
	}

	@Override
	public String toString() {
		return "Guerrero [salud=" + salud + ", danio=" + danio + "]";
	}
	
	
}
