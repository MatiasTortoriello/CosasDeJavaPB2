package ar.edu.unlam.pb2.dominio;

public class Municipio {

	private Integer numMunicipio;
	private String nombreMunicipio;

	public Municipio(Integer numMunicipio, String nombreMunicipio) {
		this.numMunicipio = numMunicipio;
		this.nombreMunicipio = nombreMunicipio;
	}

	public Integer getNumMunicipio() {
		return numMunicipio;
	}

	public void setNumMunicipio(Integer numMunicipio) {
		this.numMunicipio = numMunicipio;
	}

	public String getNombreMunicipio() {
		return nombreMunicipio;
	}

	public void setNombreMunicipio(String nombreMunicipio) {
		this.nombreMunicipio = nombreMunicipio;
	}
	
	

}
