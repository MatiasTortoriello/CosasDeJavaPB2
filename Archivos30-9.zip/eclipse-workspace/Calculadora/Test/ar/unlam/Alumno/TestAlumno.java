package ar.unlam.Alumno;

import org.junit.Test;

public class TestAlumno {

	@Test
	public void QueSePuedaCrearAlumno() {
		
		String nombre = "", Apellido = "";
		Integer dni = 0,legajo = 0;
		Boolean estado = false;
		
		//Preparacion
		Alumno Alu = new Alumno();
		Alumno AlRes = Alumno.crear(nombre, Apellido, legajo, estado, dni);
		
		
	}
}
