package ar.edu.unlam.pb2.dominio;

public class Vivienda {

	private String calle;
	private Integer numero;
	private Municipio municipio;
	private Integer id;

	public Vivienda(String calle, Integer numero, Municipio municipio, Integer id) {
		this.calle = calle;
		this.numero = numero;
		this.municipio = municipio;
		this.id = id;
	}

	public Vivienda(String calle, Integer numero, Municipio municipio) {
		this.calle = calle;
		this.numero = numero;
		this.municipio = municipio;
	}

	public String getCalle() {
		return calle;
	}

	public void setCalle(String calle) {
		this.calle = calle;
	}

	public Integer getNumero() {
		return numero;
	}

	public void setNumero(Integer numero) {
		this.numero = numero;
	}

	public Municipio getMunicipio() {
		return municipio;
	}

	public void setMunicipio(Municipio municipio) {
		this.municipio = municipio;
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}
	
	

}
