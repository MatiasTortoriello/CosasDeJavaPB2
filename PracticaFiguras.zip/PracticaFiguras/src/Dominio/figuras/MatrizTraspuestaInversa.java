package Dominio.figuras;

public class MatrizTraspuestaInversa extends Figura{

}
