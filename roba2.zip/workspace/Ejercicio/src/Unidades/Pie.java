package Unidades;

public class Pie extends UnidadDeLongitud {

	//private BigDecimal valor;

	public Pie(double valor) {
		super(valor);
		this.valor = valor;
	}
	
	@Override
	public Pie toPie() {
		return this;
	}

	@Override
	public Metro toMetro() {
		return new Metro(this.valor / 3.281);
	}
	
	@Override
	public Kilometro toKilometro() {
		return new Kilometro(this.valor / 3281);
	}
	
	@Override
	public Milla toMilla() {
		return new Milla(this.valor / 5208);
	}
	
	@Override
	public String toString() {
		return this.valor + " Pies";
	}
	
	@Override
	public Pie Sumar(UnidadDeLongitud otra) {
		return new Pie(this.valor + otra.toPie().valor);
	}
}
