public class Guerrero extends Unidad {
	private double x;
	private double y;
	private int salud;
	private int danio;

	public static void main(String[] args) {
		Guerrero g1 = new Guerrero(0, 0, 100, 10);
		Guerrero g2 = new Guerrero(0, 3, 50, 5);

		g1.atacar(g2);
		System.out.println("Guerrero 2: " + g2);
		g2.moverse();
		System.out.println("Guerrero 2: " + g2);
	}

	public Guerrero(double x, double y, int salud, int danio) {
		this.x = x;
		this.y = y;
		this.salud = salud;
		this.danio = danio;
	}

	@Override
	public void atacar(Unidad ente) {
		ente.recibirDanio(this.danio);
	}

	@Override
	public void recibirDanio(int danio) {
		if (this.salud - danio > 0)
			this.salud -= danio;
		else
			this.salud = 0;
	}

	public void moverse() {
		this.x++;
		this.y++;
	}

	public int getDanio() {
		return this.danio;
	}

	@Override
	public String toString() {
		return "[x=" + x + ", y=" + y + ", salud=" + salud + ", danio=" + danio + "]";
	}
}
