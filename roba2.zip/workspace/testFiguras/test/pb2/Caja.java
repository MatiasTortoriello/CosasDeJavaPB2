package pb2;

import java.util.ArrayList;

public class Caja {
	private ArrayList<Figura> figuras;
	private ArrayList<Figura> figurasArea;
	
	public Caja(){
		this.figuras=new ArrayList<Figura>();
		this.figurasArea=new ArrayList<Figura>();
	}
	public void agregarFigura(Figura figura){
		figuras.add(figura);
	}
	public  int cantidadFigurasGuardas(){
		return figuras.size();
	}
	public Figura obtenerFiguraConAreaMayoraDiez() {
		Figura figuArea=null;
		for(Figura figu : figuras){
			if(figu.calcularArea()>=10 ){
				figuArea=figu;
			}
		}
		return figuArea;
	}

}
