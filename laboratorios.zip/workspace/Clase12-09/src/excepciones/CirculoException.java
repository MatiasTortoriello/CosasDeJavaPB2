package excepciones;

public class CirculoException extends RuntimeException{

	/**
	 * 
	 */
	private static final long serialVersionUID = -1582226803976856833L;

	public CirculoException() {
		super("Radio negativo inaceptable");
	}
	
	public CirculoException(String mensaje) {
		super(mensaje);
	}
	
	public CirculoException(Exception e) {
		super(e);
	}
	
}
