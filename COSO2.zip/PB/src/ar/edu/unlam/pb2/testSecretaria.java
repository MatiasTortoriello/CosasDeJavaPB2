package ar.edu.unlam.pb2; 

import static org.junit.Assert.*;

import org.junit.Test;

public class testSecretaria {

	@Test
	public void queSePuedaAgregarUnaSecretaria() {
		Secretaria secretaria = new Secretaria ("Cordoba");
		assertNotNull(secretaria);
	}
	
	@Test 
	public void queSePuedaAgregarUnHabitanteALaSecretaria() {
		Integer dni;
		String nombre = "Juan";
		String calle = "Florencio Varela";
		Integer numero = 1900;
		
		String nombreDeMunicipio = "San Justo";
		Integer numeroDeMunicipio = 1;
		
		Municipio municipio = new Municipio (numeroDeMunicipio, nombreDeMunicipio);
		Vivienda vivienda = new Vivienda (calle , numero, municipio);
		Habitante habitante = new Habitante (dni, nombre, vivienda); 
		
		Integer valorEsperado = 1;
		Integer valorObtenido = secretaria.getHabitantes();
		
		assertEquals (valorEsperado, valorObtenido); 
	}
}
