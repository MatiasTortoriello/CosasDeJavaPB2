import java.util.ArrayList;

public class Monticulo {
	private ArrayList<Integer> array;
	
	public Monticulo (int element) {
		this.array.add(element);
	}
	
}
