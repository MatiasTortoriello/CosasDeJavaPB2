package ar.edu.unlam.pb2.eva03;


public interface SegurosGenerales {
	public void agregarBienAsegurado(Auto auto);
	public void agregarBienAsegurado(Vivienda vivienda);
	
}
