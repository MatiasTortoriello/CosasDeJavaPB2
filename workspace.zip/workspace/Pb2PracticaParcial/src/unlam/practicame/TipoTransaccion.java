package unlam.practicame;

public enum TipoTransaccion {
 MONETARIA, NO_MONETARIA
}
