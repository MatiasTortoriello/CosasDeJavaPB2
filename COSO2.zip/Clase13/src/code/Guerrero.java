package code;

public class Guerrero extends Unidad {
	private int vida;
	private int danioAtaque;
	
	public Guerrero(int danio) {
		this.vida = 100;
		this.danioAtaque = danio;
	}
	
	public void recibirAtaque(int danio) {
		if((this.vida-=danio)<0) {
			this.vida = 0;
		}
	}
	
	public void atacar(Guerrero enemigo) {
		enemigo.recibirAtaque(this.danioAtaque);
	}
	
	public int getVida() {
		return this.vida;
	}
	
	public int getDanioAtaque() {
		return this.danioAtaque;
	}
	

}
