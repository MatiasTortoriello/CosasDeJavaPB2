package unlam.practicame;

import static org.junit.Assert.*;

import org.junit.Test;

public class Testeando {

	@Test
	public void testQueSePuedaCrearUnCliente() {
		Dispositivo dispositivo = new PC ("Windows", "100.343.135.24", "Avellaneda");
		Cliente cliente = new Cliente (134134, "Lauty", dispositivo);
		assertNotNull (cliente);
	}
	
	@Test
	public void testQueSePuedaCrearUnDispositivo() {
		Dispositivo dispositivo = new PC ("Windows", "100.343.135.24", "Avellaneda");
		assertNotNull(dispositivo);
	}
	
	@Test
	public void testQueSePuedaMonitorearUnaExtraccion() {
		
	}
	
	@Test
	public void testQueSePuedaMonitorearUnaTransferencia() {
		
	}
	
	@Test
	public void testQueSePuedaMonitorearUnPagoConQR() {
		
	}
	
	@Test
	public void testQueSePuedaMonitorearUnPagoDeServicio() {
		
	}
	
	@Test
	public void testQueSePuedaMonitorearUnAltaDeUsuario() {
		
	}
	
	@Test
	public void testQueSePuedaMonitorearUnCambioDeContrase�a() {
		
	}
	
	@Test
	public void testQueElScoreDeUnaTransaccionRechazableSinAntecedentesDeCero() {
		
	}
	
	
	@Test
	public void testQueUnaTransaccionAlertablePuedaSerMarcadaComoFraudulenta() {
		
	}
	
	@Test
	public void testQueElScoreDeUnaTransaccionRechazableConNuevoDispositivoDe20Puntos() {
		
	}
	
	@Test
	public void testQueUnaTransaccionDeMasDe60PuntosYMenosDeOchentaSeaAlertadaPeroAprobada() {
		
	}
	
	@Test
	public void testQueUnaTransaccionDeMasDe80PuntosLanceLaExcepcionFraudeException() {
		
	}



}
