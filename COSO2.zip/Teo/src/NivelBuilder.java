
public class NivelBuilder {
	
	public void setJugable()
	{
		Jugable personaje = new Jugable();
	}
	public void setObstaculo(Obstaculo obs)
	{
		
	}
	public void setItem(Item it)
	{
		
	}
	
}
