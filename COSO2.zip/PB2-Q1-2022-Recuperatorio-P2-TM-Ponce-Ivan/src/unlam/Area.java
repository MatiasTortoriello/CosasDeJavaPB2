package unlam;
 

public class Area implements Comparable<Area>{
	Integer id;
	String nombre;
	String ubicacion ;

	public Area(Integer id, String nombre, String ubicacion) {
		
		// TODO Auto-generated constructor stub
		
		this.id = id ;
		this.nombre = nombre ;
		this.ubicacion =ubicacion ;
	}

	@Override
	public int compareTo(Area o) {
		// TODO Auto-generated method stub
		return 0;
	}

}
