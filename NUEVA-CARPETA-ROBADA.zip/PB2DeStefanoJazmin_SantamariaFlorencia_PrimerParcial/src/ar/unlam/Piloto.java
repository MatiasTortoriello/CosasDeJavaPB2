package ar.unlam;

public class Piloto extends Personal{
	
	
	//private TipoAvion tipoAvion;
	
	public Piloto(Integer id, String nombre, String apellido) {
		super(id, nombre,apellido);
		
	}

	

}
