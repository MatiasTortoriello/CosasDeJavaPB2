package ar.edu.unlam.pb2;

public class Vivienda {

	Integer id;
	Integer numero;
	String calle;
	
	
	public Vivienda(Integer id, Integer numero, String calle) {
		
		this.id = id;
		this.numero = numero;
		this.calle = calle;
		
	}

}
