package ar.edu.unlam.pb2;

import java.util.HashSet;
import java.util.Set;

public abstract class UnidadAlmacenamiento {

	Set <Archivo> archivos;
	private Double capacidadMaxima;
	private Character letra;
	
	private Double capacidadUsada;
	
	public UnidadAlmacenamiento(Double capacidadMaxima, Character letra) {
		this.capacidadMaxima = capacidadMaxima;
		this.letra = letra;
		
		this.archivos = new HashSet<Archivo>(); 
		this.capacidadUsada = 0.0;
	}
	
	public abstract void agregarArchivo(Archivo archivo);
	
	public Set <Archivo> obtenerListaDeArchivosJpgOrdenadosPorNombre(Archivo archivo1, Archivo archivo2){
		Set <Archivo> archivo = new HashSet<Archivo>();
		
		//return archivo. ompareTo(archivo1, archivo2);
		return null;
	}
	
	public Double calcularEspacioAlmacenado(){
		
		return 0.0;
	}

	public Boolean verificarCapacidad() throws CapacidadExcedidaException{
		if(this.capacidadUsada <= this.capacidadMaxima){
			return Boolean.TRUE;
		}
		throw new CapacidadExcedidaException();
	}
	
	public Double getCapacidadMaxima() {
		return capacidadMaxima;
	}

	public void setCapacidadMaxima(Double capacidadMaxima) {
		this.capacidadMaxima = capacidadMaxima;
	}

	public Character getLetra() {
		return letra;
	}

	public void setLetra(Character letra) {
		this.letra = letra;
	}
	
}
