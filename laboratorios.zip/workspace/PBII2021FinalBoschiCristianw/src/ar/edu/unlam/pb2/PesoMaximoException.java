package ar.edu.unlam.pb2;

public class PesoMaximoException extends Exception {
	public PesoMaximoException() {
		super("PesoMaximoException");
	}
}
