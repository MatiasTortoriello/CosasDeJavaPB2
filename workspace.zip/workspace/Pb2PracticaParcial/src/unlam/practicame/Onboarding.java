package unlam.practicame;

public class Onboarding extends Transaccion implements Monitoreable {

	@Override
	public void monitorear() {
		TipoTransaccion tipo = TipoTransaccion.NO_MONETARIA;
		
	}

}
