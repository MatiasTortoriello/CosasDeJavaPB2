
public class Personaje implements Accionable{


	@Override
	public int getDanio() {
		return 0;
	}
}
