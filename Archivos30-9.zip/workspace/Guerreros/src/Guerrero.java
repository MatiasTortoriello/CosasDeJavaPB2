
public class Guerrero extends Unidad {
	private int vida;
	private int danio;
	
	Guerrero(){
		this.vida = 100;
		this.danio = 10;
	}
			
	public void recibirDanio(int danio){
		if(this.vida > 0){
			this.vida -= danio;			
		}
		else{
			this.vida = 0;
			morir();
		}
	}	
}
