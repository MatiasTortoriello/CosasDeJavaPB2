package UnidadesRes;

public class Kilometro extends UnidadDeLongitud {
	private double valor;

	public Kilometro(double valor) {
		super(valor);
	}

	@Override
	public Metro toMetro() {
		return new Metro(this.valor * 1000);
	}

	@Override
	public Milla toMilla() {
		return new Milla(this.valor / 1.609);
	}

	@Override
	public Pie toPie() {
		return new Pie(this.valor * 3281);
	}

	@Override
	public Kilometro toKilometro() {
		return this;
	}
	
	@Override
	public UnidadDeLongitud sumar(UnidadDeLongitud other) {
		return new Kilometro(this.valor + other.toKilometro().valor);
	}
	
	@Override
	public UnidadDeLongitud enMiUnidad(UnidadDeLongitud other) {
		return other.toKilometro();
	}

	@Override
	public String toString() {
		return this.valor + "km";
	}

}
