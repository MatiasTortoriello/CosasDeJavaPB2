
public class Punto implements Comparable<Punto> {
	//adentro de la clase no necesito los getters, desde el mian si

	private double x, y;	//se inicializan solas pero no para hacer calculos
	
	public Punto () {
		//constructor vacio, deja de funcionar si creo uno con parametros
	}

	public Punto(double x, double y) {
		this.x = x;
		this.y = y;
	}
	
	public Punto(Punto p) { //llamo Punto unoBis = new Punto(uno) ///constructor de copia
		this.x = p.x;
		this.y = p.y;
	}

	public Double getX() {
		return x;
	}

	public Double getY() {
		return y;
	}

	public double getModulo() {
		return Math.sqrt(Math.pow(this.x, 2) + Math.pow(this.y, 2));
	}

	@Override
	public int compareTo(Punto otro) {
		Double miModulo = getModulo();
		Double otroModulo = otro.getModulo();

//		if (miModulo == otroModulo) return 0;
//		if (miModulo < otroModulo) return -1;
//		return 1;

//		return (int)(miModulo - otroModulo);

		return miModulo.compareTo(otroModulo);
	}

	@Override	//es como el igual pero con cuentas /es menos exacto
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		long temp;
		temp = Double.doubleToLongBits(x);
		result = prime * result + (int) (temp ^ (temp >>> 32));
		temp = Double.doubleToLongBits(y);
		result = prime * result + (int) (temp ^ (temp >>> 32));
		return result;
	}

	public Punto mover(double dx, double dy) {
		return new Punto(this.x + dx, this.y + dy);	//tengo que crear uno muevo asi es inmutable
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)	//si son exactamente lo mismo (unoBis = uno)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())	//no son de la misma clsae ///completar
			return false;

		Punto other = (Punto) obj;	//castea clse generica Object a Punto (clase que uso)

		if (Double.doubleToLongBits(x) != Double.doubleToLongBits(other.x)) //compara bit a bit
			return false;
		if (Double.doubleToLongBits(y) != Double.doubleToLongBits(other.y))
			return false;
		return true;
	}

	@Override	//se invoca automaticamente
	public String toString() {		//source - generate to String
		return "(" + this.x + ", " + this.y + ")";
	}

	// http://commons.apache.org/proper/commons-lang/download_lang.cgi

//	@Override
//	public String toString() {
//		return ToStringBuilder.reflectionToString(this);
//	}

	@Override
	public Punto clone() throws CloneNotSupportedException {
		return new Punto(this.x, this.y);		//creo un nuevo punto exactamente igual, hereda propiedades
	}	
}
