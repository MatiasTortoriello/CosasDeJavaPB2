package ar.edu.unlam.pb2;

import java.util.ArrayList;

public class Banco {

	private String nombreDeBanco;
	private ArrayList <Cuenta> cuentas; // = new ArrayList<>(); 
	public Banco(String nombreDeBanco) {
		this.cuentas = new ArrayList<>();
		this.nombreDeBanco = nombreDeBanco;
	}

	public Integer obtenerCantidadDeCuentas() {
		return this.cuentas.size();
	}

	public void agregarCuenta(Cuenta cuenta) {
		this.cuentas.add(cuenta);
		
	}

	public String getNombreBanco() {
		return nombreDeBanco;
	}

	public void setNombreBanco(String nombreBanco) {
		this.nombreDeBanco = nombreBanco;
		
	}
	
	public Boolean hacerTranferencia(Cuenta cuentaOrigen, Cuenta cuentaDestino, Double monto){
		if(cuentaOrigen.extraer(monto)){
			cuentaDestino.depositar(monto);
			return true;
		}
		return false;
	}
	
	public Boolean transferenciaPorId(Integer idOrigen, Integer idDestino, Double monto){
		Cuenta cuentaOrigen=this.buscarCuentaPorId(idOrigen);
		Cuenta cuentaDestino=this.buscarCuentaPorId(idDestino);
		if(cuentaOrigen!=null&&cuentaDestino!=null){
			if(cuentaOrigen.extraer(monto));
				cuentaDestino.depositar(monto);
			return true;
			
		}
		return false;
	}

	public Cuenta buscarCuentaPorId(Integer id) {
		for(int i=0; i<cuentas.size();i++){
			if(this.cuentas.get(i).getId().equals(id));
			return this.cuentas.get(i);
		}
		for(Cuenta cuenta : cuentas) {
			if (cuenta.getId().equals(id))
				return cuenta;
		}
		return null;
	}


}
