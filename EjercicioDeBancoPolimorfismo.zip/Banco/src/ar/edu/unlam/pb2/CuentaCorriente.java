package ar.edu.unlam.pb2;

public class CuentaCorriente extends Cuenta {
	private Double limiteDescubierto;
	private Integer puntos;

	public CuentaCorriente(Integer numCuenta, Double saldo, Titular titular, Double limiteDescubierto) {
		super(numCuenta, saldo, titular);
		this.limiteDescubierto = limiteDescubierto;
		this.setPuntos(0);
	}

	
	public CuentaCorriente(Integer numCuenta, Double saldo, String nombre, String apellido, Integer dni, Double limiteDescubierto) {
		super(numCuenta, dni, nombre, apellido);
		this.limiteDescubierto = limiteDescubierto;
		this.setPuntos(0);
	}


	public Double getLimiteDescubierto() {
		return limiteDescubierto;
	}

	public void setLimiteDescubierto(Double limiteDescubierto) {
		this.limiteDescubierto = limiteDescubierto;
	}
	
	@Override
	public Boolean extraer(Double monto) {
		if (monto <= this.getSaldo() + limiteDescubierto) {
			Double saldoFinal = getSaldo()-monto; 
			setSaldo(saldoFinal);
			
			// extraer como lo hace el padre
			extraer(monto);
			return true;
		}
		return false;
		
	}


	@Override
	public String getTipo() {
		// TODO Auto-generated method stub
		return "Cuenta Corriente";
	}


	public Integer getPuntos() {
		return puntos;
	}


	public void setPuntos(Integer puntos) {
		this.puntos = puntos;
	}
	
	public void depositar(Double monto){
		super.depositar(monto);
		calcularPuntos(monto);
	}


	private void calcularPuntos(Double monto) {
		this.puntos += ((Double) (monto*0.10)).intValue();
		
	}
	
	
}
