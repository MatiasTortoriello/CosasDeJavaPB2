package unlam.practicame;

public class Movil extends Dispositivo{
	int imei;
	boolean registroMedianteBiometria = false;
	
	public Movil(String so, String ip, String localidad, int imei,
			boolean registroMedianteBiometria) {
		super( so, ip, localidad);
		this.imei = imei;
		this.registroMedianteBiometria = registroMedianteBiometria;
		
	}

}
