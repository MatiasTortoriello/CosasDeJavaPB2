import java.util.ArrayList;

public class Casa {
	private ArrayList<Habitacion> habitaciones = new ArrayList<Habitacion>();
}
