package ar.unla.pb2;

import static org.junit.Assert.assertEquals;

import org.junit.Test;

public class testBanco {
	@Test
	public void testQueSePuedaAgregarUnaCuentaAlBanco() {
		String nombreBanco = "Rio";
		Banco banco = new Banco(nombreBanco);
		
		Integer idCuenta = 1;
		Double  saldoInicial = 1000.0;
		Integer idCliente = 1;
		String nombre ="German";
		Cliente cliente = new Cliente(idCliente ,nombre );
		Cuenta cuenta = new Cuenta(idCuenta ,cliente ,saldoInicial );
		banco.agregarCuenta(cuenta);
		Integer valorEsperado = 1;
		Integer valorObtenido = banco.obtenerCantidadDeCuentas();
		assertEquals(valorEsperado,valorObtenido);				
	}
	@Test
	public void testQueSePuedaEncontrarUnbaCuentaPorIdEnUnBanco() {
		String nombreBanco = "Rio";
		Banco banco = new Banco(nombreBanco);
		
		Integer idCuenta = 1;
		Double  saldoInicial = 1000.0;
		Integer idCliente = 1;
		String nombre ="German";
		Cliente cliente = new Cliente(idCliente ,nombre );
		Cuenta cuenta = new Cuenta(idCuenta ,cliente ,saldoInicial );
		Cuenta cuenta1 = new Cuenta(idCuenta ,cliente ,saldoInicial );
		banco.agregarCuenta(cuenta);
		Cuenta cuentaEncontrada= banco.buscarCuentaPorId(idCuenta);
		assertEquals(cuentaEncontrada,cuenta1);
		
	}
	
	@Test
	public void queDadaUnaCuentaConSaldo1000YOtraCusntaconSaldo200PuedaRealizarseUnaTransferenciaDeMonto100YElSaldoDeLaPrimerCuentaSea900YElSaldoDeLaOtraCuentaSea300() {
		
	}
}
