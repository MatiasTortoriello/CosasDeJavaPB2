package unlam.practicame;

public class AltaDeUsuario extends Transaccion {

	public AltaDeUsuario(){
		TipoTransaccion tipo = TipoTransaccion.NO_MONETARIA;
	}
	
	
}