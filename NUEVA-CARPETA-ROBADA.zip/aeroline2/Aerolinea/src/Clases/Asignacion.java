package Clases;

import java.util.ArrayList;
import java.util.List;

public class Asignacion {

	Pasajero nuevoPasajero;
	Asiento asiento;
	
	List <Pasajero> pasajeros;
	List <Asiento> asientos;
	
	public Asignacion(Pasajero nuevoPasajero, Asiento asiento) {
		this.nuevoPasajero = nuevoPasajero;
			this.asiento = asiento;
			this.pasajeros = new ArrayList <Pasajero>();
			this.asientos = new ArrayList <Asiento>();
	}

	public Pasajero getNuevoPasajero() {
		return nuevoPasajero;
	}

	public void setNuevoPasajero(Pasajero nuevoPasajero) {
		this.nuevoPasajero = nuevoPasajero;
	}

	public Asiento getAsiento() {
		return asiento;
	}

	public void setAsiento(Asiento asiento) {
		this.asiento = asiento;
	}

	public List<Pasajero> getPasajeros() {
		return pasajeros;
	}

	public void setPasajeros(List<Pasajero> pasajeros) {
		this.pasajeros = pasajeros;
	}

	public List<Asiento> getAsientos() {
		return asientos;
	}

	public void setAsientos(List<Asiento> asientos) {
		this.asientos = asientos;
	}
	
	

}
