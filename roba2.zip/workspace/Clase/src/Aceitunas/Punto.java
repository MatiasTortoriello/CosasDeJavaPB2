package Aceitunas;

public class Punto {
	
	private int x;
	private int y;
	
	public Punto(int x, int y) {
		super();
		this.x = x;
		this.y = y;
	}
	
	public double getDistancia () {
		return Math.hypot(x, y);
	}

	public int getX() {
		return x;
	}
}
