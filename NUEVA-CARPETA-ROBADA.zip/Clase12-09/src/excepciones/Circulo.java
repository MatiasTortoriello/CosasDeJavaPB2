package excepciones;

public class Circulo {

	private double radio;
	private Punto centro;

	public Circulo(double radio)  {
		this.centro = new Punto();
		try{
		setRadio(radio);
		} catch (Exception e){
			throw new CirculoException(e);
		}
		
	}
	
	public void setRadio(double radio) {
		if (radio < 0)
			throw new RadioNegativoException();
		this.radio = radio;
	}
	
	static class Punto {
		private double x;
		private double y;

		public Punto() {
			x = 0;
			y = 0;
		}
		
	}

}
