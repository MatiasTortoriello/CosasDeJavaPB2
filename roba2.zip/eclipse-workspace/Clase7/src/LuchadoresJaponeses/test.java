package LuchadoresJaponeses;

public class test {
	
	public static void main(String[] args) {
		
		Luchadores lista = Archivo.leerArchivo("Sumo");
		lista.calcularDominados();
		Archivo.guardarArchivo("sumo", lista);
	}
}
