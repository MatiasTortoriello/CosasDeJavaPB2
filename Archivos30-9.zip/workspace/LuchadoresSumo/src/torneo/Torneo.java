package torneo;

public class Torneo {
	public void calcularDominios() {
		
	}
}
