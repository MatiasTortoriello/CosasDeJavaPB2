package test.hab;

import static org.junit.Assert.*;

import java.util.ArrayList;

import org.junit.Test;

import dominio.Habitante;
import dominio.Secretaria;
import dominio.Vivienda;

public class TestHabitantes {

	@Test
	public void queSePuedaAgregarUnHabitante() {
		Secretaria secretaria = new Secretaria();
		
		String nombre = "pepe";
		Integer dni = 40000000;
		
		Habitante habitante = new Habitante(dni, nombre);
		
		secretaria.agregarHabitante(habitante);
		
		Integer valorEsperado = 1;
		Integer valorObtenido = secretaria.obtenerCantidadDeHabitantes();
		
		assertEquals(valorEsperado, valorObtenido);		
	}
	
	@Test
	public void queSePuedaAgregarUnaVivienda() {
		Secretaria secretaria = new Secretaria();
		
		String direccion = "pepe";
		Integer numero = 123;
		String municipio = "San Justo";
		Integer id = 1;
		
		Vivienda vivienda = new Vivienda(direccion, numero, municipio, id);
		
		secretaria.agregarVivienda(vivienda);
		
		Integer valorEsperado = 1;
		Integer valorObtenido = secretaria.obtenerCantidadDeViviendas();
		
		assertEquals(valorEsperado, valorObtenido);		
	}
	
	@Test
	public void queSePuedaAsignarUnPorcentajeDeUnaCasaParaUnHabitante() {
		Secretaria secretaria = new Secretaria();
		
		String direccion = "Galan";
		Integer numero = 123;
		String municipio = "San Justo";
		Integer id = 1;
		
		String nombre = "pepe";
		Integer dni = 40000000;
		
		Habitante habitante = new Habitante(dni, nombre);
		Vivienda vivienda = new Vivienda(direccion, numero, municipio, id);
		
		Double porcentaje = 10.0;
		
		secretaria.asignarPropiedad(vivienda, habitante, porcentaje);
		
		Integer valorEsperado = 1;
		Integer valorObtenido = secretaria.obtenerCantidadDeRegistrosDePropiedad();
		
		assertEquals(valorEsperado, valorObtenido);		
	}
	
	@Test
	public void queSePuedaAsignarUnPorcentajeDeUnaCasaADosHabitante() {
		Secretaria secretaria = new Secretaria();
		
		Habitante habitante = new Habitante(4000000, "Pepe");
		
		Habitante habitante2 = new Habitante(3604460, "Pipo");
		
		Vivienda vivienda = new Vivienda("Galan", 123, "San Justo", 1);
		
		secretaria.asignarPropiedad(vivienda, habitante, 50.0);
		secretaria.asignarPropiedad(vivienda, habitante2, 50.0);
		
		Integer valorEsperado = 2;
		Integer valorObtenido = secretaria.obtenerCantidadDeRegistrosDePropiedad();
		
		assertEquals(valorEsperado, valorObtenido);		
	}
	
	@Test
	public void queNoSePuedaExcederElPorcentajeAlAsignarPropiedad() {
		Secretaria secretaria = new Secretaria();
		
		Habitante habitante = new Habitante(4000000, "Pepe");
		
		Habitante habitante2 = new Habitante(3604460, "Pipo");
		
		Vivienda vivienda = new Vivienda("Galan", 123, "San Justo", 1);
		
		assertTrue(secretaria.asignarPropiedad(vivienda, habitante2, 50.0));
		assertFalse(secretaria.asignarPropiedad(vivienda, habitante2, 60.0));
	}

	@Test
	public void queSePuedaObtenerUnaListaDeAquellasViviendasCuyoPorcentajeSeaMenorAlCienPorCiento(){
Secretaria secretaria = new Secretaria();
		
		Habitante habitante = new Habitante(4000000, "Pepe");
		Habitante habitante2 = new Habitante(3604460, "Pipo");
		
		Vivienda vivienda = new Vivienda("Galan", 123, "San Justo", 1);
		Vivienda vivienda2 = new Vivienda("Galan", 123, "San Justo", 2);
		Vivienda vivienda3 = new Vivienda("Galan", 123, "San Justo", 3);

		secretaria.asignarPropiedad(vivienda, habitante, 70.0);

		secretaria.asignarPropiedad(vivienda2, habitante, 30.0);

		secretaria.asignarPropiedad(vivienda2, habitante, 70.0);

		secretaria.asignarPropiedad(vivienda3, habitante, 10.0);
		
		
		ArrayList<Vivienda> viviendasMenorCien = secretaria.obtenerViviendasCuyoPorcentajeEsMenorAlCienPorCiento();
		
		Integer valorEsperado = 2;
		Integer valorObtenido = viviendasMenorCien.size();
		
		assertEquals(valorEsperado, valorObtenido);
	}
}
