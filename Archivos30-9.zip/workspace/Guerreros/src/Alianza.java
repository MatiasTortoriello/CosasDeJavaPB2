import java.util.LinkedList;
import java.util.List;

public class Alianza extends Unidad {
	List<Tropa> tropas = new LinkedList<Tropa>();
	
	
	public void recibirDano(){
		tropaRandom.recibirDano;
	}
}
