package ar.unlam.miCalculadora;

public class Calculadora {

	public Integer sumar(Integer operando1, Integer operando2) {
		
		return operando1 + operando2;
	}

	public Double dividir(Double numerador, Double denominador) {
		return (double) (numerador/denominador);
	}

	public Double porcentaje(Double numero, Double porcentaje) {
		return this.dividir(numero*porcentaje,100.0);
	}

	public Double multiplicar(Double operador1, Double operador2) {
		// TODO Auto-generated method stub
		return operador1*operador2;
	}
}
