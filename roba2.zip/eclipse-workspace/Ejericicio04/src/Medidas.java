
public enum Medidas {
	//Instancias Estaticas
	METROS(1,0.001,3.28,0.0006),
	KILOMETROS(1000,1,3280.83, 0.62),
	PIES(0.30,0.0003,1,0.00018),
	MILLAS(1609.344, 1.609344,5280,1);
	
	//Atributos
	private double metros;
	private double kilometros;
	private double pies;
	private double millas;
	
	private Medidas(double metros, double kilometros, double pies, double millas) {
		this.metros = metros;
		this.kilometros = kilometros;
		this.pies = pies;
		this.millas = millas;
	}
	
	public double conversion(double cantidad, Medidas origen, Medidas destino) {
		
		switch(origen) {
		case METROS:
			return conversionDeMetros(cantidad, destino);
		case KILOMETROS:
			return conversionDeKilometros(cantidad, destino);
		case PIES:
			return conversionDePies(cantidad, destino);
		case MILLAS:
			return conversionDeMillas(cantidad, destino);
		default:
			return cantidad;
			
		}
		
		
	}
	
	public double conversionDeMetros(double cantidad, Medidas destino) {
		switch (destino) { 
		case KILOMETROS:
			return cantidad*METROS.kilometros;
		case PIES:
			return cantidad*METROS.pies;
		case MILLAS:
			return cantidad*METROS.millas;
		default:
			return cantidad;
		
		}
	}
	
	public double conversionDeKilometros(double cantidad, Medidas destino) {
		switch (destino) { 
		case METROS:
			return cantidad*KILOMETROS.metros;
		case PIES:
			return cantidad*KILOMETROS.pies;
		case MILLAS:
			return cantidad*KILOMETROS.millas;
		default:
			return cantidad;
		
		}
	}
	
	public double conversionDePies(double cantidad, Medidas destino) {
		switch (destino) { 
		case METROS:
			return cantidad*PIES.metros;
		case KILOMETROS:
			return cantidad*PIES.kilometros;
		case MILLAS:
			return cantidad*PIES.millas;
		default:
			return cantidad;
		
		}
	}
	
	public double conversionDeMillas(double cantidad, Medidas destino) {
		switch (destino) { 
		case METROS:
			return cantidad*MILLAS.metros;
		case KILOMETROS:
			return cantidad*MILLAS.kilometros;
		case PIES:
			return cantidad*MILLAS.pies;
		default:
			return cantidad;
		
		}
	}
	
}
