package ar.edu.unlam.Class;

public class ComplejoNoEncontrado extends Exception {

}
