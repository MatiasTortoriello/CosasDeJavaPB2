package finalPrograAv;

public interface ArtefactoElectronico {

		public int getConsumo();
}
