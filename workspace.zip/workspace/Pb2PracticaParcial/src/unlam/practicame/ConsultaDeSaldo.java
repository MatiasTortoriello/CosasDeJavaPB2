package unlam.practicame;

public class ConsultaDeSaldo extends Transaccion implements Monitoreable{

	public ConsultaDeSaldo(){
		TipoTransaccion tipo = TipoTransaccion.NO_MONETARIA;
	}
	
	
	@Override
	public void monitorear() {
		// TODO Auto-generated method stub
		
	}

}
