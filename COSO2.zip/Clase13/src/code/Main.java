package code;

public class Main {

	public static void main(String[] args) {
		Guerrero g1 = new Guerrero(15);
		Guerrero g2 = new Guerrero(30);
		
		
		g1.atacar(g2);
		g2.atacar(g1);
		
		System.out.println(g1.getVida());
		System.out.println(g2.getVida());
	}

}
