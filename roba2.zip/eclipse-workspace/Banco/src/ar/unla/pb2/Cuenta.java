package ar.unla.pb2;

import java.util.Objects;

public class Cuenta {

	private Cliente cliente;
	private Integer idCuenta;
	private Double saldoInicial;

	public Cuenta(Integer idCuenta, Cliente cliente, Double saldoInicial) {
		// TODO Auto-generated constructor stub
		this.idCuenta = idCuenta;
		this.cliente = cliente;
		this.saldoInicial = saldoInicial;
	
	}

	public Cliente getCliente() {
		return cliente;
	}

	public void setCliente(Cliente cliente) {
		this.cliente = cliente;
	}

	public Integer getIdCuenta() {
		return idCuenta;
	}

	public void setIdCuenta(Integer idCuenta) {
		this.idCuenta = idCuenta;
	}

	

	public void setSaldoInicial(Double saldoInicial) {
		this.saldoInicial = saldoInicial;
	}

	@Override
	public int hashCode() {
		return Objects.hash(idCuenta);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Cuenta other = (Cuenta) obj;
		return Objects.equals(idCuenta, other.idCuenta);
	}

	public Boolean extraer(double monto) {
		// TODO Auto-generated method stub
		Boolean exitoso = false;
		if(monto <= this.saldoInicial) {
			this.saldoInicial -= monto;
			exitoso = true;
		}
		return exitoso;
	}

	public Double getSaldoInicial() {
		// TODO Auto-generated method stub
		return this.saldoInicial;
	}
	
	

}
