package ar.edu.unlam.pb2;

import static org.junit.Assert.*;

import org.junit.Test;

public class TestBanco {
	@Test
	public void queSePuedaAgregarUnCuentaAlBanco() {
		String nombreDeBanco = "Rio";

		Banco banco = new Banco(nombreDeBanco);

		Integer id = 1;
		Integer idCliente = 1;
		String nombre = "German";
		Cliente cliente = new Cliente(idCliente, nombre);
		Double saldoInicial = 1000.0;
		Cuenta cuenta = new Cuenta(id, cliente, saldoInicial);
		banco.agregarCuenta(cuenta);
		Integer valorEsperado = 1;
		Integer valorObtenido = banco.obtenerCantidadDeCuentas();
		assertEquals(valorEsperado, valorObtenido);
	}

	@Test
	public void queSePuedaEncontraerUnaCuentaPorIdEnUnBanco() {

		String nombreDeBanco = "Rio";

		Banco banco = new Banco(nombreDeBanco);

		Integer id = 1;
		Integer idCliente = 1;
		String nombre = "German";
		Cliente cliente = new Cliente(idCliente, nombre);
		Double saldoInicial = 1000.0;
		Cuenta cuenta = new Cuenta(id, cliente, saldoInicial);
		Cuenta cuenta1 = new Cuenta(id, cliente, saldoInicial);
		banco.agregarCuenta(cuenta);
		Cuenta cuentaEncontrada = banco.buscarCuentaPorId(id);
		assertEquals(cuentaEncontrada, cuenta);

	}

	// TestCuenta
	/*
	 * Tests: test depositar plata -> devuelve void test extraer plata ->
	 * devuelve un boolean fondo insuficiente que se pueda hacer una
	 * transferencia entre dos cuentas
	 */

	@Test
	public void queSePuedaHcerUnaTransferenciaEntreDosCuentas() {

		String nombreDeBanco = "Rio";

		Banco banco = new Banco(nombreDeBanco);
		Integer id = 1;
		Integer idCliente = 1;
		String nombre = "German";
		Cliente cliente = new Cliente(idCliente, nombre);
		Double saldoInicial=1000.0;
		Cuenta cuenta=new Cuenta(idCliente, cliente, saldoInicial);
		
		Integer idDetino = 2;
		Integer idClienteDestino = 3;
		String nombreDestino = "Juan";
		Cliente clienteDestino = new Cliente(idClienteDestino, nombreDestino);
		Double saldoInicialDestino=1000.0;
		Cuenta cuentaDestino=new Cuenta(idClienteDestino, clienteDestino, saldoInicialDestino);
		
		banco.agregarCuenta(cuenta);
		banco.agregarCuenta(cuentaDestino);
		
		banco.hacerTranferencia(cuenta, cuentaDestino, 500.0);
		Double resultadoOrigen=cuenta.getSaldoInicial();
		Double esperadoOrigen=500.0;
		
		Double resultadoDestino=cuentaDestino.getSaldoInicial();
		Double EsperadoDestino=1500.0;
		
		
		assertEquals(esperadoOrigen,resultadoOrigen);
		assertEquals(EsperadoDestino,resultadoDestino);
	
		
		
		
		 
		/** SOBREESCRITURA DE METODOS
		 * 
		 * creo el banco creo dos cuentas con sus clientes hacer una
		 * trasnferencia que recibe las dos cuentas y otro que recibe los id de
		 * las cuentas metodos: busco la cuenta origen y le saco plata busco la
		 * cuenta destino y le pongo la plata verificar si el llego
		 * 
		 */
	}

	@Test
	public void queNoSePuedaHacerLaTransferenciaPorFaltaPlata() {
		/*
		 * monto insuficiente lo sabe la cuenta, metodo que verfica si tiene o
		 * no
		 */
	}

}
