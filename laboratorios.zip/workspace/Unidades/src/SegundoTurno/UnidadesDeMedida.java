package SegundoTurno;

public class UnidadesDeMedida {

	public static double pasaje(double cantidad, Medida origen, Medida destino) {

		double resultado = 0;
		if (destino == Medida.KILOMETROS)
			resultado = cantidad * (origen.getValorKilometro());

		if (destino == Medida.METROS)
			resultado = cantidad * (origen.getValorMetro());

		if (destino == Medida.PIE)
			resultado = cantidad * (origen.getValorPies());

		if (destino == Medida.MILLA)
			resultado = cantidad * (origen.getValorMilla());

		return resultado;
	}

	public static void main(String[] args) {
		System.out.println(pasaje(1000, Medida.METROS, Medida.KILOMETROS));
	}
}
