package Alarma;

public class Sensor {
private int id;
private String nombreDelSensor;
private Zona zona;
private int estado;

public Sensor (int id, String nombreDelSensor, Zona zona, int estado){
	this.id=id;
	this.nombreDelSensor=nombreDelSensor;
	this.zona=zona;
	this.estado=estado;
}

public int getId() {
	return id;
}

public void setId(int id) {
	this.id = id;
}

public String getNombreDelSensor() {
	return nombreDelSensor;
}

public void setNombreDelSensor(String nombreDelSensor) {
	this.nombreDelSensor = nombreDelSensor;
}

public Zona getZona() {
	return zona;
}

public void setZona(Zona zona) {
	this.zona = zona;
}

public int getEstado() {
	return estado;
}

public void setEstado(int estado) {
	this.estado = estado;
}

public String toString (){
	String mensaje="";
	mensaje = "Nombre: "+this.nombreDelSensor+"\n ID: "+this.id+"\n Estado: "+this.estado+"\n Zona: "+this.zona;
	return mensaje;
}


}
