
public class ConTalisman {

	public int getDanio() {

	}

	public int getDefensa() {

	}
}
