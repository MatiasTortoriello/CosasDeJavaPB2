package Alarma;

public enum Zona {
ENTRADA,PUERTA_TRASERA,INTERIOR;
}
