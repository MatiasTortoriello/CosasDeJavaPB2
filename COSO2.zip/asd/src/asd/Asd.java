package asd;

public class Asd {
	public static void main(String[] args) {
		System.out.println("sadad");
	}

}
