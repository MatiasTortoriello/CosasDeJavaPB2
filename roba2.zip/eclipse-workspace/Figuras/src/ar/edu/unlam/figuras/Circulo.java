package ar.edu.unlam.figuras;

public class Circulo {
	
	private String nombre;
	private String color;

	public Circulo(String nombre) {
		this.nombre = nombre;
	}
	
	public Circulo(String nombre, String color) {
		this.nombre = nombre;
		this.color = color;
	}

	public String obtenerNombre() {
		return this.nombre;
	}

	public String obtenerColor() {
		return this.color;
	}

}
