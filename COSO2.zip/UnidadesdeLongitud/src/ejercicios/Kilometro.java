package ejercicios;

public class Kilometro {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
