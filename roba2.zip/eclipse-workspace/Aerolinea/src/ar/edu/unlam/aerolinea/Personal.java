package ar.edu.unlam.aerolinea;

public class Personal {

	private String nombre;

	public Personal(String nombre) {
		this.nombre = nombre;
	}
}
