package ar.edu.unlam.pb2.eva03;

import java.util.ArrayList;

public class PolizaCombinadoFamiliar extends Poliza implements SegurosGenerales, SegurosDeVida{
	private Vivienda vivienda;
	private ArrayList<Persona>beneficiarios=new ArrayList();

	public PolizaCombinadoFamiliar(Integer nUMERO_DE_POLIZA, Persona asegurado, Double sUMA_ASEGURADA, Double pRIMA) {
		super(nUMERO_DE_POLIZA, asegurado, sUMA_ASEGURADA, pRIMA);
		// TODO Auto-generated constructor stub
	}

	@Override
	public void agregarBeneficiario(Persona hijo, TipoDeBeneficiario hijo2) {
		// TODO Auto-generated method stub
		hijo.setTipo(hijo2);
		beneficiarios.add(hijo);
		
	}

	@Override
	public Integer obtenerCantidadDeBeneficiarios() {
		// TODO Auto-generated method stub
		return beneficiarios.size();
	}

	@Override
	public void agregarBienAsegurado(Auto auto) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void agregarBienAsegurado(Vivienda vivienda) {
		// TODO Auto-generated method stub
		this.vivienda=vivienda;
	}

}
