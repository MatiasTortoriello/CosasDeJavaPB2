package LuchadoresJaponeses;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Scanner;

public class Archivo {
	
	public static Luchadores leerArchivo(String nombreArch) {
		
		File file = null;
		Scanner scanner = null;
		
		int cantLuchadores;
		Luchadores luchadores = null;
		
		try {
			
			file = new File (nombreArch + ".in");
			scanner = new Scanner(file);
			
			cantLuchadores = scanner.nextInt();
			scanner.nextLine();
			
			luchadores = new Luchadores(cantLuchadores);
			int i = 0;
			
			while(scanner.hasNextLine()) {
				
				int peso = scanner.nextInt();
				int altura = scanner.nextInt();
				Luchador luchador = new Luchador(peso, altura);
				luchadores.agregar(i, luchador);
				i++;
			}
			
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			scanner.close();
		}
		
		return luchadores;
	}
	
	public static void guardarArchivo(String nombreArch, Luchadores lista) {
			
			FileWriter file = null;
			PrintWriter printwritter = null;
			
			try {
				
				file = new FileWriter (nombreArch + ".out");
				printwritter = new PrintWriter(file);
				
				for (int i = 0; i < lista.getLenght(); i++) {
					printwritter.println(lista.getLuchadores(i));
				}
				
			} catch (Exception e) {
				e.printStackTrace();
			} finally {
				if(file != null) {
					try {
						file.close();
					}
					catch (IOException e) {
						e.printStackTrace();
					}
				}
			}

		}
}
