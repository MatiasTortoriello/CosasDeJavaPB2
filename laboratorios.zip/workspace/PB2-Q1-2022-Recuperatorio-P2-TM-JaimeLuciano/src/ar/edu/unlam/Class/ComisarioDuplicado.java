package ar.edu.unlam.Class;

public class ComisarioDuplicado extends Exception {

}
