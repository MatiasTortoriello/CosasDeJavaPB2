
public enum MedioDePago {
	EFECTIVO(0,0),
	DEBITO(0,10),
	CREDITO(1.99,0);
	
	double comisionPorcentual;
	double comisionFija;
	
	
	
	private MedioDePago(double comisionPorcentual, double comisionFija){
		this.comisionPorcentual = comisionPorcentual;
		this.comisionFija = comisionFija;
	}
}
