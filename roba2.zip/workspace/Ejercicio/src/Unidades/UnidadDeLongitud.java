package Unidades;

import java.math.BigDecimal;

public abstract class UnidadDeLongitud {
	
	protected BigDecimal valor;

	public UnidadDeLongitud (BigDecimal valor) {
		super();
		this.valor = valor;
	}
	
	public abstract Metro toMetro();
	public abstract Pie toPie();
	public abstract Milla toMilla();
	public abstract Kilometro toKilometro();
	
	public abstract UnidadDeLongitud crear(BigDecimal valor);
	public abstract UnidadDeLongitud pasarAMiUnidad(UnidadDeLongitud otra);
	

	public abstract UnidadDeLongitud Sumar(UnidadDeLongitud otra);
	
}
