
public abstract class Instrumento {

	private String nombre;
	private int tono;
	private String descripcion;

	public Instrumento(String name,int tono, String descr){
		this.nombre=name;
		this.tono=tono;
		this.descripcion=descr;
	}

	public void tocar() {
	};

}
