package unlam;

public class Comisario implements Comparable<Comisario> {
	Integer id ;
	Integer edad ;
	TipoDeComisario comisario ;
	String nombre ;

	public Comisario(Integer id, Integer edad , TipoDeComisario comisario, String nombre) {
		// TODO Auto-generated constructor stub
		this.id= id ;
		this.edad= edad ;
		this.comisario = comisario ;
		this.nombre = nombre ;
		
	}

	@Override
	public int compareTo(Comisario o) {
		// TODO Auto-generated method stub
		return 0;
	}

}
