import java.util.Scanner;

//Un m�todo est�tico que recibe la cantidad, la unidad origen y la unidad destino, retornando 
//la cantidad en la unidad destino. Manejarlo con Strings
public class Metodo1 {
	
	
	
	
	
	
	public static double conversor(double cantidad, String unidOrigen, String unidDestino){
		double aMetros;
		switch (unidOrigen.toLowerCase()){
		case "pies":
			aMetros=cantidad/3.2808;
			break;
		case "millas":
			aMetros=cantidad/0.00062137;
			break;
		case "metros":
			aMetros=cantidad;
			break;
		case "kilometros":
			aMetros=cantidad*1000;
			break;
		default:
			System.out.println("NO SE COMPRENDE LA UNIDAD DE ORIGEN");
			return -1;
		}
		switch (unidDestino.toLowerCase()){
		case "pies":
			return aMetros*3.2808;
		case "millas":
			return aMetros*0.00062137;
		case "metros":
			return aMetros;
		case "kilometros":
			return aMetros/1000;
		default:
			System.out.println("NO SE COMPRENDE LA UNIDAD DE DESTINO");
			return -1;
		}
	}
	
	public static void main(String[] args) {
		String origen,destino;
		double res;
		Scanner teclado = new Scanner(System.in);
		
		System.out.println("ingrese el origen");
		origen = teclado. nextLine();
		System.out.println("ingrese el destino");
		destino = teclado. nextLine();
		
		teclado.close();
		
		if((res=conversor(10,origen,destino)) != -1)
			System.out.println(res);
		
		
	}
}
