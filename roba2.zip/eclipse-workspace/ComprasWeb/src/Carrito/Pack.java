package Carrito;

public abstract class Pack {
	
	protected double precio;
	protected List<Articulo> articulos = new Linked;
	
	abstract public Pack () {
		this.precioTotal = 0;
	}
}
