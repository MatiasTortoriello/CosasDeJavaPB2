package Clases;

import java.util.ArrayList;
import java.util.List;

public class Avion {

	private Integer identificador;
	private String modelo;
	private Integer capacidad;
	private String tipoAvion;
	private List <Asignacion> asignaciones;
	
	public Avion(Integer identificador, String modelo, Integer capacidad, String tipoAvion) {
		this.identificador = identificador;
		this.modelo = modelo;
		this.capacidad = capacidad;
		this.tipoAvion = tipoAvion;
		this.setAsignaciones(new ArrayList <Asignacion>());
	}

	public Integer getIdentificador() {
		return identificador;
	}

	public String getModelo() {
		return modelo;
	}

	public Integer getCapacidad() {
		return capacidad;
	}

	public String getTipoAvion() {
		return tipoAvion;
	}

	public void setIdentificador(Integer identificador) {
		this.identificador = identificador;
	}

	public void setModelo(String modelo) {
		this.modelo = modelo;
	}

	public void setCapacidad(Integer capacidad) {
		this.capacidad = capacidad;
	}

	public void setTipoAvion(String tipoAvion) {
		this.tipoAvion = tipoAvion;
	}

	public void agregarAsignacion(Asignacion asignacion) {
		asignaciones.add(asignacion);
	}

	public List <Asignacion> getAsignaciones() {
		return asignaciones;
	}

	public void setAsignaciones(List <Asignacion> asignaciones) {
		this.asignaciones = asignaciones;
	}
	
	@Override
	public String toString() {
		return "Avion [asignaciones=" + asignaciones + "]";
	}

	
}
