package PB.Parcial2;

public class capacidadExcedidaExeption extends Exception {

}
