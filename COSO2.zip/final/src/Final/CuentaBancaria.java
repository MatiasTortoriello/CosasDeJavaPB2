package Final;

import javax.sql.rowset.spi.TransactionalWriter;

public class CuentaBancaria {
	protected double balance;
	
	public CuentaBancaria(double inicBalance){
		balance = inicBalance;
	}

	public double getBalance() {
		return balance;
	}

	public void depositar(double cantidad){
		balance += cantidad;
	}
	
	public void extraer(double cantidad){

		try{
		if (balance - cantidad < 0)
			throw new FondosInsuficientesException();
		else
			balance -= cantidad;
		}
		catch(FondosInsuficientesException e){
			System.out.println(e.getMessage(cantidad));
		}
		
	}
	
}
