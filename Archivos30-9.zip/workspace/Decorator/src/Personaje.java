
public class Personaje extends Unidad {
	private int danio = 10;
	private int defensa = 100;
	
	public int getDanio() {
		return danio;
	}

	public int getDefensa() {
		return defensa;
	}
}
