
public class Nivel {	
	
	private static int nivelActual = 0;
	private Entidad[][] disenioNivel;
	
	Nivel()
	{
		NivelDirector.crearNivel0();
	}
	
}
