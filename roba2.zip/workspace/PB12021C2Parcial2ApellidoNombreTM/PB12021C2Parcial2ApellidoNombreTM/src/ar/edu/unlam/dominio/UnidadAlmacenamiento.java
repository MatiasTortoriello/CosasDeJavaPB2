package ar.edu.unlam.dominio;

public class UnidadAlmacenamiento {
	Archivo[] archivos;
	double capacidadMaxima;
	char letra;
	
	public UnidadAlmacenamiento() {
		
	}
	
	/**
	 * Agrega un archivo al array de archivos, solo si hay espacio en el array
	 * y el archivo que se agregará no supera la capacidad máxima.
	 *
	 * @param archivo Archivo que se agregará.
	 * @return Verdadero en caso de éxito
	 */
	public boolean agregarArchivo(Archivo archivo) {
		return false;
	}

	/**
	 * Obtiene un array de archivos de tipo JPG ordenados por nombre descendente
	 *
	 * @return 	Array de archivos JPG con orden descendente por nombre 
	 */
	public Archivo[] obtenerAchivosTipoJpgOrdenadosPorNombreDesc() {
		return null;
	}

	/**
	 * Calcula el espacio ocupado por los archivos en la unidad de almacenamiento
	 *
	 * @return 	valor del espacio almacenado 
	 */
	public double informarEspacioAlmacenado() {
		return 0d;
	}
}
