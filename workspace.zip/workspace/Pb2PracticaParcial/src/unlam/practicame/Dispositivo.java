package unlam.practicame;

public abstract class Dispositivo {
	
	String so;
	String ip;
	String localidad;

	public Dispositivo( String so, String ip, String localidad) {
		this.so = so;
		this.ip = ip;
		this.localidad = localidad;
	}

	public String getSo() {
		return so;
	}

	public void setSo(String so) {
		this.so = so;
	}

	public String getIp() {
		return ip;
	}

	public void setIp(String ip) {
		this.ip = ip;
	}

	public String getLocalidad() {
		return localidad;
	}

	public void setLocalidad(String localidad) {
		this.localidad = localidad;
	}
	
	
	
}
