
public class Metodo2 {
	
	
	
	
	
	public static double(double cantidad, Unidades origen ,Unidades destino){
		return 
	}
}
