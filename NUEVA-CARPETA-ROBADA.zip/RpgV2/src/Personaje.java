
public class Personaje extends ElementoDeJuego{


	
	@Override
	public Integer getDanio() {
		return 0;
	}

}
