package ar.edu.unlam.pb2;

public class Archivo {

	private String nombre;
	private TipoArchivo tipo;
	
	public Archivo(String nombre, TipoArchivo tipo) {
		this.nombre = nombre;
		this.tipo = tipo;
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public TipoArchivo getTipo() {
		return tipo;
	}

	public void setTipo(TipoArchivo tipo) {
		this.tipo = tipo;
	}
	
}
