package ar.edu.unlam.pb2;


import ar.edu.unlam.pb2.interfaces.Multeable;


public class Auto extends MedioTransporte implements Multeable {
	private String patente;
	private Integer velocidadActual;
	private Integer CantidadMaximaDePasajeros = 5;
	private Integer velocidadMaximaPermitida;
	private Double peso;
	private Double pesoMaximo=1000.0;
	private Boolean cruzarEnRojo;
	private Boolean papelesAlDia;

	public Auto(String patente, int cantidadMaximaDePasajeros, int velocidadMaximaPermitida, double latitud,
			double longitud) {
		super(latitud, longitud);
		this.patente = patente;
		this.velocidadActual = 0;
		this.velocidadMaximaPermitida = velocidadMaximaPermitida;
		this.peso=500.0;
		this.cruzarEnRojo=false;
		this.papelesAlDia=true;
	}

	public Integer getVelocidadActual() {
		return velocidadActual;
	}

	public void setVelocidadActual(Integer velocidadActual) {
		this.velocidadActual = velocidadActual;
	}

	public Integer getCantidadMaximaDePasajeros() {
		return CantidadMaximaDePasajeros;
	}

	public Boolean getCruzarEnRojo() {
		return cruzarEnRojo;
	}

	public void setCruzarEnRojo(Boolean cruzarEnRojo) {
		this.cruzarEnRojo = cruzarEnRojo;
	}

	public Boolean getPapelesAlDia() {
		return papelesAlDia;
	}

	public void setPapelesAlDia(Boolean papelesAlDia) {
		this.papelesAlDia = papelesAlDia;
	}

	public void setCantidadMaximaDePasajeros(Integer cantidadMaximaDePasajeros) {
		CantidadMaximaDePasajeros = cantidadMaximaDePasajeros;
	}

	public String getPatente() {
		return patente;
	}

	public void setPatente(String patente) {
		this.patente = patente;
	}

	public Integer getVelocidadMaximaPermitida() {
		return velocidadMaximaPermitida;
	}

	public void setVelocidadMaximaPermitida(Integer velocidadMaximaPermitida) {
		this.velocidadMaximaPermitida = velocidadMaximaPermitida;
	}

	@Override
	public Boolean superoVelocidadMaxima() throws VelocidadMaximaException {
		if(this.velocidadActual <=this.velocidadMaximaPermitida){
			return false;
		}
		throw new VelocidadMaximaException();
	}
	public void cruzarMal(){
		this.cruzarEnRojo=true;
	}
	@Override
	public Boolean superoPesoMaximoCarga() throws PesoMaximoException {
		if(this.peso <=this.pesoMaximo){
			return false;
		}
		throw new PesoMaximoException();
	}

	@Override
	public Boolean cruzoEnRojo() throws NoRespetoSemaforoException {
		if(!this.cruzarEnRojo){
			return false;
		}
		throw new NoRespetoSemaforoException();
	}

	@Override
	public Boolean estaEnRegla() throws FlojoDePapelesException {
		if(this.papelesAlDia){
			return true;
		}
		throw new FlojoDePapelesException();
	}

	public Double getPeso() {
		return peso;
	}

	public void setPeso(Double peso) {
		this.peso = peso;
	}

	public Double getPesoMaximo() {
		return pesoMaximo;
	}

	public void setPesoMaximo(Double pesoMaximo) {
		this.pesoMaximo = pesoMaximo;
	}

}
