package carrito;

public class Articulo implements Item{

	public Articulo() {
		private String n;
		private double p;
	}

}
