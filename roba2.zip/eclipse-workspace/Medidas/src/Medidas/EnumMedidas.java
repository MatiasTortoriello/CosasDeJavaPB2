package Medidas;

public enum EnumMedidas {
	KILOMETROS,
	PIES,
	MILLAS,
	METROS
	
}
