package EjercicioCarrito;

public class PackFijo extends Pack{

	public PackFijo(double fijo) {
		precio = fijo;
	}
	
	@Override
	public void agregarArticulo(Articulo articulo) {
		this.articulos.add(articulo);
	}
	

}
