package j;
import pk.Punto;

class Main {
	
	public static void main(String[] args) {
		Punto uno = new Punto(2,3);
		Punto dos = new Punto(1,2);
		
		if (!uno.equals(dos))		//por defecto solo da igual si creo unoBis = uno (si modifico uno se modifica unoBis)
			System.out.println("hola");
	}

}
