package Aceitunas;

public class app {
	
	public static void main(String[] args) {
		ListaTiros lista = Archivo.leerArchivo("entrada");
		Archivo.guardarArchivo("entradas", lista.getRadioMenor());
	}

}
