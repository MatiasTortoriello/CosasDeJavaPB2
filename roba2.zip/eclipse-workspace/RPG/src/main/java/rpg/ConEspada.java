package rpg;

public class ConEspada implements IDa�o {

	private int danio = 10;

	public ConEspada(IDa�o jug) {
		this.danio = this.danio + jug.obtenerDanio();
	}
	
	public int getDanio()
	{
		return this.danio;
	}
	
	public int obtenerDanio() {
		return this.getDanio();
	}

}
