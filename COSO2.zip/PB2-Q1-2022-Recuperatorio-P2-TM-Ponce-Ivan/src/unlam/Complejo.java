package unlam;
import java.util.Set;
import java.util.TreeSet;





public class Complejo implements Comparable<Complejo > {
	Integer id;
	TipoDeComplejo tipoDeComplejo ;
	String nombre; 
	Integer areatotal ;
	private Set<Area> areas;
	private Set<Evento> eventos;

	public Complejo(Integer id, TipoDeComplejo tipoDeComplejo, String nombre, Integer areatotal) {
		// TODO Auto-generated constructor stub}
		this.id = id;
		this.tipoDeComplejo = tipoDeComplejo;
		this.nombre = nombre; 
	    this.areatotal= areatotal;
	    this.areas = new TreeSet<>();
	    this.eventos = new TreeSet<>();
	}

	

	public void agregarArea(Area area) {
		// TODO Auto-generated method stub
		this.areas.add(area);
	}

	public Integer cantidadDeAreas() {
		// TODO Auto-generated method stub
		return this.areas.size();
	}



	public void agregarEvento(Evento evento) {
		// TODO Auto-generated method stub
		this.eventos.add(evento);
	}



	public Integer cantidadDeEventos() {
		// TODO Auto-generated method stub
		return this.eventos.size();
	}



	@Override
	public int compareTo(Complejo arg0) {
		// TODO Auto-generated method stub
		return 0;
	}

}
