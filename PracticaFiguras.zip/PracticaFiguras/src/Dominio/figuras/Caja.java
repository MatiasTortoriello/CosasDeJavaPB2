package Dominio.figuras;

import java.util.ArrayList;

public class Caja {
	
	private ArrayList<Figura> listaFigura;

	public Caja() {
		this.listaFigura = new ArrayList<Figura>();
		
	}

	public void agregarFigurasACaja(Figura figura) {
		this.listaFigura.add(figura);
	}

	public Integer calcularMayoresDeDiez() {
		
		ArrayList<Figura> figurasMayoresDeDiez = new ArrayList<Figura>();
		for (Figura figura : listaFigura) {
			if (figura.getArea() > 10.0) {
				figurasMayoresDeDiez.add(figura);
			}
		}
		return figurasMayoresDeDiez.size();
	}

	public ArrayList<Figura> getListaFigura() {
		return listaFigura;
	}

	public void setListaFigura(ArrayList<Figura> listaFigura) {
		this.listaFigura = listaFigura;
	}
	
	public Integer determinarTipo(){
		ArrayList<Figura> listaDeTipoDeFiguras = new ArrayList<Figura>();
		for (Figura figu : this.listaFigura ) {
			if(figu instanceof Circulo){
				listaDeTipoDeFiguras.add(figu);
			}
		}
		return listaDeTipoDeFiguras.size();
	}
	
	
}
