package code;

import java.util.ArrayList;

public class Resolucion {

	public void resolver(String nombreArchivo) {
		Archivo archivo = new Archivo(nombreArchivo);
		DatosEntrada datos = archivo.leerArchivo();
		int resultado = 0;

		ArrayList<Personaje> personajes = datos.getPersonajes();
		ArrayList<Objeto> objetos = datos.getObjetos();
		int distanciaObjetivo = datos.getDistanciaObjetivo();
		
		for (Personaje p : personajes) {
			for (Objeto o : objetos) {
				if (p.calcularDistancia(o) >= distanciaObjetivo) {
					resultado++;
				}
			}
		}
		
		archivo.guardarArchivo(resultado);
	}

}
