package LuchadoresJaponeses;

public class App {

	public static void main(String[] args) {
		Archivo arch = new Archivo("sumo");
		Torneo t = new Torneo(arch.leerArchivo());
		
		arch.guardarArchivo(t.calcularDominios());
	}
}
