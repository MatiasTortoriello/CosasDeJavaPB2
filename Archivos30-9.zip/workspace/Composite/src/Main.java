
public class Main {
	public static void main(String[] args) {
		Guerrero g1 = new Guerrero(100, 70);
		Guerrero g2 = new Guerrero(100, 10);
		Tropa t1 = new Tropa();
		Tropa t2 = new Tropa();
		
		t1.agregarATropa(g1);
		t1.agregarATropa(g1);
		t1.agregarATropa(g1);
		t1.agregarATropa(g1);
		
		t2.agregarATropa(g2);
		t2.agregarATropa(g2);
		t2.agregarATropa(g2);
		
		t1.daniar(t2);
		System.out.println(t1);
		System.out.println(t2);
	}
}
