import java.util.ArrayList;
import java.util.Collections;

public class ColaDePrioridad<T> {
	private ArrayList<T> array = new ArrayList<T>();
	
	public ColaDePrioridad(){
		array.add(null);
	}
	
	public T getMax(){
		return array.get(1);
	}
	
	public T rmMax(){
		int tamanio = array.size();
		
		Collections.swap(array, 1, tamanio-1);
		T datoARemover = array.remove(tamanio-1);
		tamanio = array.size();
//		array.add(1, array.get(array.size()-1));
		
//		metodo q le paso indice raiz y tamanio
//		adentro verifico q indice hijos esten dentro del tamanio
//		si el primero cumple, lo comparo y me quedo el menor, y luego hago lo mismo con el segundo si es q tiene
		
		
//		subir el de mas abajo, a la derecha, a la raiz
//		raiz comparo con hijos y subo el menor
//		cortar cuando ninguno es menor o no hay mas hijos
		
		return datoARemover;
	}
	
	public boolean insertar(T a){
		return true;
	}
	
	public static void main(String[] args) {
//		ColaDePrioridad<Integer> cola = new ColaDePrioridad<Integer>();
		
	}
	
}
