

public class Main {

	public static <E> void main(String[] args) 
	{
		
	}

}
