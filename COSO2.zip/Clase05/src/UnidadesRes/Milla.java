package UnidadesRes;

public class Milla extends UnidadDeLongitud {
	private double valor;

	public Milla(double valor) {
		super(valor);
	}

	@Override
	public Kilometro toKilometro() {
		return new Kilometro(this.valor * 1.609);
	}

	@Override
	public Pie toPie() {
		return new Pie(this.valor * 5280);
	}

	@Override
	public Metro toMetro() {
		return new Metro(this.valor * 1609);
	}

	@Override
	public Milla toMilla() {
		return this;
	}
	
	@Override
	public UnidadDeLongitud sumar(UnidadDeLongitud other) {
		return new Milla(this.valor + other.toMilla().valor);
	}
	
	@Override
	public UnidadDeLongitud enMiUnidad(UnidadDeLongitud other) {
		return other.toMilla();
	}

	@Override
	public String toString() {
		return this.valor + "mi";
	}

}
