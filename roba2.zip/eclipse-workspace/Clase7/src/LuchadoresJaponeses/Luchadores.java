package LuchadoresJaponeses;

public class Luchadores {
	
	private Luchador[] luchadores;
	
	public Luchadores(int cant) {
		super();
		this.luchadores = new Luchador[cant];
	}
	
	public void calcularDominados () {
		for (int i = 0; i < this.luchadores.length; i++) {
			int j = i + 1;
			for (; j < this.luchadores.length; j++) {
				if (this.luchadores[i].domina(this.luchadores[j]) > 0) 
					this.luchadores[i].aumentar();
				else if (this.luchadores[i].domina(this.luchadores[j]) < 0)
					this.luchadores[j].aumentar();
				}
			}
	}
	
	public void agregar(int pos, Luchador luchador) {
		this.luchadores[pos] = luchador;
	}

	public int getLuchadores(int pos) {
		return luchadores[pos].getCantDominados();
	}

	public int getLenght() {
		return this.luchadores.length;
	}
}
