package carrito;

public class PackRegalo extends Pack{
	Articulo artRegalo;
	public PackRegalo() {
		// TODO Auto-generated constructor stub
	}

}
