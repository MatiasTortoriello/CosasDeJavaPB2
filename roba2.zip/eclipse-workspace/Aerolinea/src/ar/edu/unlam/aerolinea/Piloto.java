package ar.edu.unlam.aerolinea;

public class Piloto extends Personal {
	//String edad;
	public Piloto(String nombre) {
		super(nombre);
		//this.edad = edad;
	}
}
