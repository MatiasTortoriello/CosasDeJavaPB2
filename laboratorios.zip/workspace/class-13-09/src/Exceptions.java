
public class Exceptions {
	
}
