package unlam;

public class AreaDuplicadaException extends Exception {
	public AreaDuplicadaException(String msg) {
		super(msg);
	}
}
