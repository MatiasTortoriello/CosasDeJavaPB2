package colecciones;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.Set;
import java.util.TreeSet;

public class MainSet {

	public static void main(String[] args) {
		
		Set<Integer> conj = new HashSet<Integer>(); //ordena segun el Hashcode
		
		for(int i=0; i<5; i++)
			conj.add((int) (Math.random()*10));
		
		System.out.println(conj);
		
		Set<String> conj2 = new TreeSet<String>(); // ordena segun el compareTo
		
		conj2.add("Hola");
		conj2.add("Mundo");
		System.out.println(conj2);
		
		ArrayList<Integer> lista = new ArrayList<>();
		lista.add(1);
		lista.add(1);
		lista.add(1);
		System.out.println(lista);
		
		conj.addAll(lista);
		System.out.println(conj);
		
	}

}
