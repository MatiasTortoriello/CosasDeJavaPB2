package Dominio.figuras;

public class TrapecioInvertido extends Figura{

}
