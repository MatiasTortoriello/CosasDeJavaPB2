
public interface ArtefactoElectronico {
	public int getConsumo();
	public void setConsumo();
}
