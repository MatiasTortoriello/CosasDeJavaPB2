package unlam.practicame;

public interface Monitoreable {

	public void monitorear();
}
