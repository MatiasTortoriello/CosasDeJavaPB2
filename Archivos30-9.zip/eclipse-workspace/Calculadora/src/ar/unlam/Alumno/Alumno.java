package ar.unlam.Alumno;

public class Alumno {

	private String nombre;
	private String apellido;
	private int dni;
	private boolean estado;
	private int legajo;
	
	public Alumno() {
		
	}
	
	public static Alumno crear(String nombre, String apellido, Integer DNI, Boolean estado, Integer legajo) {
		
		Alumno Alu = new Alumno();
		Alu.setNombre(nombre);
		Alu.setApellido(apellido);
		Alu.setDni(DNI);
		Alu.setEstado(estado);
		Alu.setLegajo(legajo);
		
		return Alu;
	}

	
	public void setDni(int dni) {
		this.dni = dni;
	}

	public void setEstado(boolean estado) {
		this.estado = estado;
	}

	public void setLegajo(int legajo) {
		this.legajo = legajo;
	}

	public void setNombre(String nombre) {

		this.nombre = nombre;
	}

	
	public void setApellido(String apellido) {
		this.apellido = apellido;
	}

	
}
