import org.junit.Assert;
import org.junit.Test;

public class CerraduraDeCombinacionTests {

	@Test
	public void puedoCrearla() {
		new CerraduraDeCombinacion(1, 2, 3);
	}

	@Test
	public void abre() {
		CerraduraDeCombinacion c = new CerraduraDeCombinacion(1, 2, 3);
		c.izquierda();

		c.derecha();
		c.derecha();

		c.izquierda();
		c.izquierda();
		c.izquierda();

		Assert.assertTrue(c.abrir());
	}

	@Test
	public void noAbre() {
		CerraduraDeCombinacion c = new CerraduraDeCombinacion(1, 2, 3);
		c.izquierda();

		c.derecha();

		c.izquierda();

		Assert.assertFalse(c.abrir());
	}

}
