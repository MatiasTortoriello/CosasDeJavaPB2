import java.util.ArrayList;

public class Monticulo {
	ArrayList<Integer> array= new ArrayList<Integer>();
	
	Monticulo(){
		array.add(null);
	}
	
	void poner(int objeto) {
	
		array.add(objeto);
		
		int index = array.indexOf(objeto);
		
		if(index == 1) {
			return;
		}
		
		int fatherIndex = index / 2;
		
		while(fatherIndex > 0 && array.get(fatherIndex) < objeto) {
			int aux = array.get(fatherIndex);
			array.set(fatherIndex, objeto);
			array.set(index, aux);
			
			fatherIndex /= 2;
		}
		
		
	}
	
	int sacar() {
		
		int primerElem = array.get(1);
		int lastIndex = array.size()-1;
		array.set(1, array.get(lastIndex));
		array.remove(lastIndex);
		
		int fatherIndex = 1;
		int sonLeftIndex = fatherIndex*2;
		int sonRightIndex = sonLeftIndex+1;
		
		if(sonLeftIndex > lastIndex) {
			return primerElem;
		}
		
		int father = array.get(fatherIndex);
		int sonLeft = array.get(sonLeftIndex);
		int sonRight = array.get(sonRightIndex);
		
		int mayorIndex;
		
		while((sonLeft>father || sonRight>father) && sonLeftIndex < lastIndex)
		{
			if(sonLeft > sonRight)
				mayorIndex = sonLeftIndex;
			else
				mayorIndex = sonRightIndex;
			
			int aux = array.get(mayorIndex);
			array.set(mayorIndex, father);
			array.set(fatherIndex, aux);
			
			fatherIndex = mayorIndex;
			sonLeftIndex = fatherIndex*2;
			sonRightIndex = sonLeftIndex+1;
			
			if(sonLeftIndex < lastIndex){
				father = array.get(fatherIndex);
				sonLeft = array.get(sonLeftIndex);
				sonRight = array.get(sonRightIndex);
			}
			
		}
		
		return primerElem;
	}
}
