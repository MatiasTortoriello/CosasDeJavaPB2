package Guerra;

import java.util.ArrayList;
import java.util.List;

public class Tropa extends Unidad {
	
	private List<Unidad> tropa = new ArrayList<Unidad>();
	
	public boolean add(Unidad agregado) {
		return this.tropa.add(agregado);
	}

	public void atacar(Unidad otra) {
		this.tropa.get(0).atacar(otra);
	}
	
	public void recibirDanio(double danio) {
		if(this.estaVivo()) {
			int pos = (int)Math.random() * (this.tropa.size() - 1);
			this.tropa.get(pos).recibirDanio(danio);
			if(!this.tropa.get(pos).estaVivo())
				this.tropa.remove(pos);
		}
	}

	@Override
	public boolean estaVivo() {
		for (Unidad unidad : tropa) {
			if(unidad.estaVivo())
				return true;
		}
		return false;
	}
	

}
