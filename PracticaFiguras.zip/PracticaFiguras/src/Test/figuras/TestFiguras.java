package Test.figuras;

import static org.junit.Assert.*;

import java.util.ArrayList;

import org.junit.Test;

import Dominio.figuras.Caja;
import Dominio.figuras.Circulo;
import Dominio.figuras.Figura;
import Dominio.figuras.Rectangulo;
import Dominio.figuras.Triangulo;

public class TestFiguras {

	@Test
	public void queSePuedaCrearUnObjetoCirculo() {
		Circulo circulo = new Circulo("", 0.0, 0, 0.0);
		assertNotNull(circulo);
	}
	
	@Test
	public void queSePuedaCalcularElAreaDeUnCirculo() {
		Circulo circulo = new Circulo("A", 0.0, 2, 2.0);
		
		Double valorEsperado = 12.56;
		Double valorObtenido = circulo.calcularArea();
	
		assertEquals(valorEsperado, valorObtenido);
	}
	
	@Test
	public void queSePuedaObtenerUnaListaDeFigurasDesdeUnaCaja(){
		ArrayList<Figura> caja = new ArrayList<Figura>();
		Circulo circulo = new Circulo("A", 0.0, 2, 2.0);
		Circulo circulo2 = new Circulo("A", 0.0, 2, 2.0);
		Circulo circulo3 = new Circulo("A", 0.0, 2, 2.0);
		
		caja.add(circulo);
		caja.add(circulo2);
		caja.add(circulo3);
		
		Integer valorEsperado = 3;
		Integer valorObtenido = caja.size();
		
		assertEquals(valorEsperado, valorObtenido);
	}
	
	@Test 
	public void queSePuedaLeerElArrayListDeLaCaja(){
		Caja caja = new Caja();
		Circulo circulo = new Circulo("A", 11.0, 2, 2.0);

		caja.agregarFigurasACaja(circulo);
		
		Integer valorEsperado = 1;
		Integer valorObtenido =	caja.getListaFigura().size();
		
		assertEquals(valorEsperado, valorObtenido);
	}
	
	@Test
	public void queSePuedaObtenerFiguasConAreaMayorADiezDesdeUnaListaDeFiguras(){
		Caja caja = new Caja();
		Circulo circulo = new Circulo("A", 11.0, 2, 2.0);
		Circulo circulo2 = new Circulo("A", 425.0, 2, 2.0);
		Circulo circulo3 = new Circulo("A", 0.0, 2, 2.0);
		
		caja.agregarFigurasACaja(circulo);
		caja.agregarFigurasACaja(circulo2);
		caja.agregarFigurasACaja(circulo3);
		
		
		
		Integer valorEsperado = 2;
		Integer valorObtenido = caja.calcularMayoresDeDiez();
		
		assertEquals(valorEsperado, valorObtenido);
	}
	
	@Test
	public void queSePuedaObtenerFigurasCirculosDeUnaListaDeFiguras(){
		Caja caja = new Caja();
		Circulo circulo = new Circulo("A", 11.0, 2, 2.0);
		Circulo circulo2 = new Circulo("A", 425.0, 2, 2.0);
		Rectangulo triangulo = new Rectangulo("A", 0.0, 2, 2.0,2.0);
		
		
		caja.agregarFigurasACaja(circulo);
		caja.agregarFigurasACaja(circulo2);
		caja.agregarFigurasACaja(triangulo);
		
		
		
		Integer valorEsperado = 2;
		Integer valorObtenido = caja.determinarTipo();
		
		assertEquals(valorEsperado, valorObtenido);
	}
}
