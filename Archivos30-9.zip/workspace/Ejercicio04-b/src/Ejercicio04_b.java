
public class Ejercicio04_b {
	public static void main(String[] args) {
		/*Color color = Color.ROJO;
		MedioDePago mp = MedioDePago.CREDITO;
		
		System.out.println(color);
		System.out.println(mp);*/
		Kilometro km = new Kilometro(5);
		Metro metro = new Metro(1000);
		
		System.out.println(km.aMetro());
		System.out.println(metro.aKm());
		
	}
}
