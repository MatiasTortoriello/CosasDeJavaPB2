
public abstract class UnidadAtaque {
	
	public abstract void atacar(UnidadAtaque atacado);
	
	public abstract void recibirAtaque(int danio);
	
}
