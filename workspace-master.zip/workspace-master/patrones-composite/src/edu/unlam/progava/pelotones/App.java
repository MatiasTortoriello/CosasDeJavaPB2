package edu.unlam.progava.pelotones;

public class App {

	public static void main(String[] args) {
		

//		
//		System.out.println(pp);
//		
//		Unidad victima = new Unidad(new Punto(10, 10));
//		
//		pp.atacar(victima);
		
		
	}
	
}
