package unlam.practicame;

public class Transferencia extends Transaccion  implements  Rechazable, Alertable{

	public Transferencia (){
		TipoTransaccion tipo = TipoTransaccion.MONETARIA;
	}
	
	@Override
	public void marcarComoCasoSospechoso() {
		
		
	}

	@Override
	public void confirmarSiFueFraude(Boolean fueFraude) {
		
		
	}

	@Override
	public Boolean monitorear() throws FraudeException {
		
		return null;
	}

}
