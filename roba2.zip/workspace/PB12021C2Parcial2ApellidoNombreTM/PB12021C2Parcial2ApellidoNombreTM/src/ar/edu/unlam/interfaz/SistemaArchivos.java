package ar.edu.unlam.interfaz;

import java.util.Scanner;

public class SistemaArchivos {
	
	/**
	 * DIIT - Tecnicatura Universitaria en Web / Mobile
	 * PB1 - 2C - Segundo Parcial - TM
	 * 
	 * Fecha: 30/11/2021
	 * 
	 * Se pide:
	 *	1 - Generar los constructores de las clases UnidadAlmacenamiento y Archivo.
	 *	2 - Generar los enums necesarios para satisfacer los tipos de unidad (hdd, usb) y tipos de archivo (jpg, png, txt, exe).
	 *	3 - Desarrollar el método agregarArchivo de la clase UnidadAlmacenamiento considerando que el array de archivos no esté lleno y la capacidad máxima no sea superada.
	 *	4 - Desarrollar el método obtenerAchivosTipoJpgOrdenadosPorNombreDesc de la clase UnidadAlmacenamiento.
	 *	5 - Desarrollar el método informarEspacioAlmacenado de la clase UnidadAlmacenamiento.
	 *	6 - Agregar el código necesario en el main para satisfacer las operaciones solicitadas.
     *
	 * Importante:
	 * 	- El alumno podrá agregar todos atributos y/o generar métodos adicionales que considere necesarios para alcanzar dicha solución.
	 * 	- No es posible modificar los prototipos de métodos preexistentes.
	 *	- El criterio de condición de promoción es tener el 80% o más del exámen aprobado y el criterio para aprobar la cursada es del 60% del exámen aprobado.
	 *  - En la clase de pruebas, realice lo siguiente:
	 *  -   + Agregue el código necesario para resolver los casos del switch principal.
	 *	-	+ Sugiera mejoras que puedan aplicarse al código actual.
	 * */
	
	
	static final char SALIR = 'Z';
	
	public static void main(String[] args) {
		Scanner teclado = new Scanner(System.in);
		
		mostrarMenuPrincipal();
		char opcion = 0;
		do {

			opcion = teclado.next().charAt(0);
			
			switch (opcion) {
			case 'A': // Agregar un archivo a la unidad de almacenamiento tipo HDD e informar si el agregado fue exitoso.
				break;
			case 'B': // Informar el espacio almacenado en el HDD
				break;
			case 'C': // Mostrar archivos JPG ordenados por nombre del HDD
				break;
			case 'D': // Copiar archivos desde el HDD a USB
				break;
			default:
				System.out.println("Opcion invalida. Ingrese nuevamente.");
			}
		} while (opcion != SALIR);

		teclado.close();
	}

	/**
	 * Muestra el menú principal del sistema con las opciones disponibles
	 */
	private static void mostrarMenuPrincipal() {
		System.out.println("\n¡Bienvenido al gestor de archivos!");
		System.out.println("\nIngrese:");
		System.out.println("A - Para agregar un archivo a la unidad de almacenamiento HDD.");
		System.out.println("B - Para informar el espacio almacenado en el HDD.");
		System.out.println("C - Para mostrar archivos JPG ordenados por nombre del HDD.");
		System.out.println("D - Para copiar los archivos desde el HDD a USB.");
		System.out.println("Z - Para volver.");
	}
}
