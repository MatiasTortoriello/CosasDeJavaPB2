package Guerra;

public abstract class Unidad {
	
	public abstract void recibirDanio (double danio);
	public abstract void atacar(Unidad otro);
	public abstract boolean estaVivo();

}
