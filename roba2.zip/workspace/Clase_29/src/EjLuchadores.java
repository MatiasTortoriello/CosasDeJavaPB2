
public class EjLuchadores {
	public static void main(String[] args) {
		EjLuchadores luchadores = new EjLuchadores();
		luchadores.resolver();
		
	}
	
	public void resolver(){
		Archivos archivo = new Archivos("sumo");
		
		int[][] datos = archivo.leerArchivo();
		int superados = 0;
		
		for(int i=0; i<datos.length; i++){
			superados = 0;
			int 
			for(int j=i; j<datos.length; j++){
				if(datos[i][0] > datos[i][1])
				{
					superados++;
				}
				else
				{
					if(datos[])
				}
			}
		}
		
		archivo.guardarArchivo(datos);
	}
	
}
