package code;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Locale;
import java.util.Scanner;

public class Archivo {
	private String nombre;

	public Archivo(String nombre) {
		this.nombre = nombre;
	}

	public DatosEntrada leerArchivo() {
		Scanner scanner = null;
		DatosEntrada datos = null;

		try {
			File file = new File("src/casos de prueba/in/" + this.nombre + ".in");
			scanner = new Scanner(file);
			// Especifica la configuraci�n regional que se va a utilizar
			scanner.useLocale(Locale.ENGLISH);
			// Para la configuraci�n regional de Argentina, utilizar:
			// arch.useLocale(new Locale("es_AR"));

			int n = scanner.nextInt();
			int m = scanner.nextInt();
			int D = scanner.nextInt();

			ArrayList<Personaje> personajes = new ArrayList<Personaje>();
			ArrayList<Objeto> objetos = new ArrayList<Objeto>();

			for (int i = 0; i < n; i++) {
				int a = scanner.nextInt();
				int f = scanner.nextInt();

				personajes.add(new Personaje(a, f));
			}

			for (int i = 0; i < m; i++) {
				int p = scanner.nextInt();

				objetos.add(new Objeto(p));
			}

			datos = new DatosEntrada(personajes, objetos, D);
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			// Cerrar el archivo, eso es mucho muy importante
			scanner.close();
		}
		return datos;
	}

	public void guardarArchivo(int datos) {
		FileWriter file = null;
		PrintWriter printerWriter = null;

		try {
			file = new FileWriter("src/casos de prueba/out/" + this.nombre + ".out");
			printerWriter = new PrintWriter(file);

			printerWriter.println(datos);

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			if (file != null) {
				try {
					file.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		}
	}
}