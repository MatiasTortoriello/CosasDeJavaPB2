package edu.unlam.progava.cafe;

public class MaquinaPremium extends MaquinaDeCafe {

}
