package Packs;

public class PackDescuento extends Pack {

}
