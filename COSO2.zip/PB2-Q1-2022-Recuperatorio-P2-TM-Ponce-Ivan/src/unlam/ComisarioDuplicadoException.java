package unlam;

public class ComisarioDuplicadoException extends Exception {
	public ComisarioDuplicadoException(String msg) {
		super(msg);
	}
}
