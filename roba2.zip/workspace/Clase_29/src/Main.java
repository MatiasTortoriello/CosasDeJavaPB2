import java.util.Arrays;

public class Main {
	public static void main(String[] args){
		
		Punto puntos[] = new Punto [10];
		
		puntos[0] = new Punto(1,1);
		puntos[1] = new Punto(10,0);
		puntos[2] = new Punto(0,0);
		puntos[3] = new Punto(-5,-2);
		puntos[4] = new Punto(-7,8);
		puntos[5] = new Punto(3,-10);
		puntos[6] = new Punto(1,0);
		puntos[7] = new Punto(-1,0);
		puntos[8] = new Punto(0,1);
		puntos[9] = new Punto(0,-1);
		
		
		Arrays.sort(puntos);
		
		for(Punto punto : puntos ){
			System.out.println(punto);
		}
	}
	
//	Punto p1 = new Punto();
	
//	System.out.println(p1.getX());
//	System.out.println(p1.getY());
//	
//	Punto p2 = p1.clone();
//	
//	p2.setY(p1.getY() + 1);
//	
//	System.out.println(p1.equals(p2));
//	
}
