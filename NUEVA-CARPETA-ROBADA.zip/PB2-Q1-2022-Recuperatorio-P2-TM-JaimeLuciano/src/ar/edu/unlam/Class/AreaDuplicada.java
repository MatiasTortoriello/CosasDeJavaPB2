package ar.edu.unlam.Class;

public class AreaDuplicada extends Exception {

}
