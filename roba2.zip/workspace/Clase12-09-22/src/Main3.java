import java.util.HashMap;
import java.util.Map;

public class Main3 {

	public static void main(String[] args) {
		Map<Integer, String> map1 = new HashMap<Integer, String>();
		
		map1.put(2, "juan");
		map1.put(40, "juan");
		map1.put(40, "perro");
		map1.put(30, "perro");
		System.out.println(map1.containsKey(2));
		map1.containsValue("juan");
		
		map1.isEmpty();
		map1.putIfAbsent(20, "juan");
		System.out.println("tamanio: " + map1.size());
		System.out.println(map1);
		
	}
}
