package ar.edu.unlam.pb2.eva03;

public class Vivienda{
	private String direccion;
	private String localidad;
	private String ciudad;
	private String provincia;
	public Vivienda(String string, String string2, String string3, String string4) {
		// TODO Auto-generated constructor stub
		this.direccion=string;
		this.localidad=string2;
		this.ciudad=string3;
		this.provincia=string4;
	}

}
