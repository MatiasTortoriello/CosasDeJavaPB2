package ar.edu.unlam.pb2;

public class CuentaCorriente extends Cuenta {
	
	private Double limiteDescubierto;
	
	public CuentaCorriente(Integer nroCuenta, Double saldo, String nombre, String apellido, Integer dni) {
		super(nroCuenta, saldo, nombre, apellido, dni);
		this.limiteDescubierto = limiteDescubierto;
	}

	public Double getLimiteDescubierto() {
		return limiteDescubierto;
	}

	public void setLimiteDescubierto(Double limiteDescubierto) {
		this.limiteDescubierto = limiteDescubierto;
	}

	@Override 
	public Boolean extraer (Double monto){
		if (monto <= this.getSaldo() + this.limiteDescubierto) {
			setSaldo(getSaldo()-monto);
			// super.extraer(monto); (llamar al padre)
			return true;
		}
		return false;
	}
	
	
}
