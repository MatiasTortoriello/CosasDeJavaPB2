
public class Guerrero extends Unidad{
	private int vida = 100;
	private int ataque = 10;
	
	public Guerrero() {
	}
	
	@Override
	public void atacar(Unidad otro) {
		if(vida>0) {
			otro.recibir(ataque);
		}
	}
	
	@Override
	public void recibir(int dano) {
		this.vida-=dano;
	}
	
	@Override
	public boolean isAlive() {
		return this.vida>0;
	}

	
}
