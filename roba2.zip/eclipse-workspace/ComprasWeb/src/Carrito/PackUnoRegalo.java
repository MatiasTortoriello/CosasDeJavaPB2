package Carrito;

public class PackUnoRegalo extends Pack {

	private int cantidad;
	private double[] precioTotal;
	
	public PackUnoRegalo (int cantidad) {
		this.cantidad = cantidad;
		this.precioTotal = ;
	}

	public void agregar(Articulo art) {
		this.precioTotal += art.precio * (this.cantidad - 1);
	}

}
