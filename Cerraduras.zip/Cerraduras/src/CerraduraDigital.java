
public class CerraduraDigital {
	private int x, y, z;
	private int a, b, c;
	private boolean seIntento = false;

	public CerraduraDigital(int x, int y, int z) {
		// Check 9 >= x, y, z >= 0
		this.x = x;
		this.y = y;
		this.z = z;
	}

	public void ingresarClave(int a, int b, int c) {
		this.a = a;
		this.b = b;
		this.c = c;
		seIntento = true;
	}

	public boolean presionarOk() {
		if (seIntento && x == a && y == b && z == c) {
			return true;
		}
		return false;
	}
}
