package colecciones;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

public class MainLista {

	public static void main(String[] args) {
		
		List<Integer> lista = new ArrayList<Integer>();
//		List<Integer> lista = new LinkedList<Integer>();
		
		lista.add(1);
		lista.add(2);
		lista.add(1, new Integer(3));
		
		System.out.println(lista);
		
		lista.remove(0);
		System.out.println(lista);
		
		lista.remove(new Integer(2));
		System.out.println(lista);
		
		System.out.println(lista.get(0));
		
		for(int i=0; i<5; i++)
			lista.add(i);
		
		System.out.println(lista);
		System.out.println(lista.indexOf(3));
		
		lista.clear();
		System.out.println(lista);
		
		System.out.println(lista.size());
		
		System.out.println(lista.isEmpty());
		
		
		
	}

}
