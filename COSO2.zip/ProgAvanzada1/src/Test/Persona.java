package Test;

import Exception.PersonaException;
import Exception.PersonaNombreException;

public class Persona {
	
	private Integer dni;
	
	private String nombre;
	
	private String apellido;

	private MiCalendar fecNac;

	public Persona(Integer dni, String nombre, String apellido, MiCalendar fecNac) {
		super();
		this.dni = dni;
		this.nombre = nombre;
		this.apellido = apellido;
		this.fecNac = fecNac;
	}
	
	public Persona(){
		
	}
	
	public Persona(Integer dni){
		this.dni = dni;
	}

	public Integer getDni() {
		return dni;
	}

	public void setDni(Integer dni) throws PersonaException {
		if(dni == null || dni <= 0){
			throw new PersonaException("Ingrese un valor mayor a 0");
		}
		this.dni = dni;
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) throws PersonaNombreException  {
		if(nombre == null || nombre.trim().isEmpty()){
			throw new PersonaNombreException("El nombre no puede estar vacio");
		}
		//Validar caracteres validos
		this.nombre = nombre;
	}

	public String getApellido() {
		return apellido;
	}

	public void setApellido(String apellido) {
		this.apellido = apellido;
	}
	
	public MiCalendar getFecNac() {
		return fecNac;
	}

	public void setFecNac(MiCalendar fecNac) {
		this.fecNac = fecNac;
	}
	
}