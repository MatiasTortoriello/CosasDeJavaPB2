package ar.edu.unlam.aerolinea;

import java.util.ArrayList;
import java.util.Iterator;

public class Vuelo {

	private Avion avion;
	private ArrayList<Personal> personal = new ArrayList<>();

	public Boolean agregarAvion(Avion avion) {
		if(this.avion == null) {
			this.avion = avion;
			return true;
		} else {
			return false;
		}
	}

	public Boolean agregarPersonal(Personal p) {
		if(puedoAgregarPersonal(p)) {
			this.personal.add(p);
			return true;
		} else {
			return false;
		}
		
	}

	private boolean puedoAgregarPersonal(Personal p) {
		if(p instanceof Piloto) {
			for(int i=0; i< personal.size(); i++) {
				
			}
		}
		return false;
	}

}
