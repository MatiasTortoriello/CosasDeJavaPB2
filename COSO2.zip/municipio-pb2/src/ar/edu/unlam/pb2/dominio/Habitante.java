package ar.edu.unlam.pb2.dominio;

public class Habitante {

	private Integer dni;
	private String nombre;
	private Vivienda vivienda;
	private String apellido;

	public Habitante(Integer dni, String nombre) {
	
	}

	public Habitante(Integer dni, String nombre, Vivienda vivienda) {
		this.dni = dni;
		this.nombre = nombre;
		this.vivienda = vivienda;
	}

	public Habitante(Integer dni, String nombre, Vivienda vivienda, String apellido) {
		this.dni = dni;
		this.nombre = nombre;
		this.apellido = apellido;
		this.vivienda = vivienda;
	}

	public Habitante(Integer dni, String nombre, String apellido) {
		this.dni = dni;
		this.nombre = nombre;
		this.apellido = apellido;
	}

	public Integer getDni() {
		return dni;
	}

	public void setDni(Integer dni) {
		this.dni = dni;
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public Vivienda getVivienda() {
		return vivienda;
	}

	public void setVivienda(Vivienda vivienda) {
		this.vivienda = vivienda;
	}

	public String getApellido() {
		return apellido;
	}

	public void setApellido(String apellido) {
		this.apellido = apellido;
	}

	
}
