package patron_Decorator;

public class Personaje extends Unidad {
	private int salud;
	private int danio;

	@Override
	public int getAtaque() {
		return this.danio
				
				;
	}

	@Override
	public int getDefensa() {
		// TODO Auto-generated method stub
		return 0;
	}
}
