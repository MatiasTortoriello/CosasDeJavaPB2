package unlam;

public enum TipoDeComisario {
	Juez , Observador

}
