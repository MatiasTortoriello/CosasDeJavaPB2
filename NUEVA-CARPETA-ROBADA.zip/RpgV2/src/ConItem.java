
public abstract class ConItem extends ElementoDeJuego {
	private ElementoDeJuego edj;

	public ConItem(ElementoDeJuego edj) {
		this.edj = edj;
	}
	
	@Override
	public Integer getDanio() {
		return edj.getDanio();
	}

}
