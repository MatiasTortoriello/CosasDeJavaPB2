
public class Main {
	public static void main(String[] args) {
		Accionable pj = new Personaje();
		System.out.println(pj.getDanio());
		
		pj = new ConEspada(pj);
		System.out.println(pj.getDanio());
		
		pj = new ConAmuleto(pj);
		System.out.println(pj.getDanio());
		
	}
}
