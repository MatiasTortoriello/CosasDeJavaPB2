package dominio;

import java.util.ArrayList;

public class Secretaria {

	private ArrayList<Habitante> habitantes;
	private ArrayList<Vivienda> viviendas;
	private ArrayList<RegistroPropiedad> registroPropiedades;

	public Secretaria() {
		this.habitantes = new ArrayList<>();
		this.viviendas = new ArrayList<>();
		this.registroPropiedades = new ArrayList<>();
	}

	public void agregarHabitante(Habitante habitante) {
		this.habitantes.add(habitante);
	}

	public Integer obtenerCantidadDeHabitantes() {
		return this.habitantes.size();
	}

	public void agregarVivienda(Vivienda vivienda) {
		this.viviendas.add(vivienda);
	}

	public Integer obtenerCantidadDeViviendas() {
		return this.viviendas.size();
	}

	public Boolean asignarPropiedad(Vivienda vivienda, Habitante habitante, Double porcentaje) {
		if (!excedeElPorcentaje(porcentaje, vivienda)) {
			RegistroPropiedad registro = new RegistroPropiedad(this.generarId(), vivienda, habitante, porcentaje);
			this.registroPropiedades.add(registro);
			return true;
		}
		return false;
	}

	public Boolean excedeElPorcentaje(Double porcentaje, Vivienda vivienda) {
		return porcentaje + obtenerPorcentajeDeUnaVivienda(vivienda) > 100;
	}

	public Double obtenerPorcentajeDeUnaVivienda(Vivienda vivienda) {
		Double porcentajeTotal = 0.0;
		for (int i = 0; i < registroPropiedades.size(); i++) {
			if (registroPropiedades.get(i).getVivienda().equals(vivienda)) {
				porcentajeTotal += registroPropiedades.get(i).getPorcentaje();
			}
		}
		return porcentajeTotal;
	}

	private Integer generarId() {
		return 1; // tarea
	}

	public Integer obtenerCantidadDeRegistrosDePropiedad() {
		return registroPropiedades.size();
	}

	public ArrayList<Vivienda> obtenerViviendasCuyoPorcentajeEsMenorAlCienPorCiento() {
		ArrayList<Vivienda> viviendasPorcentajeMenor = new ArrayList<>();
		for (RegistroPropiedad registroPropiedad : registroPropiedades) {
			if (this.obtenerPorcentajeDeUnaVivienda(registroPropiedad.getVivienda()) < 100.0) {
				viviendasPorcentajeMenor.add(registroPropiedad.getVivienda());
			}
		}
		return viviendasPorcentajeMenor;
	}

}
