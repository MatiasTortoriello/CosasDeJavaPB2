public class Archivos {
	private String nombre;
	
	//constructor
	public Archivos(String nombre) {
		this.nombre = nombre;
	}
	
	
	///metodos
	public double[] leerArchivo() {
		Scanner scanner = null;
		double[] datos = null;

		
		try {
			File file = new File(this.nombre + ".in");
			scanner = new Scanner(file);
			
			scanner.useLocale(Locale.ENGLISH);
			
			int cant = scanner.nextInt();
			datos = new double[cant];
			for (int i = 0; i < cant; i++) {
				double n = scanner.nextDouble();
				datos[i] = n;
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			scanner.close();
		}
		
		return datos;
	}
	
	
	public void guardarArchivo(int min, int max, int prom) {
		FileWriter file = null;
		PrintWriter printerWriter = null;
		Formatter formato = new Formatter();
		
		try {
			file = new FileWriter(this.nombre + ".out");
			printerWriter = new PrintWriter(file);
			
			printerWriter.println("+----------+-------+");
			printerWriter.println("| M�ximo   |" + formato.format("%6d",max ) + " |");
			formato.close();
			printerWriter.println("+----------+-------+");
			printerWriter.printf("| M�nimo   |%6d |\n", min);
			printerWriter.println("+----------+-------+");
			printerWriter.printf("| Promedio |%6d |\n", prom);
			printerWriter.println("+----------+-------+");
			
			
		}catch (Exception e) {
			e.printStackTrace();
		} finally {
			if (file != null) {
				try {
					file.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		}
		
	}

	public void escribirArchNumerosRandom() {
		FileWriter file = null;
		PrintWriter printerWriter = null;
		
		try {
			file = new FileWriter(this.nombre + ".in");
			printerWriter = new PrintWriter(file);
			
			
			int cantNum = (int)(Math.random() * 100 + 100);//entre 100 y 200
			int numRandom;
			printerWriter.println(cantNum);	//cant de numeros
			
			for(int i=0; i<cantNum; i++) {
				numRandom = (int)(Math.random() * 12000);
				printerWriter.println(numRandom);
			}
			
		}catch (Exception e) {
			e.printStackTrace();
		} finally {
			if (file != null) {
				try {
					file.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		}
		
	}
	
	
}