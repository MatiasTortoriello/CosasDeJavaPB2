package ar.edu.unlam.Class;

public class ComisarioInexistente extends Exception {

}
