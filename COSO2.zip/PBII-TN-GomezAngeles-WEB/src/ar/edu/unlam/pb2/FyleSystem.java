package ar.edu.unlam.pb2;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;

public class FyleSystem {
	HashSet <UnidadAlmacenamiento> unidades;
	List <DiscoRigidos> discos;
	List <DVD> dvd;
	
	public FyleSystem(){
		this.unidades = new HashSet<UnidadAlmacenamiento>();
		
		this.discos = new ArrayList<DiscoRigidos>();
		this.dvd = new ArrayList<DVD>();
	}
	
	public Boolean agregarUnidad(DVD dvd, DiscoRigidos disco){
		return Boolean.TRUE;
	}
	
	public void agregarDiscoRigido(DiscoRigidos disco){
		this.discos.add(disco);
	}
	
	public void agregarDVD(DVD dvd){
		this.dvd.add(dvd);
	}
	
	public Boolean formatearArchivos(DiscoRigidos disco){
		Boolean seFormateo = false;
		//archivos.removeAll(archivos);
		return seFormateo;
	}
	
	public List <Character> obtenerListaDeUnidadesDeDiscoRigido(){
		
		return null;
	}
}
