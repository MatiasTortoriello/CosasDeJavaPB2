package ejercicios;

public abstract class UnidadDeLongitud {
	
	public abstract a

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}
  
}
