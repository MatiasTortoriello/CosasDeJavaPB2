import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

public class Main {

	public static void main(String[] args) {

		//agregar
		
//		int num1 = 1;
//		int num2 = 2;
//		int num3 = 3;
//		List <Integer> lista = new LinkedList<Integer>();
//		
//		lista.add(num1);
//		lista.add(0, num2);
//		
////		for (int elem : lista)
////		{
////			System.out.println(elem);
////		}
//		System.out.println(lista);
//		
//		lista.add(num1);
//		lista.remove(2);
//		lista.remove(num1);
//		
//		lista.indexOf(num3);	//buscar
//		
//		lista.contains(num1);
//		
//		
//		lista.size();	//tama�o
//		
//		lista.clear(); 		//vaciar
//
//		lista.isEmpty();	//esta vacio?
//		
//		//Las cosas que pones en la lista tienen que tener bine definido el Equals
		
		
		int num1 = 1;
		int num2 = 2;
		int num3 = 3;
		
		ArrayList<Integer> lista = new ArrayList<Integer>();
		
		lista.add(num1);
		lista.add(0, num2);
		
//		for (int elem : lista)
//		{
//			System.out.println(elem);
//		}
		System.out.println(lista);
		lista.toString();
		
		lista.add(num1);
		lista.remove(2);
		lista.remove(num1);
		
		lista.indexOf(num3);	//buscar
		
		lista.contains(num1);
		
		
		lista.size();	//tama�o
		
		lista.clear(); 		//vaciar

		lista.isEmpty();	//esta vacio?
		
		
	}
}
