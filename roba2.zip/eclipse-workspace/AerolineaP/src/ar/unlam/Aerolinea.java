package ar.unlam;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class Aerolinea {
		private String nombre;
		private Set<Vuelo> vuelos;

	public Aerolinea(String nombre) {

this.nombre=nombre;
this.vuelos = new HashSet<>();
	}

	public boolean agregar(Vuelo vuelo) {
		//if(this.buscarVuelo(vuelo.getIdVuelo())==null)
		return this.vuelos.add(vuelo);
		
		//return false;
	}

	public Vuelo buscarVuelo(Integer idVuelo) {
		for (Vuelo vuelo : vuelos) {
			if(vuelo.getIdVuelo().equals(idVuelo))
				return vuelo;
		}
		return null;
	}
	public Vuelo buscarVuelo(Vuelo vuelo) {
		for (Vuelo vuelo1 : vuelos) {
			if(vuelo1.equals(vuelo))
				return vuelo;
		}
		return null;
	}
}
