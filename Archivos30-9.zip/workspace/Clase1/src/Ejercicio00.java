//SMB AAL

public class Ejercicio00 {
	public boolean comprobar(int[][] matriz) {
		int sumaDeLasAnteriores = matriz[0][0];
		for (int i = 1; i < matriz.length; i++) {
			if (matriz[i][i] == sumaDeLasAnteriores) {
				sumaDeLasAnteriores += matriz[i][i];
			} else {
				return false;
			}
		}
		return true;
	}

	public static void main(String[] args) {
		int[][] ejemplo = { { 1, 2, 3 }, { 4, 1, 6 }, { 7, 8, 2 } };

		Ejercicio00 miEjercicio = new Ejercicio00();
		System.out.println(miEjercicio.comprobar(ejemplo));
	}
}
