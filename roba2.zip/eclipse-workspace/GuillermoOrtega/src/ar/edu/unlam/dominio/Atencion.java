package ar.edu.unlam.dominio;

public class Atencion {

	private int id;
	private String nombreCliente;
	private String nombreMascota;
	private Especie especieMascota; 
	private double monto;
	
	public Atencion() {
		// TODO: Ajustar para satisfacer las funcionalidades 
	}
}

