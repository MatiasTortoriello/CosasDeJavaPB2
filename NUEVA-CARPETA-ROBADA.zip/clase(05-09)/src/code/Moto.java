package code;

import java.util.ArrayList;

public class Moto extends Transporte{

	private final int paquetesMax = 3;
	private final double pesoMax = 50;
	private final double dimensionMax = 1;
	
	public Moto() {
		paquetes = new ArrayList<Paquete>();
	}
	
	@Override
	public boolean cargarPaquete(Paquete p) {
		
		if(paquetes.size() < paquetesMax && p.getPeso()+chequearPeso() <= pesoMax 
				&& p.getTam()+chequearDimension() <= dimensionMax ){
			if(paquetes.size() == 0 || p.getDestino().equals(paquetes.get(0).getDestino())) {
				paquetes.add(p);
				return true;
			} 

		}
		return false;
	}

	private double chequearPeso(){
		double acu = 0;
		for (Paquete paquete : paquetes) {
			acu += paquete.getPeso();
		}
		return acu;
	}
	
	private double chequearDimension(){
		double acu = 0;
		for (Paquete paquete : paquetes) {
			acu += paquete.getTam();
		}
		return acu;
	}
	
}
