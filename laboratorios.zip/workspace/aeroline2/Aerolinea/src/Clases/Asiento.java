package Clases;

public class Asiento {

	private Integer identificador;	
	Boolean vacio;
	
	public Asiento(Integer identificador) {
		this.identificador = identificador;
		this.vacio = true;
	}

	public Integer getIdentificador() {
		return identificador;
	}
	
	public void setIdentificador(Integer identificador) {
		this.identificador = identificador;
	}
	
	public void setVacio(Boolean vacio) {
		this.vacio = vacio;
	}
	
	public Boolean getVacio() {
		return vacio;
	}
}
