
public abstract class  Inicio {
	public abstract int getDa�o();
}
