

public class Main {

	public static void main(String[] args) {
		
			Japoneses japos = new Japoneses();
			japos.resolucion("entrada.in", "salida.out");
	}

}
