package ar.unlam.figuras;

public abstract class Figura {

	// protected String nombre;
	private String color;

	public Figura(String color) {
		this.color = color;
	}

	public String obtenerColor() {
		return this.color;
	}

	public abstract Double calcularArea();
	
	public abstract String getTipo();

	@Override
	public String toString() {
		return " Soy una Figura de color=" + this.obtenerColor();
	}

}
