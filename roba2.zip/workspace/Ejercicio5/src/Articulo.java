
public class Articulo {
	
	public float precio;
	public String nombre;
	
	
	
	Articulo(String nombre,float precio){
		this.nombre=nombre;
		this.precio=precio;
	}
	

}
