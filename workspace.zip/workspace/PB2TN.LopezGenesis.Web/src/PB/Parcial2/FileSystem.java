package PB.Parcial2;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;

public class FileSystem {

	Set<Character> unidades;
	private Integer capacidadMaximaDeDiscoRigido;
	private Integer agregarDiscoRigido;
	private Integer agregarDvd;

	public List<Character> obtenerListaDeUnidadeDeDiscoRigido = new ArrayList<Character>();

	public Integer agregarDiscoRigido() throws Exception{
		
	
	if(agregarDiscoRigido == capacidadMaximaDeDiscoRigido){
		return null;
		
		throw new capacidadExcedidaExeption();
	}
	
	return null;
	}

	public Character agregarDvd() throws Exception{
		
		if(agregarDvd == capacidadMaximaDeDiscoRigido){
			return null;
	
			throw new capacidadExcedidaException();
				return null;
		}
	}
	
		
	

	public Set<Letra> getUnidades() {
		return unidades;
	}

	public void setUnidades(Set<Letra> unidades) {
		this.unidades = unidades;
	}

	public Integer getCapacidadmaximaDeDiscoRigido() {
		return capacidadmaximaDeDiscoRigido;
	}

	public void setCapacidadmaximaDeDiscoRigido(Integer capacidadmaximaDeDiscoRigido) {
		this.capacidadmaximaDeDiscoRigido = capacidadmaximaDeDiscoRigido;
	}

	public List<Character> getObtenerListaDeUnidadeDeDiscoRigido() {
		return obtenerListaDeUnidadeDeDiscoRigido;
	}

	public void setObtenerListaDeUnidadeDeDiscoRigido(List<Character> obtenerListaDeUnidadeDeDiscoRigido) {
		this.obtenerListaDeUnidadeDeDiscoRigido = obtenerListaDeUnidadeDeDiscoRigido;
	}

	public Integer getAgregarDiscoRigido() {
		return agregarDiscoRigido;
	}

	public void setAgregarDiscoRigido(Character agregarDiscoRigido) {
		this.agregarDiscoRigido = agregarDiscoRigido;
	}

	public Integer getAgregarDvd() {
		return agregarDvd;
	}

	public void setAgregarDvd(Character agregarDvd) {
		this.agregarDvd = agregarDvd;
	}

	public Integer getCapacidadMaximaDeDiscoRigido() {
		return capacidadMaximaDeDiscoRigido;
	}

	public void setCapacidadMaximaDeDiscoRigido(Integer capacidadMaximaDeDiscoRigido) {
		this.capacidadMaximaDeDiscoRigido = capacidadMaximaDeDiscoRigido;
	}

	public void setAgregarDiscoRigido(Integer agregarDiscoRigido) {
		this.agregarDiscoRigido = agregarDiscoRigido;
	}

	public void setAgregarDvd(Integer agregarDvd) {
		this.agregarDvd = agregarDvd;
	}

}
