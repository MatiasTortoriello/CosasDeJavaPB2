
public class ConAmuleto extends ConItem{
	
	public ConAmuleto(Accionable item){
		super(item);
	}
	
	public int getDanio(){
		return super.getDanio() * 2;
	}
}
