package edu.unlam.progava.complejidad.estrategias;

public interface StreetNumbersStrategy {

	public int alturaDeLaCasa(int ultimoNumero);

}
