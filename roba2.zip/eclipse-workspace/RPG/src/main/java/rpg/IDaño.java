package rpg;

public interface IDa�o {

	public abstract int obtenerDanio();
}
