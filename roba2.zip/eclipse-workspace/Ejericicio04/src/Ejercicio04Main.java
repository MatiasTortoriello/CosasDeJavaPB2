
public class Ejercicio04Main {

	public static void main(String[] args) {
		Medidas medida = Medidas.KILOMETROS;
		System.out.println(medida);
	}
	
	public static float convertirUnidad(float unidad, String uniOrigen, String uniDest) { 
		
		return 0;
	}
	
}
