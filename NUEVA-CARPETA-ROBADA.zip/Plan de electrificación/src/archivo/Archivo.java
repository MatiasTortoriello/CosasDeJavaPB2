package archivo;

public class Archivo {

}
