
public class Main {
	public static void main(String[] args) {
		Guerrero g1 = new Guerrero(0, 0, 100, 20);
		Guerrero g2 = new Guerrero(0, 0, 100, 10);
		Guerrero g3 = new Guerrero(0, 0, 100, 10);
		Guerrero g4 = new Guerrero(0, 0, 100, 10);
		Guerrero g5 = new Guerrero(0, 0, 100, 10);

		Tropa tropa = new Tropa();
		Tropa tropa2 = new Tropa();

		tropa.agregarGuerrero(g1);
		tropa2.agregarGuerrero(tropa);
	}
}
