package edu.unlam.progava.triatlon;

public interface Nadador {

	public void nadar();
	
}
