package Medidas;

public enum MetodosPago {

	EFECTIVO(0,0),
	DEBITO(0,10);
	
	private double compor;
	private double comfija;
	
	public double getCompor()
	{
		return compor;
	}
	
	public double getComFija()
	{
		return comfija;
	}
	
	private MetodosPago(double compor,double comfija)
	{
		this.compor = compor;
		this.comfija = comfija;
	}
}
