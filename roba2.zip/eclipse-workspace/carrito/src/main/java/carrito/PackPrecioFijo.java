package carrito;

public class PackPrecioFijo extends Pack {
	double precioFijo;
	public PackPrecioFijo() {
		// TODO Auto-generated constructor stub
	}

}
