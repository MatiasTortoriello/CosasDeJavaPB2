package ar.edu.unlam.pb2;

public class Cuenta {

	private Integer nroCuenta;
	private Double saldo;
	private Titular titular;

	public Cuenta(Integer nroCuenta, Double saldo, Titular titular) {
		//Titular registrado 
		this.nroCuenta = nroCuenta;
		this.saldo = saldo;
		this.titular = titular;
	}

	public Cuenta(Integer nroCuenta, Double saldo, String nombre, String apellido, Integer dni) {
	// Titular no registrado
		super();
		this.titular = new Titular(nombre, apellido, dni);
		this.nroCuenta = nroCuenta;
		this.saldo = 0.0;
	}
	// Metodos
	public Boolean extraer(Double monto) {
		if (saldo >= monto) {
			this.saldo -= monto;
			return true;
		}
		return false;
	}

	public void depositar(Double monto) {
		this.saldo += monto;
	}

	public Integer getNroCuenta() {
		return nroCuenta;
	}

	public void setNroCuenta(Integer nroCuenta) {
		this.nroCuenta = nroCuenta;
	}

	public Double getSaldo() {
		return saldo;
	}

	public void setSaldo(Double saldo) {
		this.saldo = saldo;
	}

	public Titular getTitular() {
		return titular;
	}

	public void setTitular(Titular titular) {
		this.titular = titular;
	}

}
