package graph.coloring;

import graph.Graph;
import graph.coloring.order.Order;

public class ColoringFirstColor implements ColoringMethod {

	@Override
	public Coloring paint(Graph graph, Order order) {
		Coloring coloring = new Coloring();
		
		// TODO: Implement me!
		
		return coloring;
	}
	
}
