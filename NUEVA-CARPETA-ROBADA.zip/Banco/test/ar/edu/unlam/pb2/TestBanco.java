package ar.edu.unlam.pb2;

import static org.junit.Assert.*;

import org.junit.Test;

public class TestBanco {

	@Test
	public void queSePuedaCrearUnaCajaDeAhorro() {
		CajaDeAhorro cajaAhorro = new CajaDeAhorro(null, null, null, null, null, null);
		
		CuentaCorriente cuentaCorriente  = new CuentaCorriente(0, 0.0, "x", "y", 12312541);
	}

}
