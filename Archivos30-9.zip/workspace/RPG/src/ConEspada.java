
public class ConEspada extends ConItem{
	
	public ConEspada(Accionable item){
		super(item);
	}
	
	public int getDanio(){
		return 10 + super.getDanio();
	}
	
}
