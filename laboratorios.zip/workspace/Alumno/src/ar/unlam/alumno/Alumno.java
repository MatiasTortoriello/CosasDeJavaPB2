package ar.unlam.alumno;

public class Alumno {

	private String nombre;
	private String apellido;
	private Integer dni;
	private Boolean estado;
	private String legajo;

	public Alumno(String nombre, String apellido, Integer dni, Boolean estado, String legajo) {

	}

	public Alumno() {
		// TODO Auto-generated constructor stub
	}

	public Alumno crearAlumno(String nombre, String apellido, Integer dni, Boolean estado, String legajo) {

		Alumno alumno1 = new Alumno(nombre, apellido, dni, estado, legajo);
		alumno1.setNombre(nombre);
		alumno1.setApellido(apellido);
		alumno1.setDni(dni);
		alumno1.setEstado(estado);
		alumno1.setLegajo(legajo);
		return alumno1;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public void setApellido(String apellido) {
		this.apellido = apellido;
	}

	public void setDni(Integer dni) {
		this.dni = dni;
	}

	public void setEstado(Boolean estado) {
		this.estado = estado;
	}

	public void setLegajo(String legajo) {
		this.legajo = legajo;
	}

	public String getNombre() {
		return nombre;
	}

	public String getApellido() {
		return apellido;
	}

	public Integer getDni() {
		return dni;
	}

	public Boolean getEstado() {
		return estado;
	}

	public String getLegajo() {
		return legajo;
	}

}
