package rpg;

public class main2 {

	public static void main(String[] args) {
		IDa�o jug = new Jugador();
		System.out.println(jug.obtenerDanio());
		
		jug = new ConEspada(jug);
		System.out.println(jug.obtenerDanio());
	}

}
