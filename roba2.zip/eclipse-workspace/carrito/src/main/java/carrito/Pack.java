package carrito;
import java.util.List;

public class Pack implements Item{
	private List<Articulo> la;
	
	public Pack() {
		
	}
	public void agregarArticulo() {
		
	}

}
