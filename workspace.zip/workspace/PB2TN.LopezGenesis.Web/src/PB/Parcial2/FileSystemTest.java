package PB.Parcial2;

import static org.junit.Assert.*;

import org.junit.Test;

public class FileSystemTest {

	@Test
	public void hacerQueSeAgreguenDiscosRigidos() {
		
		FileSystem fileSystem= new FileSystem();
		
		
	}

}
