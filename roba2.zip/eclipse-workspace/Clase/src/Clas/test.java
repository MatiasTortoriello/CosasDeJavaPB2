package Clas;

import java.util.HashMap;
import java.util.Map.Entry;

public class test {
	
	public static void main(String[] args) {
		
		HashMap <String, String> x = new HashMap <String, String> ();
		HashMap <String, String> y = new HashMap <String, String> ();
	
		
		x.put("argentina", "Bs As");
		x.put("brasil", "Rio de Janeiro");
		
		for (Entry<String, String> k : x.entrySet()) {
			System.out.println(k.getKey());
		}
		
	
		
		
	}

	
}
