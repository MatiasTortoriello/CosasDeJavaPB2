
public class Lectura {

}
