package ar.edu.unlam.figuras;

import static org.junit.Assert.assertEquals;

import org.junit.Test;

public class TestFiguras {

	@Test
	
	public void queSePuedaInformarElNombreDeUnCirculo() {
		String nombre = "circulo";
		Circulo circulo = new Circulo(nombre);
		String nombreObtenido = circulo.obtenerNombre();
		assertEquals(nombre, nombreObtenido);
	}
	
	@Test
	
	public void queSePuedaInformarElColorDeUnCirculo() {
		String nombre = "cuadrado";
		String color = "rojo";
		Circulo circulo = new Circulo(nombre, color);
		String colorObtenido = circulo.obtenerColor();
		assertEquals(color, colorObtenido);
	}
	
	@Test
	
	public void queSePuedaInformarElNombreDeUnCuadrado() {
		String nombre = "cuadrado";
		Cuadrado cuadrado = new Cuadrado(nombre);
		String nombreObtenido = cuadrado.obtenerNombre();
		assertEquals(nombre, nombreObtenido);
	}
	
	@Test
	
	public void queSePuedaInformarElColorDeUnCuadrado() {
		String nombre = "cuadrado";
		String color = "azul";
		Cuadrado cuadrado = new Cuadrado(nombre, color, 2.0);
		String colorObtenido = cuadrado.obtenerColor();
		assertEquals(color, colorObtenido);
	}
	
	/*
	 * @Test
	 * 
	 * public void queSePuedaCrearUnaFiguraDeColorBlanco() { String nombre =
	 * "figura"; String color = "blanco"; Figura figura = new Figura(nombre, color);
	 * String colorObtenido = figura.obtenerColor(); assertEquals(color,
	 * colorObtenido); }
	 */
	
	@Test
	
	public void queSePuedaObtenerElNombreDeUnaFiguraCuadrada() {
		String nombre = "figura";
		String color = "blanco";
		Figura cuadrado = new Cuadrado(nombre, color, 2.0);
		String nombreObtenido = cuadrado.obtenerNombre();
		assertEquals(nombre, nombreObtenido);
	}
	
	@Test
	
	public void queSePuedaCalcularElAreaDeUnaFigura() {
		String nombre = "figura";
		String color = "blanco";
		Double lado = 2.0;
		Double areaEsperada = 4.0;
		
		Figura cuadrado = new Cuadrado(nombre, color, lado);
		
		Double areaObtenida = cuadrado.calcularArea();
		
		assertEquals(areaEsperada, areaObtenida);
		
	}

}
