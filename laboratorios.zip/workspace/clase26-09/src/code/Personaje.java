package code;

public class Personaje {

	private int altura;
	private int fuerza;

	public Personaje(int altura, int fuerza) {
		this.altura = altura;
		this.fuerza = fuerza;
	}

	public int calcularDistancia(Objeto o) {

		return o.tienePeso() ? (this.altura * this.fuerza) / o.getPeso() : 0;
	}

}
