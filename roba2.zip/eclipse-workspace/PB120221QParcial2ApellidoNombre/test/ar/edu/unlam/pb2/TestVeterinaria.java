package ar.edu.unlam.pb2;

import static org.junit.Assert.*;

import org.junit.Test;

public class TestVeterinaria {

	@Test
	public void queSePuedaInstanciarUnaVeterinariaConNombre() {
		
		
		String nombreVeterinaria = "bichito";
		Veterinaria vet = new Veterinaria(nombreVeterinaria);
		assertEquals(nombreVeterinaria, vet.getNombre());
		
	}

	
	 @Test 
	 public void queSePuedaCrearUnDuenioConDniYConNombre() {
		  
		 Integer dni = 11222333;
		 String nombre = "Daniel";
		 Duenio duenio = new Duenio(dni, nombre);
		 assertEquals(nombre, duenio.getNombre());
		 assertEquals(dni, duenio.getDni());
		  
	 }
	  
		
	 @Test 
	 public void queSePuedaCrearUnaMascotaConNombreIdApodoYTipoDeMascota() {
		 
		 String nombreMascota = "Perro";
		 Integer idMascota = 1234;
		 String apodoMascota = "Haku";
		 String tipoMascota = "domestica";
		 
		 Mascota mascota = new Mascota(nombreMascota, idMascota, apodoMascota, tipoMascota);
		 
		 assertEquals(nombreMascota, mascota.getNombreMascota());
		 assertEquals(idMascota, mascota.getIdMascota());
		 assertEquals(apodoMascota, mascota.getApodoMascota());
		 assertEquals(tipoMascota, mascota.getTipoMascota());
		 // El tipo de mascota puede ser solamente doméstica y exótica (enum) 
		 
	 }
		  
		
		
  @Test public void queSePuedaAgregarDosMascotasAUnDuenio() throws MascotaDuplicadaException {
  
	  String nombreMascota1 = "Perro"; Integer idMascota1 = 1234; String
	  apodoMascota1 = "Haku"; String tipoMascota1 = "domestica";
	  
	  Mascota mascota1 = new Mascota(nombreMascota1, idMascota1, apodoMascota1,
	  tipoMascota1);
	  
	  String nombreMascota2 = "Loro"; Integer idMascota2 = 5678; String
	  apodoMascota2 = "Morfeo"; String tipoMascota2 = "exotica";
	  
	  Mascota mascota2 = new Mascota(nombreMascota2, idMascota2, apodoMascota2,
	  tipoMascota2);
	  
	  Integer dni = 11222333; String nombre = "Daniel";
	  
	  Duenio duenio = new Duenio(dni, nombre);
	  
	  duenio.agregarMascota(mascota1); 
	  duenio.agregarMascota(mascota2);
	  
	  assertEquals(2, duenio.getCantidadDeMascotas());
  
  }
		 
		  
	
	@Test (expected = MascotaDuplicadaException.class)
	public void queAlAgregarDosMascotasConMismoIdParaUnMismoDuenioLanceUnaExcepcionMascotaDuplicadaException() throws MascotaDuplicadaException{
		
		String nombreMascota1 = "Perro";
		Integer idMascota1 = 1234;
		String apodoMascota1 = "Haku";
		String tipoMascota1 = "domestica";
		 
		Mascota mascota1 = new Mascota(nombreMascota1, idMascota1, apodoMascota1, tipoMascota1);
		
		String nombreMascota2 = "Loro";
		Integer idMascota2 = 1234;
		String apodoMascota2 = "Morfeo";
		String tipoMascota2 = "exotica";
		 
		Mascota mascota2 = new Mascota(nombreMascota2, idMascota2, apodoMascota2, tipoMascota2);
		
		Integer dni = 11222333;
		String nombre = "Daniel";
		
		Duenio duenio = new Duenio(dni, nombre);
		
		duenio.agregarMascota(mascota1); 
		duenio.agregarMascota(mascota2);
		
		
	}
	  
	
	  @Test public void queSePuedaCrearUnMedicamentoConIdDescripcionYPrecio() {
	  
		  Integer idMedicamento = 4321;
		  String descripcion = "antibiotico";
		  Double precio = 230.50;
		  Medicamento remedio = new Medicamento (idMedicamento, descripcion, precio);
		  
		  assertEquals(idMedicamento, remedio.getIdMedicamento());
		  assertEquals(descripcion, remedio.getDescripcion());
		  assertEquals(precio, remedio.getPrecio());
		  
		  
	  }
	  
	  @Test public void queSePuedanAgregarDueniosDeMascotasAUnaVeterinaria() {
		  
		 String nombreVeterinaria = "bichito";
		 Veterinaria vet = new Veterinaria(nombreVeterinaria);
	  
		Integer dni = 11222333;
		String nombre = "Daniel";
		Duenio duenio = new Duenio(dni, nombre);
		
		vet.agregarDuenio(duenio);
		
		assertTrue(vet.buscarDuenio(dni));
		
		
		
		  
	  }
	  
	  
	  
		/*
		 * @Test public void queSePuedaCrearUnaAtencionConDuenioMascotaYPrecio() throws
		 * DuenioInexistenteException, MascotaNoEncontradaException{
		 * 
		 * }
		 * 
		 * @Test public void queSePuedaAsignarVariosMedicamentosAUnaAtencion() { // Para
		 * asignar un medicamento necesita el id de la atencion y el id del medicamento
		 * }
		 * 
		 * @Test public void queSePuedaCalcularElPrecioTotalDeUnaAtencion() { // El
		 * precio total de la atencion será la suma del precio de la atencion mas la
		 * suma del precio de todos los medicamentos }
		 * 
		 * @Test public void
		 * queSePuedaObtenerDeUnDuenioUnaListaDeMascotasDomesticasOrdenadasPorApodo() {
		 * 
		 * }
		 * 
		 * @Test public void queSePuedaObtenerUnMapaConIdDeAtencionYIdDeMascota() {
		 * 
		 * }
		 */
	 
	 
		 
		 
	 
	
}
