package ar.edu.unlam.dominio;

public enum TiposDeArchivos {

	JPG,PNG,TXT,EXE;
}
