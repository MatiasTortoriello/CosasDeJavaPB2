package ar.unlam.figuras;

public class Cuadrado extends Figura {
	
	private Double lado;

	public Cuadrado(String nombre) {
		super(nombre);
		
	}
	@Override 
	public String getTipo(){
		return "Cuadrado";
	}

	public Cuadrado( String color,Double lado) {
		super(color);
		this.lado=lado;
	}

	public Double calcularArea() {
		
		return Math.pow(this.lado,this.lado);
	}

	// public String obtenerNombre(){
	// return this.nombre;
	// }
	//
	// public String obtenerColor() {
	// return this.color;
	// }

}
