package patron_Decorator;

public abstract class Unidad {
	public abstract int getAtaque();
	public abstract int getDefensa();
}
