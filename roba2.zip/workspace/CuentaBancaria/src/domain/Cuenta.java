package domain;

public class Cuenta {

	private Integer nroCuenta;
	private Double saldo;
	private Titular titular;
	
	public Cuenta (Integer nroCuenta, Double saldo, Titular titular){
		this.nroCuenta = nroCuenta;
		this.saldo = saldo;
		this.titular = titular;
	}
	
	public Cuenta(Integer nroCuenta, Titular titular) {
		super();
		this.nroCuenta = nroCuenta;
		this.titular = titular;
		this.saldo = 0.0;
	}
	
	public Cuenta(Integer nroCuenta, String nombre, String apellido, Integer dni) {
		super();
		this.nroCuenta = nroCuenta;
		this.titular = new Titular(nombre, apellido, dni);
		this.saldo = 0.0;
	}

	public Boolean extraer(Double monto) {
		if (this.saldo >= monto) {
			this.saldo -= monto;
			return true;
		}
		return false;
	}

	public void depositar(Double monto) {
		this.saldo += monto;
	}
	
	public Integer getNroCuenta() {
		return nroCuenta;
	}
	
	public void setNroCuenta(Integer nroCuenta) {
		this.nroCuenta = nroCuenta;
	}
	
	public Double getSaldo() {
		return saldo;
	}
	
	public void setSaldo(Double saldo) {
		this.saldo = saldo;
	}
	
	public Titular getTitular() {
		return titular;
	}
	
	public void setTitular(Titular titular) {
		this.titular = titular;
	}

	
	
}
