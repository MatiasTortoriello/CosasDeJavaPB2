package Unidades;

public class App {
	
	public static void main(String[] args) {
		
		Metro a = new Metro(10);
		/*
		System.out.println(a.toKilometro());
		System.out.println(a.toMilla());
		System.out.println(a.toPie());
		System.out.println(a.toMetro());
		*/
		
		UnidadDeLongitud[] medidas = {a.toKilometro(), a.toMilla(), a.toPie(), a.toMetro()};
		
		for (UnidadDeLongitud medida : medidas) { //UnidadDeLongitud (int) medida (i) : medidas (vector)
			System.out.println(medida.toMetro());
		}
	}

}
