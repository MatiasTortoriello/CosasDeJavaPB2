
public class Contador {
		
	private static final int MAXIMO_VALOR_CONTABLE = 9999;
	private static int cont;
	
	public Contador()
	{
		Contador.cont = 0;
	}
	
	public static void contar()
	{	
		Contador.cont = Contador.cont == MAXIMO_VALOR_CONTABLE ? 0 : ++(Contador.cont);
		
	}
	public void reiniciar()
	{
		Contador.cont = 0;
	}
	
	public int mostrar()
	{
		return Contador.cont;
	}
}
