package LuchadoresJaponeses;

public class Luchador {
	private double peso;
	private double altura;

	public Luchador(double peso, double altura) {
		// TODO Auto-generated constructor stub

		this.peso = peso;
		this.altura = altura;
	}
	
	public boolean dominaA(Luchador other) {
		if(this.peso > other.peso && this.altura > other.altura) {
			return true;
		} else if(this.peso == other.peso && this.altura > other.altura) {
			return true;
		} else if(this.altura == other.altura && this.peso > other.peso) {
			return true;
		} else {
			return false;
		}
	}

}
