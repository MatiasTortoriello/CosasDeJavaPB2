package patron_Composite;

public abstract class Unidad {
	public abstract void atacar(Unidad enemigo);
	public abstract void recibirAtaque(int danio);
	public abstract boolean estaVivo();
}
