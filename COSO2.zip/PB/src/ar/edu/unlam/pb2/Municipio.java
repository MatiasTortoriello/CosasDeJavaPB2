package ar.edu.unlam.pb2;

public class Municipio {
  
	private Integer numeroDeMunicipio;
	private String nombreDeMunicipio;

	public Municipio (Integer numeroDeMunicipio, String nombreDeMunicipio) {
		this.numeroDeMunicipio = numeroDeMunicipio;
		this.nombreDeMunicipio = nombreDeMunicipio;
	}
}
