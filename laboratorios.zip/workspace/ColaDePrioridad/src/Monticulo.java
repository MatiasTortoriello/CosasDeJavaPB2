import java.util.ArrayList;
import java.util.List;

public class Monticulo {

	private ArrayList<Integer> monticulo;

	public Monticulo(ArrayList<Integer> monticulo) {
		this.monticulo = monticulo;
	}

	public int obtenerRaiz() {
		return this.monticulo.get(0);
	}

	public void mostrarMonticulo() {
		System.out.println(this.monticulo);
	}

	public void insertarNodo(int numero) {
		if (monticulo.isEmpty()) {
			monticulo.add(0, null);
			monticulo.add(1, numero);
		} else {
			monticulo.add(numero);
		}

		acomodarNodo();

	}

	// acomodar nodo agarra el ultimo elemento y lo compara con el de arriba e
	// intercambia
	private void acomodarNodo() {
		int posUltimo = monticulo.size() - 1;
		int posPadre = posUltimo / 2;
		int aux;

		if (posPadre != 0) {
			while (monticulo.get(posPadre) < monticulo.get(posUltimo)) {
				// intercambio
				aux = monticulo.get(posPadre);
				monticulo.set(posPadre, monticulo.get(posUltimo));
				monticulo.set(posUltimo, aux);

				// calculo las posiciones

				posUltimo = posPadre;
				posPadre = posUltimo == 1 ? posPadre : posUltimo / 2;

			}
		}
	}

	public static void main(String[] args) {
		ArrayList<Integer> monticulo = new ArrayList<Integer>();
		Monticulo m = new Monticulo(monticulo);
		m.insertarNodo(70);
		m.insertarNodo(80);
		m.insertarNodo(100);
		m.insertarNodo(90);
		m.mostrarMonticulo();

	}

}
