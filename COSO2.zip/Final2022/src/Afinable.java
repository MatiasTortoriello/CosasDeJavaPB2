
public interface Afinable {
	public void afinar();
}
