package excepciones;

public class RadioNegativoException extends RuntimeException{

	/**
	 * 
	 */
	private static final long serialVersionUID = -1582226803976856833L;

	public RadioNegativoException() {
		super("Radio negativo inaceptable");
	}
	
	public RadioNegativoException(String mensaje) {
		super(mensaje);
	}
	
}
