package Carrito;

public class Banana extends Articulo {

	public Banana(double precio) {
		super(precio);
		// TODO Auto-generated constructor stub
	}

	

}
