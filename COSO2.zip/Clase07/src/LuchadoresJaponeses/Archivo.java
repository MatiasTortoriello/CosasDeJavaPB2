package LuchadoresJaponeses;


import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Scanner;


public class Archivo {
	private String nombre;

	public Archivo(String nombre) {
		this.nombre = nombre;
	}

	public Luchador[] leerArchivo() {
		Scanner scanner = null;
		Luchador[] datos = null;

		try {
			File file = new File(this.nombre + ".txt");
			scanner = new Scanner(file);

			//scanner.useLocale(Locale.ENGLISH);

			int cant = scanner.nextInt();
			datos = new Luchador[cant];
			
			for (int i = 0; i < cant; i++) {
				
				double peso = scanner.nextDouble();
				double altura = scanner.nextDouble();
				
				Luchador l = new Luchador(peso,altura);
				
				datos[i] = l;
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {

			scanner.close();
		}
		return datos;
	}

	public void guardarArchivo(int[] datos) {
		FileWriter file = null;
		PrintWriter printerWriter = null;

		try {
			file = new FileWriter(this.nombre +" Salida" + ".txt");
			printerWriter = new PrintWriter(file);

			for (int i = 0; i < datos.length; i++) {

				printerWriter.println(datos[i]);
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			if (file != null) {
				try {
					file.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		}
	}
}
