package ar.edu.unlam.pb2;

import ar.edu.unlam.pb2.interfaces.Multeable;


public class Camion extends MedioTransporte implements Multeable{

	private Integer pesoMaximoPermitido;
	private String patente;
	private int velocidadMaximaPermitida;
	private Integer velocidad;
	private Double peso;
	private Boolean cruzarEnRojo;
	private Boolean papelesAlDia;
	
	public Camion(String patente, int velocidadMaximaPermitida,int pesoMaximoPermitido , double latitud, double longitud) {
		super(latitud, longitud);
		this.pesoMaximoPermitido=pesoMaximoPermitido;
		this.patente=patente;
		this.velocidadMaximaPermitida=velocidadMaximaPermitida;
		this.pesoMaximoPermitido=pesoMaximoPermitido;
		this.velocidad=0;
		this.peso=0.0;
		this.cruzarEnRojo=false;
		this.papelesAlDia=true;
	}
	

	public Integer getVelocidad() {
		return velocidad;
	}


	public Boolean getCruzarEnRojo() {
		return cruzarEnRojo;
	}


	public void setCruzarEnRojo(Boolean cruzarEnRojo) {
		this.cruzarEnRojo = cruzarEnRojo;
	}


	public Boolean getPapelesAlDia() {
		return papelesAlDia;
	}


	public void setPapelesAlDia(Boolean papelesAlDia) {
		this.papelesAlDia = papelesAlDia;
	}


	public void setVelocidad(Integer velocidad) {
		this.velocidad = velocidad;
	}


	public Integer getPesoMaximoPermitido() {
		return pesoMaximoPermitido;
	}

	public void setPesoMaximoPermitido(Integer pesoMaximoPermitido) {
		this.pesoMaximoPermitido = pesoMaximoPermitido;
	}

	public String getPatente() {
		return patente;
	}

	public void setPatente(String patente) {
		this.patente = patente;
	}

	public int getVelocidadMaximaPermitida() {
		return velocidadMaximaPermitida;
	}

	public void setVelocidadMaximaPermitida(int velocidadMaximaPermitida) {
		this.velocidadMaximaPermitida = velocidadMaximaPermitida;
	}

	@Override
	public Boolean superoVelocidadMaxima() throws VelocidadMaximaException {
		if(this.velocidad <=this.velocidadMaximaPermitida){
			return false;
		}
		throw new VelocidadMaximaException();
	}

	@Override
	public Boolean superoPesoMaximoCarga() throws PesoMaximoException {
		if(this.peso <=this.pesoMaximoPermitido){
			return false;
		}
		throw new PesoMaximoException();
	}
	

	@Override
	public Boolean cruzoEnRojo() throws NoRespetoSemaforoException {

		if(!this.cruzarEnRojo){
			return false;
		}
		throw new NoRespetoSemaforoException();
	}

	@Override
	public Boolean estaEnRegla() throws FlojoDePapelesException {
		if(this.papelesAlDia){
			return true;
		}
		throw new FlojoDePapelesException();
	}


	public Double getPeso() {
		return peso;
	}


	public void setPeso(Double peso) {
		this.peso = peso;
	}
	public void cruzarMal(){
		this.cruzarEnRojo=true;
	}
}
