package unlam.practicame;

public class FraudeException extends Exception {

	public FraudeException (){
		
	}
	
	public FraudeException (String mensaje){
		super (mensaje);
	}
	
}
