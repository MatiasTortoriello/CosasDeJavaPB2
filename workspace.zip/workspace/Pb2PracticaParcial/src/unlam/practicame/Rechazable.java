package unlam.practicame;

public interface Rechazable {
	
	public Boolean monitorear() throws FraudeException;

}

