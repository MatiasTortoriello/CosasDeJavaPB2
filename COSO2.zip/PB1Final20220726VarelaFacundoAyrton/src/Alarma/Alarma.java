package Alarma;

public class Alarma {

private String nombreDeLaAlarma;
private int cantidadDeSensoresMaximos;
private String codigoDeConfiguracion;
private String CODIGO_ADMINISTRADOR="C137";
private	String CODIGO_ACTIVACION="C500";
private Sensor sensores[];


public Alarma (String nombreDeLaAlarma, int cantidadDeSensoresMaximo, String codigoDeConfiguracion){
	this.nombreDeLaAlarma=nombreDeLaAlarma;
	this.cantidadDeSensoresMaximos=cantidadDeSensoresMaximos;
	this.codigoDeConfiguracion=codigoDeConfiguracion;
	sensores=new Sensor[cantidadDeSensoresMaximo];
}

public String getCodigoDeConfiguracion() {
	return codigoDeConfiguracion;
}

public void setCodigoDeConfiguracion(String codigoDeConfiguracion) {
	this.codigoDeConfiguracion = codigoDeConfiguracion;
}

public String getCODIGO_ADMINISTRADOR() {
	return CODIGO_ADMINISTRADOR;
}

public void setCODIGO_ADMINISTRADOR(String cODIGO_ADMINISTRADOR) {
	CODIGO_ADMINISTRADOR = cODIGO_ADMINISTRADOR;
}

public String getCODIGO_ACTIVACION() {
	return CODIGO_ACTIVACION;
}

public void setCODIGO_ACTIVACION(String cODIGO_ACTIVACION) {
	CODIGO_ACTIVACION = cODIGO_ACTIVACION;
}

public static boolean validarCodigoIngresado (String codigo){
	int cantidadDeCaracteres=0;
	boolean seEncontroC=false;
	boolean longitudMayorACuatro=false;
	boolean seEncontroNumero=false;
	boolean seEncontroLetra=false;
	boolean codigoCorrecto=false;
	
	for (int i=0;i<codigo.length();i++){
		
		if (codigo.charAt(0)==67&&seEncontroC==false){
			seEncontroC=true;
		}
		cantidadDeCaracteres++;
		if (cantidadDeCaracteres>=4&&longitudMayorACuatro==false){
			longitudMayorACuatro=true;
		}
		if(codigo.charAt(i)>=47&&codigo.charAt(i)<=56){
			seEncontroNumero=true;
		}
		if (codigo.charAt(i)>=65&&codigo.charAt(i)<=90){
			seEncontroLetra=true;
		}
		if (codigo.charAt(i)>=97&&codigo.charAt(i)<=122){
			seEncontroLetra=true;
		}
	}
	if (seEncontroLetra==true&&seEncontroNumero==true&&seEncontroC==true&&longitudMayorACuatro==true){
			codigoCorrecto=true;
		}
	return codigoCorrecto;	
}
public boolean agregarSensor (Sensor nuevoSensor){
	boolean seAgrego=false;
	for (int i=0;i<sensores.length;i++){
		if (sensores[i]==null&&seAgrego==false){
			sensores[i]=nuevoSensor;
			seAgrego=true;
		}
	}
	return seAgrego;
}
public boolean habilitarODeshabilitarSensor (int id){
	boolean seEncontro=false;
	for (int i=0;i<sensores.length;i++){
		if (sensores[i]!=null&&sensores[i].getId()==id&&seEncontro==false){
			if (sensores[i].getEstado()==0){
				sensores[i].setEstado(1);
			}
			if (sensores[i].getEstado()==1){
				sensores[i].setEstado(0);
			}
			seEncontro=true;
		}
	}
	return seEncontro;
}
public boolean habilitarPorZona (Zona zona){
	boolean seHabilitaron=false;
	Sensor sensoresPorZona[]=new Sensor [sensores.length];
	int posicionVector=0;
	for (int i=0;i<sensores.length;i++){
		if (sensores[i]!=null&&sensores[i].getZona().equals(zona)){
			sensoresPorZona[posicionVector]=sensores[i];
			posicionVector++;
		}
	}
	if (sensoresPorZona[0]==null){
		return seHabilitaron=false;
	}else{
		
		for (int j=0;j<sensoresPorZona.length;j++){
			if (sensoresPorZona[j]!=null&&sensoresPorZona[j].getEstado()==0){
				sensoresPorZona[j].setEstado(1);
			}
		}
		seHabilitaron=true;
	}
	return seHabilitaron;
}
public Sensor obtenerPorNombre (String nombre){
	Sensor sensorBuscado=null;
	for (int i=0;i<sensores.length;i++){
		if (sensores[i]!=null&&sensores[i].getNombreDelSensor().equals(nombre)){
			sensorBuscado=sensores[i];
		}
	}
	return sensorBuscado;
}
public String deshabilitadosPorZona (Zona zona){
	Sensor sensoresDeshabilitadosPorZona[]=new Sensor [sensores.length];
	int posicionVector=0;
	boolean haySensoresCorrectos=false;
	String mensaje="";
	for (int i=0;i<sensores.length;i++){
		if (sensores[i]!=null&&sensores[i].getZona().equals(zona)&&sensores[i].getEstado()==0){
			sensoresDeshabilitadosPorZona[posicionVector]=sensores[i];
			posicionVector++;
			haySensoresCorrectos=true;
		}
}
	if (haySensoresCorrectos==true){
		for (int j=0;j<sensoresDeshabilitadosPorZona.length;j++){
			if (sensoresDeshabilitadosPorZona[j]!=null){
				mensaje+=sensoresDeshabilitadosPorZona[j]+"\n ******************  \n";
			}
		}
		
	}
	return mensaje;
}
/*public boolean cambiarEstadoAlarma (){
	boolean activador=false;
	int contadorSensoresActivos=0;
	for (int i=0;i<sensores.length;i++){
		if (sensores[i]!=null&&sensores[i].getEstado()==0){
			return false;
		}else{
		if (sensores[i]!=null&&sensores[i].getEstado()==1){
			
		}
				
		}
		
	}
	return activacion;
}*/
}

