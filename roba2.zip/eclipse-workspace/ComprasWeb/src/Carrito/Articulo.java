package Carrito;

public class Articulo {
	
	protected double precio;
	private String nombre;
	
	public Articulo(String nombre, double precio) {
		super();
		this.nombre = nombre;
		this.precio = precio;
	}

	public double getPrecio() {
		return precio;
	}

	public String getNombre() {
		return nombre;
	}
	
	

}
