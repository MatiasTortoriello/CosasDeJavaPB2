
public interface Lustrable {
	
	public void lustrar();

}
