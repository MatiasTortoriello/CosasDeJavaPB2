package ar.edu.unlam.pb1;



public class anotaciones {

	public static void main(String[] args) {
		System.out.println("WELCOME");
		/*
		 * public String buscarPorCodigo(int codigo) {
		for (int i = 0; i <decirDimensionDeArray(); i++) {
			if(coches[i] != null && coches[i].getCodigo()+1==codigo) {
				return coches[i].toString();
			}

		}
		return "No existe el codigo";
	}
		 * 
		 * public String mostrarListadoDeVehiculos(int i) {
		if(coches[i] != null) {
			return "Marca:"+coches[i].getMarca()+"\nModelo:"+coches[i].getModelo()+"\nPrecio:$"+coches[i].getPrecio()+"\nC�digo:"+coches[i].getCodigo();
	} else {
		return "";
	}
	}
		 * 
		 * 
		 * 
		 * public void ordenar() {
		for (int i = 1; i < coches.length; i++) {
			for (int j = 0; j < coches.length-1; j++) {
				if (coches[j]!= null && coches[j+1]!= null && coches[j].getMarca().compareTo(coches[j+1].getMarca()) > 0) {
					Coche auxiliar = coches[j];
					coches[j] = coches[j+1];
					coches[j+1] = auxiliar;
				}
			}
		}
		
	}
		 * 
		 * public boolean ingresarVehiculo(String marca, String modelo, double precio, int codigo) {
		boolean sePudoIngresarVehiculo=true;
		for (int j = 0; j < coches.length; j++)
			if (coches[j] != null && modelo.equals(coches[j].getModelo()))
				sePudoIngresarVehiculo = false;
		
		Coche coche = new Coche(marca, modelo, precio,codigo);
		
		
		
		for (int i = 0; i < coches.length; i++) {
			if (coches[i] == null) {
				codigo=i+1;
				coches[i] = coche;
				return sePudoIngresarVehiculo;
			}
		}
		return sePudoIngresarVehiculo;
	}
		 * 
		 * 
		 * public String buscar(String nombre) {
		for (int i = 0; i < usuarios.length; i++) {
			if(usuarios[i] != null && usuarios[i].getNombre().equals(nombre)) {
				return usuarios[i].toString();
			}

		}
		return "No existe el usuario";
	}

	public String[] filtrar(char letra) {
		String [] usuariosFiltrados = new String [10];
		for(int i = 0; i < usuarios.length; i++) {
			if (usuarios[i]!= null && usuarios[i].getNombre().charAt(0) == letra) {
			usuariosFiltrados[i] = usuarios[i].getNombre();
			}	
		}
		return usuariosFiltrados;
	}
		 * 
		 * public void ordenar(int opcion) {
		if (opcion == 1) {
			for (int i = 1; i < usuarios.length; i++) {
				for (int j = 0; j < usuarios.length-1; j++) {
					if (usuarios[j] !=null && usuarios[j+1]!=null && usuarios[j].getNombre().compareTo(usuarios[j+1].getNombre())>0) {
						Usuario auxiliar = usuarios[j];
						usuarios[j] = usuarios[j+1];
						usuarios[j+1] = auxiliar;
					}
				}
			}
		} else {
			for (int i = 1; i < usuarios.length; i++) {
				for (int j = 0; j < usuarios.length-1; j++) {
					if (usuarios[j] !=null && usuarios[j+1]!=null && usuarios[j].getNombre().compareTo(usuarios[j+1].getNombre())<0) {
						Usuario auxiliar = usuarios[j];
						usuarios[j] = usuarios[j+1];
						usuarios[j+1] = auxiliar;
					}
				}
			}
		}
		
	}
		 * 
		 * 
		 * 
		 * 
		 * public boolean registrar(String nombre, int clave) {
		boolean sePudoRegistrar = true;

		for (int j = 0; j < usuarios.length; j++)
			if (usuarios[j] != null && nombre.equals(usuarios[j].getNombre()))
				sePudoRegistrar = false;

		Usuario usuario = new Usuario(nombre, clave);
		for (int i = 0; i < usuarios.length; i++) {
			if (usuarios[i] == null) {
				usuarios[i] = usuario;
				sePudoRegistrar = true;
				break;
			}
		}
		return sePudoRegistrar;
	}

	public boolean loguear(String nombre, int clave) {
		
		for(int i = 0; i < usuarios.length; i++) {
			//miro donde el nombre sea igual
			if (usuarios[i]!= null && nombre.equals(usuarios[i].getNombre())) {
				//miro si la clave es igual
				if (clave == usuarios[i].getClave()) {
					return true;
				}
			}
		}
		return false;
	}

	public void editar(int clave, String nombre) {
		for(int i = 0; i < usuarios.length; i++) {
			if (usuarios[i]!= null && nombre.equals(usuarios[i].getNombre())) 
				usuarios[i].setClave(clave);
		}
	}

	public void eliminar(String nombre) {
		for(int i = 0; i < usuarios.length; i++) {
			if (usuarios[i]!= null && nombre.equals(usuarios[i].getNombre())) 
				usuarios[i] = null;
		}
	}
		 * 
		 * 
		 * 
		 * 
		 * 
		 * 
		 * 
		 * 
		 * 
		 * 
		 * 
		 * 
		 * 
		 * */
	}

}
