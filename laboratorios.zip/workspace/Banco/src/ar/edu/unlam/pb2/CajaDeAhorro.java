package ar.edu.unlam.pb2;

public class CajaDeAhorro extends Cuenta {

	private String tipo;
	
	public CajaDeAhorro(Integer nroCuenta, Double saldo, String nombre, String apellido, Integer dni, String tipo) {
		super(nroCuenta, saldo, nombre, apellido, dni);
		this.tipo = tipo;

	}



	public String getTipo() {
		return tipo;
	}

	public void setTipo(String tipo) {
		this.tipo = tipo;
	}

}
