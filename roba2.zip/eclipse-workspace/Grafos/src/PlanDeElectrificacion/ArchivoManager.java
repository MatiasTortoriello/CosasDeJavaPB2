package PlanDeElectrificacion;

public class ArchivoManager {

	public static void leerArchivo(String argvs) {
		
	}
}
