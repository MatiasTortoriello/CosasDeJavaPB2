package PB.Parcial2;

public class DiscoRigido extends FileSystem{

}
