package practicaWhile;

import java.util.Scanner;

public class practicaWhile {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
			Scanner Teclado= new Scanner(System.in);
			
			//ATRIBUTOS DEL ASCENSOR
			
			int pisoActual=1;
			int pisoMinimo=1;
			int pisoMaximo=6;
			int subirPiso;
			
			do{
			while(pisoActual<=pisoMaximo){
				System.out.println("Usted est� en el piso "+pisoActual);
				System.out.println("Seleccione cu�ntos pisos subir");
				subirPiso=Teclado.nextInt();
				pisoActual+=subirPiso;
				if(pisoActual>pisoMaximo){
					pisoActual-=subirPiso;
					}
			}
			}while(pisoActual<pisoMaximo);
			
	}

}
