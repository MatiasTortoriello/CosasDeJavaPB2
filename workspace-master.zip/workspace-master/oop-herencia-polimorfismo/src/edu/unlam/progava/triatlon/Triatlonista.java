package edu.unlam.progava.triatlon;

public class Triatlonista implements Nadador, Corredor {

	@Override
	public void correr() {
		// ...
	}

	@Override
	public void nadar() {
		// ...
	}
}
