package main;

import ejercicio.Resolucion;

public class Main {
	public static void main(String[] args) {
		Resolucion resolucion = new Resolucion();
		resolucion.resolver("uno");
	}
}
