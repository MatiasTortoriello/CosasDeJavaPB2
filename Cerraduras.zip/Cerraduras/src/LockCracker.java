
public class LockCracker {

	public int[] abrir(CerraduraDigital cerraduraDigital) {
		for (int i = 9; i >= 0; i--) {
			for (int j = 9; j >= 0; j--) {
				for (int k = 9; k >= 0; k--) {
					cerraduraDigital.ingresarClave(i, j, k);
					if (cerraduraDigital.presionarOk()) {
						return new int[] { i, j, k };
					}
				}
			}
		}
		return null;
	}
}
