package Clases;

public class Pasajero extends Persona{

	public Pasajero(Integer identificador, String nombre) {
		super(identificador, nombre);
	}

}
