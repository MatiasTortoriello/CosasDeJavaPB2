package ColaDePrioridad;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class Cola {
	
	List<Integer> cola = new ArrayList<Integer>();
	
	public Integer getMax() {
		if (this.cola.isEmpty())
			return null;
		return this.cola.get(1);
	}
	public Integer removeMax() {
		
		int i = 1;
		
		Collections.swap(cola, i, this.cola.size() - 1);
		
		while (i < (this.cola.size() - 1)) {
			if (this.cola.get(2*i).compareTo(this.cola.get((2 * i) + 1)) > 0 ) {
				Collections.swap(cola, 2 * i, i);
				i += 2 * i;
			}
			else {
				Collections.swap(cola, (2 * i) + 1, i);
				i += (2 * i) + 1;
			}
		}
		
		return this.cola.remove(this.cola.size() - 1);
		
	}
	public void insert(Integer o){
		this.cola.add(o);
	}
}
