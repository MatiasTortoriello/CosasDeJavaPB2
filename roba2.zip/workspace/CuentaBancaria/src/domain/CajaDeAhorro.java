package domain;

public class CajaDeAhorro extends Cuenta {

	private String tipo;

	public CajaDeAhorro(Integer nroCuenta, String nombre, String apellido, Integer dni, String tipo) {
		super(nroCuenta, nombre, apellido, dni);
		this.tipo = tipo;
	}


	public String getTipo() {
		return tipo;
	}

	public void setTipo(String tipo) {
		this.tipo = tipo;
	}
	
	
	
}
