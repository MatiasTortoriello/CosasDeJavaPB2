package ar.edu.unlam.aerolinea;

import static org.junit.Assert.assertEquals;

import org.junit.Test;

public class TestAerolinea {
	
	/*
	 * @Test
	 * 
	 * public void queSePuedaCrearAerolinea() {
	 * 
	 * }
	 */
	
	@Test
	
	public void queSePuedaAgregarAvion() {
		
		
		String modelo = "Boeing";
		String fabricante = "AirplaneFab";
		Integer id = 12345;
		Integer cantidadAsientos = 100;
		Avion avion = new Avion(modelo, fabricante, id, cantidadAsientos);
		
		Vuelo vuelo = new Vuelo();
		Boolean sePudoAgregarAvion = vuelo.agregarAvion(avion);
		Boolean valorEsperado = true;
		assertEquals(valorEsperado, sePudoAgregarAvion);
	}
	
	@Test
	
	public void queSePuedaAgregarPersonal() {
		
		String modelo = "Boeing";
		String fabricante = "AirplaneFab";
		Integer id = 12345;
		Integer cantidadAsientos = 100;
		Avion avion = new Avion(modelo, fabricante, id, cantidadAsientos);
		
		Vuelo vuelo = new Vuelo();
		Boolean sePudoAgregarAvion = vuelo.agregarAvion(avion);
		Boolean valorEsperado = true;
		assertEquals(valorEsperado, sePudoAgregarAvion);
		
		String nombrePiloto = "Juan";
		//String avionQuePilota = "Boeing";
		
		Personal piloto = new Piloto(nombrePiloto);
		Boolean sePudoAgregarPiloto = vuelo.agregarPersonal(piloto);
		Boolean valorEsperadoAgregarPiloto = true;
		assertEquals(valorEsperadoAgregarPiloto, sePudoAgregarPiloto);
		
		
		
	}
	
	@Test
	
	public void queSePuedaAgregarPersonalPiloto() {
		
	}
	
}
