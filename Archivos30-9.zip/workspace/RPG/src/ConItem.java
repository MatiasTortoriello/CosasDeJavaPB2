
public class ConItem implements Accionable{
	private Accionable decorado;

	public ConItem(Accionable acc){
		decorado = acc;
	}
	
	@Override
	public int getDanio() {
		return decorado.getDanio();
	} 
	
	
}
