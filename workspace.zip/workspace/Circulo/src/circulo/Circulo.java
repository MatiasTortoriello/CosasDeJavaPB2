package circulo;

public class Circulo {

	private Double radio=2.5;
	
	public void x(){
		int i=2;
		System.out.println("");
	}
	
	
}
