
public enum Medida {
	KILOMETROS(0.621371, 1000, 3280.81, 1,"km"), METROS(0.000621371, 1, 3.28084, 0.001,"mts"), PIE(0.000189394, 0.3048, 1,
			0.0003048,"pie"), MILLA(1, 1609.34, 5280, 1.60934,"milla");

	private double valorMilla;
	private double valorMetro;
	private double valorPies;
	private double valorKilometro;
	private String unidad;
	
	public double getValorMilla() {
		return valorMilla;
	}


	public double getValorMetro() {
		return valorMetro;
	}



	public double getValorPies() {
		return valorPies;
	}


	public double getValorKilometro() {
		return valorKilometro;
	}



	public String getUnidad() {
		return unidad;
	}



	private Medida(double milla, double metro, double pies, double kilometro,String unidadR) {
		valorMilla = milla;
		valorMetro = metro;
		valorPies = pies;
		valorKilometro = kilometro;
		unidad=unidadR;
	}

}
