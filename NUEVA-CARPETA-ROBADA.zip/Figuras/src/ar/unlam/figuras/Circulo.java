package ar.unlam.figuras;

public class Circulo extends Figura {
	private Double radio;

	public Circulo(String color, Double radio) {
		super(color);
		this.radio = radio;

	}
	
	@Override
	public Double calcularArea(){
		return this.radio*radio*Math.PI;
	}
	
	@Override 
	public String getTipo(){
		return "Circulo";
	}

	public Double getRadio() {
		return radio;
	}

	public void setRadio(Double radio) {
		this.radio = radio;
	}

	@Override
	public String toString() {
		return "Soy un Circulo radio=" + this.getRadio() + "y mi color es: " + obtenerColor() ;
	}
	

}
