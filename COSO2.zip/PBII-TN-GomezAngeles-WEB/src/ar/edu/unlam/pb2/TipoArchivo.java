package ar.edu.unlam.pb2;

public enum TipoArchivo {

	JPG,
	PDF,
	GIF
}
