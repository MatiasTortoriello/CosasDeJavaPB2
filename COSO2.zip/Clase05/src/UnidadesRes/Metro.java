package UnidadesRes;

public class Metro extends UnidadDeLongitud {
	private double valor;
	
	public Metro(double valor) {
		super(valor);
	}
	
	public double getValor() {
		return this.valor;
	}
	
	@Override
	public Kilometro toKilometro() {
		return new Kilometro(this.valor/1000);
	}
	
	@Override
	public Milla toMilla() {
		return new Milla(this.valor/1609);
	}
	
	@Override
	public Pie toPie() {
		return new Pie(this.valor*3.281);
	}

	@Override
	public Metro toMetro() {
		return this;
	}
	
	@Override
	public String toString() {
		return this.valor + "m";
	}
	
	@Override
	public UnidadDeLongitud sumar(UnidadDeLongitud other) {
		return new Metro(this.valor + other.toMetro().valor);
	}
	
	
	
	@Override
	public UnidadDeLongitud enMiUnidad(UnidadDeLongitud other) {
		return other.toMetro();
	}

	@Override
	public UnidadDeLongitud crear(double valor) {
		return new Metro(valor);
	}

	
	
}
