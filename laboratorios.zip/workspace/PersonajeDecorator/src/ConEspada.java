
public class ConEspada extends ConItem{
	
	public ConEspada(){
		
	}
	
	@Override
	public void atacar(Unidad otra) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void recibirDanio(int danio) {
		// TODO Auto-generated method stub
		
	}
	
}
