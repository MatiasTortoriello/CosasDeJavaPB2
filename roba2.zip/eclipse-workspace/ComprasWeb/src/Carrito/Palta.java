package Carrito;

public class Palta extends Articulo {

	public Palta(double precio) {
		super(precio);
		// TODO Auto-generated constructor stub
	}

	
}
