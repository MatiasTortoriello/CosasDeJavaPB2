package Medidas;

public class Medidas {

	public static double ConvertirUnidad(double cantidad, EnumMedidas unidadOrigen,	EnumMedidas unidadDestino) {
		if (unidadOrigen == unidadDestino) {
			return cantidad;
		}
		switch (unidadOrigen) {
		case EnumMedidas.MILLAS:
			switch (unidadDestino) {
			case EnumMedidas.KILOMETROS:
				return cantidad / 0.62137;
			

			}
			break;
		case "Kilometros":
			switch (unidadDestino) {
			case "Millas":
				return cantidad / 0.62137;

			case "Pies":
				return cantidad / 0.62137;

			case "Metros":
				return cantidad / 0.62137;

			}
			break;
		case "Pies":
			switch (unidadDestino) {
			case "Kilometros":
				return cantidad / 0.62137;

			case "Millas":
				return cantidad / 0.62137;

			case "Metros":
				return cantidad / 0.62137;

			}
			break;
		case "Metros":
			switch (unidadDestino) {
			case "Kilometros":
				return cantidad / 0.62137;

			case "Pies":
				return cantidad / 0.62137;

			case "Millas":
				return cantidad / 0.62137;

			}
			break;
		}
		return 0;
	}

}

//Un m�todo est�tico que recibe la cantidad, la unidad origen y 
//la unidad destino, retornando la cantidad en la unidad destino. 
//Manejarlo con Strings