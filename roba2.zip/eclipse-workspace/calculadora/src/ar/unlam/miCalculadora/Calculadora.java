package ar.unlam.miCalculadora;

public class Calculadora {

	public Integer sumar(Integer operando1, Integer operando2) {
		// TODO Auto-generated method stub
		return operando1 + operando2;
	}

	public Double dividir(Double numerador, Double denominador) {
		// TODO Auto-generated method stub
		return (numerador/denominador);
	}

	public Double multiplicar(Double operador1, Double operador2) {
		// TODO Auto-generated method stub
		return operador1*operador2;
	}

	public Double porcentaje(Double numero, Double porcentaje) {
		// TODO Auto-generated method stub
		return (numero*porcentaje/100.0);
	}

	
}
