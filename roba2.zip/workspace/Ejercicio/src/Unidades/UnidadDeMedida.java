package Unidades;
import static Unidades.Tipo.*;

public class UnidadDeMedida {

	private double unidad;
	private Tipo tipo;
	
	public UnidadDeMedida(double unidad, Tipo tipo) {
		super(); // heredo del obejto Object u otro
		this.unidad = unidad;
		this.tipo = tipo;
	}

	public void toKm () {
		if (METRO == this.tipo) {
			this.unidad *= 1000;
			this.tipo = KILOMETRO;
		} else if (MILLA == this.tipo) {
			this.unidad /= 1.60934;
			this.tipo = MILLA;
		}  else if (PIE == this.tipo) {
			this.unidad *= 0.3048;
			this.tipo = PIE;
		}	
	}
	
	public void toM () {
		if (KILOMETRO == this.tipo) {
			this.unidad /= 1000;
			this.tipo = KILOMETRO;
		} else if (MILLA == this.tipo) {
			this.unidad *= 1609.34;
			this.tipo = MILLA;
		}  else if (PIE == this.tipo) {
			this.unidad *= 3.28;
			this.tipo = PIE;
		}	
	}
}
