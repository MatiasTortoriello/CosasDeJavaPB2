package ar.edu.unlam.pb2.eva03;

public interface SegurosDeVida {

	void agregarBeneficiario(Persona hijo, TipoDeBeneficiario hijo2);
	Integer obtenerCantidadDeBeneficiarios();

}
