package vehiculo;

public class DemasiadoRapidoException extends Throwable {
	
	public String mensaje;
	
	public DemasiadoRapidoException () {
		this.mensaje = "Velocidad superada";
	}

}
