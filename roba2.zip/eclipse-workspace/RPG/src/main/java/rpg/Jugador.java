package rpg;

public class Jugador implements IDa�o {
	private int danio = 10;
	
	public Jugador() {
		// TODO Auto-generated constructor stub
	}

	public int obtenerDanio()
	{
		return this.danio;
	}
	
	public void setDanio(int danio) {
		this.danio = danio;
	}

	public int getDanio() {
		return this.danio;
	}

}
