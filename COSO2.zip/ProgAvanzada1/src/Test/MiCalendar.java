package Test;

import java.util.Calendar;
import java.util.GregorianCalendar;

import Exception.MiCalendarioException;

public class MiCalendar extends GregorianCalendar {

	public MiCalendar() {
		super();
	}

	public MiCalendar(int dia, int mes, int anio) throws MiCalendarioException {
		super(anio, mes-1, dia);
		setLenient(false);
		try {
			this.get(Calendar.YEAR);
		} catch (Exception e) {
			throw new MiCalendarioException("La fecha es invalida");
		}
		
	}
	
}
