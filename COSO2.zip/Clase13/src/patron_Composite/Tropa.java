package patron_Composite;

import java.util.ArrayList;
import java.util.List;

public class Tropa extends Unidad {
	
	private List<Unidad> formacion = new ArrayList<Unidad>();
	
	public boolean agregar(Unidad unidad) {
		return this.formacion.add(unidad);
	}

	@Override
	public void atacar(Unidad enemigo) {
		this.formacion.get(0).atacar(enemigo);
	}

	@Override
	public void recibirAtaque(int danio) {
		int pos = (int)Math.floor(Math.random()*(this.formacion.size()+1)+0);
		Unidad victima = this.formacion.get(pos);
		victima.recibirAtaque(danio);
	}

	@Override
	public boolean estaVivo() {
		for (Unidad unidad : formacion) {
			if(unidad.estaVivo()) {
				
			}
		}
		return false;
	}

}
