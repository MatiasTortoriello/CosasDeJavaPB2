package EjercicioCarrito;

public class Articulo implements Vendible{
	private String descripcion;
	private double precio;
	
	public Articulo(String desc, double prec) {
		descripcion=desc;
		precio=prec;
	}
	
	public String getDescripcion(){
		return descripcion;
	}
	
	@Override
	public double getPrecio() {
		return precio;
	}
	
}
