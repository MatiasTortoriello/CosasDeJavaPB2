
public class Ejercicio6Luchadores {

	public static void main(String[] args) {
		int[][] luchadores = new int[][]{{300, 1500},
											{320, 1500},
											{299, 1580}};//peso - altura
		int cantLuchadores;
		
		
		299 1580
		330 1690
		330 1540
		339 1500
		298 1700
		344 1570
		276 1678
		289 1499
		
		//cantLuchadores = primer linea del archivo;
		cantLuchadores = 10;
		
		/*while(!EOF){
		 * luchadores = leido;
		 */
		luchadores[0][0] = ;
		
		
	}

}
