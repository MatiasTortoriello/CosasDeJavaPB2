package ar.edu.unlam.ae;

public class Pasajero {

	private Integer dni;

	public Pasajero(Integer dni) {
	this.dni=dni;
	}

	public Integer getDni() {
		return dni;
	}

	public void setDni(Integer dni) {
		this.dni = dni;
	}

}
