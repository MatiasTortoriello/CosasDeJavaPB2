package ar.edu.unlam.pb2.interfaces;

import ar.edu.unlam.pb2.FlojoDePapelesException;
import ar.edu.unlam.pb2.NoRespetoSemaforoException;
import ar.edu.unlam.pb2.PesoMaximoException;
import ar.edu.unlam.pb2.VelocidadMaximaException;

public interface Multeable {

	public Boolean superoVelocidadMaxima() throws VelocidadMaximaException;
	public Boolean superoPesoMaximoCarga() throws PesoMaximoException;
	public Boolean cruzoEnRojo() throws NoRespetoSemaforoException;
	public Boolean estaEnRegla() throws FlojoDePapelesException;
}
