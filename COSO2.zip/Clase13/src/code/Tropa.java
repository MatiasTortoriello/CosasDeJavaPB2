package code;

import java.util.ArrayList;

public class Tropa extends Unidad {
	
	private ArrayList<Unidad> tropa;
	
	public Tropa() {
		this.tropa = new ArrayList<Unidad>();
	}
	
	public void agregarGuerrero(Guerrero g) {
		this.tropa.add(g);
	}
	
	public void atacar(Tropa enemigo) {
		enemigo.recibirAtaque(this.tropa.get(0).getDanioAtaque());
	}
	
	public void recibirAtaque(int danio) {
		int pos = (int)Math.floor(Math.random()*(this.tropa.size()+1)+0);
		this.tropa.get(pos).recibirAtaque(danio);
		if(this.tropa.get(pos).getVida()==0) {
			this.tropa.remove(pos);
		}
	}
	
	

}
