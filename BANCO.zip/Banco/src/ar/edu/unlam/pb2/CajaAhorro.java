package ar.edu.unlam.pb2;

public class CajaAhorro extends Cuenta {
	
	private String tipo;
	
	public CajaAhorro(Integer numCuenta, Integer dni, String nombre, String apellido, String tipo) {
		super(numCuenta, dni, nombre, apellido);
		this.tipo = tipo;
		
		// TODO Auto-generated constructor stub
	}

	

	public String getTipo() {
		return tipo;
	}

	public void setTipo(String tipo) {
		this.tipo = tipo;
	}
	
}
