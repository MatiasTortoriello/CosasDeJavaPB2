package code;

public class Paquete {

	private double tam;
	private double peso;
	private String destino;
	
	public Paquete(double tam, double peso, String destino) {
		super();
		this.tam = tam;
		this.peso = peso;
		this.destino = destino;
	}

	public double getTam() {
		return tam;
	}

	public double getPeso() {
		return peso;
	}

	public String getDestino() {
		return destino;
	}	
	
}
