
public abstract class Unidad {
	public abstract void daniar(Unidad otro);
	public abstract void recibirDanio(int danio);
	public abstract boolean estaVivo();
}
