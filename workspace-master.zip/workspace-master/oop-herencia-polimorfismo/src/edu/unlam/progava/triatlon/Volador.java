package edu.unlam.progava.triatlon;

public interface Volador {

	public void volar();	
}
