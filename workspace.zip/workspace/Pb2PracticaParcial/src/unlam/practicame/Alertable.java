package unlam.practicame;

public interface Alertable {

	public void marcarComoCasoSospechoso();
	public void confirmarSiFueFraude(Boolean fueFraude);
	
}

