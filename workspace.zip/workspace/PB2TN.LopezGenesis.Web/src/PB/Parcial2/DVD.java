package PB.Parcial2;

public class DVD extends FileSystem{
	
	private Boolean cerrado;
	
	public void agregarArchivo(){
		
	}

}
