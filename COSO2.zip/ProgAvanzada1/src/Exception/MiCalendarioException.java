package Exception;

public class MiCalendarioException extends Exception {

	public MiCalendarioException(String message) {
		super(message);
	}
	
}
