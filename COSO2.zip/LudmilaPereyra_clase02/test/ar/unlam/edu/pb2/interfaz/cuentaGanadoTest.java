package ar.unlam.edu.pb2.interfaz;

import static org.junit.Assert.*;

import org.junit.Test;

public class cuentaGanadoTest {

	@Test
	public void queSePuedaCrearUnCuentaGanado() {
	CuentaGanado cuentaGanado= new CuentaGanado();
	assertNotNull(cuentaGanado);
	}
	
	@Test
	public void queSeCreeUnCuentaGanadoConElContadorEnCero(){
	
	CuentaGanado cuentaGanado= new CuentaGanado();
	Integer valorEsperado=0;
	Integer valorObtenido =cuentaGanado.getContador();
	assertEquals(valorEsperado, valorObtenido);
	
	}
	
	@Test
	public void queElContadorSume(){
		CuentaGanado cuentaGanado= new CuentaGanado();
		Integer valorDeseado=1;
		cuentaGanado.sumar();
		Integer valorObtenido=cuentaGanado.getContador();
		assertEquals(valorDeseado,valorObtenido);
	}
	
	@Test
	public void queAlPasarElLimiteSeaCero(){
		CuentaGanado cuentaGanado= new CuentaGanado();
		Integer valorEsperado=0;
		cuentaGanado.sumar();
		cuentaGanado.sumar();
		cuentaGanado.sumar();
		cuentaGanado.sumar();
		cuentaGanado.sumar();
		cuentaGanado.sumar();
		cuentaGanado.sumar();
		cuentaGanado.sumar();
		cuentaGanado.sumar();
		cuentaGanado.sumar();
		Integer valorObtenido=cuentaGanado.getContador();
		assertEquals(valorEsperado,valorObtenido);
	}
	@Test
	public void reset(){
		CuentaGanado cuentaGanado= new CuentaGanado();
		Integer valorDeseado=0;
		cuentaGanado.reset();
		Integer valorObtenido= cuentaGanado.getContador();
		assertEquals(valorDeseado,valorObtenido);
	}
	
	@Test
	public void cualquierCosa(){
		Double x 7.0
		Double y 3.0
		Double division
		Double suma
		Double valorEsperadoSuma
		Double valoresperaroDivision=
		Double division
		assertEquals(divisionbelta)
		ssert(suma)
	}

}
