package dominio;

public class Habitante {

	private Integer dni;
	private String nombre;
	
	public Habitante(Integer dni, String nombre) {
		this.dni = dni;
		this.nombre = nombre;
	}

}
