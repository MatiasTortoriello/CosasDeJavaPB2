
public abstract class Unidad {
	protected boolean activo;
	
	Unidad(){
		activo = true;
	}
	
	public void atacar(Unidad otraUnidad){
		if(!this.activo){
			return;
		}
		otraUnidad.recibirDanio();
	}
	
	public void morir(){
		this.activo = false;
	}
	
	public abstract void recibirDanio();
	
}
