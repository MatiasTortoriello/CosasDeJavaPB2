#include <stdio.h>
#include <stdlib.h>
#include "funciones.h"
#include <string.h>
#define NOMBRE "datos.dat"
#define ARCHTEXTO "novedades.txt"

int main()
{
    if(creararchivo(NOMBRE))
    {
        leerarchivo(NOMBRE);

        leertxt(ARCHTEXTO,NOMBRE);

        leerarchivo(NOMBRE);
    }
    return 0;
}
