package UnidadesRes;

public class Pie extends UnidadDeLongitud {
	private double valor;

	public Pie(double valor) {
		super(valor);
	}

	@Override
	public Kilometro toKilometro() {
		return new Kilometro(this.valor / 3281);
	}

	@Override
	public Milla toMilla() {
		return new Milla(this.valor / 5280);
	}

	@Override
	public Metro toMetro() {
		return new Metro(this.valor / 3.281);
	}

	@Override
	public Pie toPie() {
		return this;
	}
	
	@Override
	public UnidadDeLongitud sumar(UnidadDeLongitud other) {
		return new Pie(this.valor + other.toPie().valor);
	}
	
	@Override
	public UnidadDeLongitud enMiUnidad(UnidadDeLongitud other) {
		return other.toPie();
	}

	@Override
	public String toString() {
		return this.valor + "ft";
	}

}
