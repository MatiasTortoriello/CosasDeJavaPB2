package monti;

import java.util.ArrayList;

public class Monticulo<T> {

	ArrayList<T> array = new ArrayList<T>();
	
	public Monticulo()
	{
		array.add(null);
	}
	
	public void agregarAMonticulo(T num)
	{
		array.add(num);
		int pos = array.size();
		int posPadre = array.size();
		
		while((Integer)array.get(posPadre) < (Integer)num)
		{
			array.set(pos, array.get(posPadre));
			array.set(posPadre, num);
			posPadre=posPadre/2;
			
		}

		
	}
}
