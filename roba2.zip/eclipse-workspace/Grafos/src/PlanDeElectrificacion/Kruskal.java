package PlanDeElectrificacion;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class Kruskal {
	
	private static int cantNodos;
	private static int[] references;
	private static List<Arista> aristas = new ArrayList<Arista>();
	
	private static int find(int references[], int x) {
		return (x == references[x] ? x : find(references, references[x]));
	}
	
	private static void union(int references[], int x, int y) {
		references[find(references, x)] = find(references, y);
	}
	
	private static void initReferences(int references[], int cantNodos) {
		for (int i = 0; i < cantNodos; i++) {
			references[i] = i;
		}
	}
	
	
	public void ejecutar(Grafo grafo) {
		cantNodos = grafo.getNodes();
		references = new int[cantNodos];
		
		initReferences(references, cantNodos);
		int fil = 0, col = 1;
		while (fil <= grafo.getNodes()) {
			double pesoArista = grafo.getEdge(fil, col);
			// fil == des // col == hasta
			if(pesoArista != Double.MAX_VALUE) {
				aristas.add(new Arista(fil, col, pesoArista));
			}
			col++;
			if (col >= grafo.getNodes()) {
				fil++;
				col = fil + 1;
			}
		}
		
		Collections.sort(aristas);
		
		int cantAristas = 0, i = 0;
		double pesoTotal = 0;
		Arista aristaActual;
		
		while (cantAristas < cantNodos - 1) {
			aristaActual = aristas.get(i);
			if (find(references, aristaActual.origen) != find(references, aristaActual.destino)) {
				union(references, aristaActual.origen, aristaActual.destino);
				pesoTotal += aristaActual.peso;
				cantAristas++;
			}
			i++;
		}	
		
	}

	class Arista implements Comparable<Arista> {
		int origen, destino;
		double peso;
		
		public Arista(int origen, int destino, double peso) {
			this.origen = origen;
			this.destino = destino;
			this.peso = peso;
		}

		@Override
		public int compareTo(Arista o) {
			return Double.compare(this.peso, o.peso);
		}
	}
}
