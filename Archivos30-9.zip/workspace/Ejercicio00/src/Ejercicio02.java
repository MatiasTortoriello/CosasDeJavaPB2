
public class Ejercicio02 {
	
//	public static void main(String[] args) {
//	int[][]entrada={
//			 {8,  2, -3,  4}
//			 {5, -6, -6, 20}
//			{21,  1, -5,  0}
//	};
//	}
}
