
public class ConEspada {
	
	public int getDanio() {
		
	}
	
	public int getDefensa() {
		
	}
}
