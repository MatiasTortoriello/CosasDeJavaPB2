package prueba;

import java.io.File;

public class Prueba {
	
	public static void main(String[] args) {
//		try {
			leer();
//		} catch (ArrayIndexOutOfBoundsException e) {
//			// TODO Auto-generated catch block
//			System.out.println(e.toString());
//			System.out.println("exception");
//		}
	}
	
	public static void leer() /*throws ArithmeticException*/{
		int[] a = new int[2];
		
		for(int i=0;i<=a.length;i++){
			try{
				a[i] = 5/i;
			}catch (ArithmeticException e) {
				System.out.println(e.toString());
//			}catch (ArithmeticException e) {
//				// TODO: handle exception
//				System.out.println(e.toString());
			}
			finally{
				System.out.println("finally");
			}
			System.out.println("prueba");
		}
		
	}
	
	

}
