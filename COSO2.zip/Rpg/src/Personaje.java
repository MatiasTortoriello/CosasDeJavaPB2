
public class Personaje extends Inicio{
	private int da�o = 0;

	@Override
	public int getDa�o() {
		return da�o;
	}
	
	
}
