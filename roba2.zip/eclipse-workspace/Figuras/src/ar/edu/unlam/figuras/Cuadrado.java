package ar.edu.unlam.figuras;

public class Cuadrado extends Figura {

	private double lado;//esto nunca va a existir en figura
	
	public Cuadrado(String nombre) {
		super(nombre);//construccion del padre. Esta linea suele ser la primera
	}

	public Cuadrado(String nombre, String color, Double lado) {
		super(nombre, color);
		this.lado = lado;
	}

	
	public Double calcularArea() {
	 
		return Math.pow(this.lado, this.lado); 
	
	}
	 
	

}
