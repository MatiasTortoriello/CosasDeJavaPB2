package ar.unlam.alumnotest;

import static org.junit.Assert.*;

import org.junit.Test;

import ar.unlam.alumno.Alumno;

public class AlumnoTest {

	@Test
	public void queSePuedaCrearAlumno() {
		// preparacion
		String nombre = "Sofia";
		String apellido = "Rodriguez";
		Integer dni = 43567890;
		Boolean estado = true;
		String legajo = "34KJB3";

		Alumno miAlumno = new Alumno();
		// Ejecucion
		Alumno alumnoAgregado = miAlumno.crearAlumno(nombre, apellido, dni, estado, legajo);
		// Verificacion
		assertEquals(alumnoAgregado.getNombre(), nombre);
		assertEquals(alumnoAgregado.getApellido(), apellido);
		assertEquals(alumnoAgregado.getDni(), dni);
		assertEquals(alumnoAgregado.getEstado(), estado);
		assertEquals(alumnoAgregado.getLegajo(), legajo);

	}
}
