package ar.edu.unlam.pb2;

import static org.junit.Assert.*;

import org.junit.Test;

public class TestSecretaria {

	@Test
	public void queSePuedaCrearUnaSecretaria() {
		Secretaria secretaria = new Secretaria("Cordoba");
		assertNotNull(secretaria);
	}

	@Test
	public void queSePuedaAgregarUnHabitanteALaSecretaria() {
		Integer numeroMunicipio = 1;
		String nombreMunicipio = "San justo";
		Municipio municipio = new Municipio(numeroMunicipio, nombreMunicipio);
		
		String calle = "Varela";
		Integer numero = 2153;
		Vivienda vivienda = new Vivienda(calle, numero, municipio);
		
		Integer dni = 42132541;
		String nombre = "Juan";
		Habitante habitante = new Habitante(dni, nombre, vivienda);
		
		Secretaria secretaria = new Secretaria("Cordoba");
		
		secretaria.agregarHabitante(habitante);
		
		Integer valorEsperado = 1;
		Integer ValorObtenido =secretaria.obtenerCantidadDeHabitantes(); 
		assertEquals(valorEsperado, ValorObtenido);
	}
	
	
	
	
	
	
	

}
