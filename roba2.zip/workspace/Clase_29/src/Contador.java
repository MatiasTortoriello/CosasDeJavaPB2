
public class Contador {

	private final int MAXIMO_VALOR_CONTADOR = 9999;
	private int contador;
	
	//con STATIC:
//	private static final int MAXIMO_VALOR_CONTADOR = 9999;
//	private static int contador;

	// metodos
	public void contar() {
		if(contador == MAXIMO_VALOR_CONTADOR){	//numero sin explicar nada es un magic number, mejor usar constante
			contador = 0;
		}
		else{
			this.contador++;
		}
		this.contador++;
	}

	public void reiniciar() {
		this.contador = 0;
	}

	public int mostrar() {
		return this.contador;
	}

	public static void main(String[] args) {
		Contador cont1 = new Contador();
		
		
		cont1.contar();
		System.out.println(cont1.mostrar());
		cont1.reiniciar();
	}

}
