#ifndef FUNCIONES_H_INCLUDED
#define FUNCIONES_H_INCLUDED
#include <stdio.h>
#include "funciones.h"

typedef struct
{
    int id;
    char nombre[32];
    int cantidad;
    float precio;
    int volprod;
}tProductos;

typedef struct
{
    int id;
    int cantidad;
    char tipo;
}tNovedades;

int creararchivo(char *nombre);
void mostrarAct(tNovedades const *aux);
void TrozarCamposLongVariable(tNovedades *d,char *cad);
int actualizararch(const char *archbin,tNovedades *aux);
int leertxt(char *archtexto,char *archbin);
int leerarchivo(char *nombre);
int buscarPorDNI(FILE *fp, tProductos *pe);

#endif // FUNCIONES_H_INCLUDED
