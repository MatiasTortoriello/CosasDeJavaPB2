package UnidadesRes;

public abstract class UnidadDeLongitud {

	protected double valor;

	public UnidadDeLongitud(double valor) {
		super();
		this.valor = valor;
	}

	public abstract Metro toMetro();

	public abstract Kilometro toKilometro();

	public abstract Pie toPie();

	public abstract Milla toMilla();
	
	public abstract UnidadDeLongitud sumar(UnidadDeLongitud other);
	
	public static UnidadDeLongitud sumar(UnidadDeLongitud u1, UnidadDeLongitud u2) {
		return new Metro(u1.toMetro().valor + u2.toMetro().valor);
	}
	
	public abstract UnidadDeLongitud enMiUnidad(UnidadDeLongitud other);
	public abstract UnidadDeLongitud crear(double valor);

}
