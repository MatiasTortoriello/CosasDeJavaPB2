package unlam;

public enum TipoDeComplejo {Polideportivo , Simple

}
