package ar.edu.unlam.pb2.eva03;

public class Beneficiario extends Persona{
	
	public Beneficiario(String Nombre, Integer dni, Integer a) {
		super(Nombre, dni, a);
		// TODO Auto-generated constructor stub
	}
	
}
