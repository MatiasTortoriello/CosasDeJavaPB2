package excepcion;

public class RadioNegativoException extends Exception{
	
	private static final long serialVersionUID = -15822608;
	
	
	public RadioNegativoException(){
		
	}
}
