import java.util.ArrayList;

public class Monticulo {
	ArrayList<Integer> array;
	
	Monticulo(){
		array = new ArrayList<Integer>();
		array.add(null);
	}
	
	public void insertar (int elemento){
		this.array.add(elemento);
//		if(this.array.size() == 1){
//			return;
//		}
		buscarPosicionDeInsersion( (this.array.indexOf(elemento) / 2), this.array.indexOf(elemento));
				
		return;
	}
	
	public void buscarPosicionDeInsersion (int posicionPadre, int posicionHijo){
		if(posicionPadre == 0){
			return;
		}
		int hijo = this.array.get(posicionHijo);
		int padre = this.array.get(posicionPadre);
		
		if( hijo > padre){
			return;
		}
		
		this.array.set(posicionPadre, hijo);
		this.array.set(posicionHijo, padre);
		padre = hijo;
		buscarPosicionDeInsersion(this.array.indexOf(padre)/2, this.array.indexOf(padre));
	}
	
	public void remover (){
		
	}
		
}


















