package Packs;

public class PackRegalo extends Pack {

}
