package patron_Composite;

public class Guerrero extends Unidad {
	private int salud = 100;
	
	public Guerrero() {
		
	}

	@Override
	public void atacar(Unidad enemigo) {
		enemigo.recibirAtaque(10);
	}

	@Override
	public void recibirAtaque(int danio) {
		this.salud-=danio;
		if(this.salud < 0) {
			this.salud = 0;
		}
	}
	
	public int getSalud() {
		return this.salud;
	}

	@Override
	public boolean estaVivo() {
		return this.salud > 0;
	}
	
	
	
}
