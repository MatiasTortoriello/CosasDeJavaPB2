import java.util.ArrayList;

public class ColaDePrioridad {
//	private ArrayList<Integer> cola = new ArrayList<Integer>();
//
//	public void insertar(int elem) {
//		cola.add(elem);
//	}
//
//	public int getMax() {
//		int max = cola.get(0);
//
//		for (Integer integer : cola) {
//
//			if (max < integer)
//				max = integer;
//		}
//
//		return max;
//	}
//
//	public void removeMax() {
//		int max = 0;
//
//		for (int i = 0; i < cola.size(); i++) {
//
//			if (cola.get(max) < cola.get(i))
//				max = i;
//		}
//		cola.remove(max);
//	}
	private ArrayList<Integer> monticulo = new ArrayList<Integer>();
	private ArrayList<Integer> monticuloAux= new ArrayList<Integer>(this.monticulo.size()+1);
	
	public void insertar(int elem) {
		if(monticulo.isEmpty()){
			monticulo.add(0);
			monticulo.add(elem);
		}
		else{
			for (int i = 1; i <= monticuloAux.size(); i++) {
				if(monticulo.get(i)<elem)
					monticuloAux.add(i,elem);
				else
					monticuloAux.add(i,this.monticulo.get(i));
			}
			this.monticulo=monticuloAux;
		}
	}
	
	public Integer remove(){
		if(monticulo.size() == 1)
			return null;
		
		return this.monticulo.remove(1);
	}
	
	

	@Override
	public String toString() {
		return "ColaDePrioridad [monticulo=" + monticulo + "]";
	}

	public static void main(String[] args) {
		ColaDePrioridad prueba = new ColaDePrioridad();
		
		prueba.insertar(1);
		prueba.insertar(4);
		prueba.insertar(6);
		prueba.insertar(5);
		prueba.insertar(8);
		
		System.out.println(prueba);

	}
}


