package ar.edu.unlam.pb2.eva03;

public class PolizaDeAuto extends Poliza implements SegurosGenerales{

	private Auto auto;
	private Boolean fueRobado=false;	
	
	public PolizaDeAuto(Integer nUMERO_DE_POLIZA, Persona asegurado, Double sUMA_ASEGURADA, Double pRIMA) {
		// TODO Auto-generated constructor stub
		super(nUMERO_DE_POLIZA, asegurado, sUMA_ASEGURADA, pRIMA);

	}
	@Override
	public void agregarBienAsegurado(Auto auto) {
		this.auto=auto;
		
	}
	public Auto getAuto() {
		return auto;
	}
	public void setAuto(Auto auto) {
		this.auto = auto;
	}
	@Override
	public void agregarBienAsegurado(Vivienda vivienda) {
		// TODO Auto-generated method stub
		
	}
	public Boolean FueRobado() {
		return fueRobado;
	}
	public void setFueRobado(Boolean fueRobado) {
		this.fueRobado = fueRobado;
	}


	
}
