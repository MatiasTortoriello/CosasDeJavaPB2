
public class conAmuleto extends conItem{
	int da�oTotal;
	int multDa�o=2;
	
	public conAmuleto(Inicio pj) {
		super(pj);
	}

	@Override
	public int getDa�o() {	
		return super.getDa�o()*multDa�o;
	}
}
