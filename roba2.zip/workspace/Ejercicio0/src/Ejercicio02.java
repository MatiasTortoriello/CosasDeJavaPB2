import java.util.Arrays;

/*
 * Escribir un m�todo en Java que de una matriz num�rica dada, devuelva una matriz con la misma cantidad de elementos, pero donde cada valor es la suma de sus adyacentes originales (arriba, abajo, izquierda, y derecha; si existen)

Ejemplo:
Para la matriz
 8  2 -3  4
 5 -6 -6 20
21  1 -5  0

La salida debe ser
15  1  -3 21
28 -4   0 18
27 11 -10 15
 * 
 * 
 * */
public class Ejercicio02 {
	
	public static void main(String[] args) {
		int[][] entrada={{8,  2, -3,  4},{5, -6, -6, 20},{21,  1, -5,  0}};
		Ejercicio02 e2=new Ejercicio02();
		int[][] salida=e2.resolver(entrada);
		for(int i=0;i<salida.length;i++){
			System.out.println(Arrays.toString(salida[i]));
		}
	}
	//Copio matriz original en matriz lucas con bordes en 0
	private int[][] resolver(int[][] entrada) {
		int[][] matrizLucas = new int[entrada.length+2][entrada[0].length+2];
		int[][] matrizSalida = new int[entrada.length][entrada[0].length];
		for(int i=1;i<matrizLucas.length;i++){
			for(int j=1;j<matrizLucas[i].length;j++){
				matrizLucas[i+1][j+1]=entrada[i][j];
			}
		}
		//
		for(int i=0;i<matrizLucas.length-1;i++){
			for(int j=0;j<matrizLucas[i].length;j++){
				matrizSalida[i-1][j-1]= matrizLucas[i][j]+matrizLucas[i-1][j]+matrizLucas[i][j-1]+matrizLucas[i+1][j]+matrizLucas[i][j+1];
			}
		}
		return matrizSalida;
	}

}
