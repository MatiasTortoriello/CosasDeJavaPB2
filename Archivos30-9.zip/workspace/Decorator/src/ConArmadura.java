
public class ConArmadura {
	
	public int getDanio() {

	}

	public int getDefensa() {

	}
}
