package EjercicioCarrito;

public class PackDescuento extends Pack{
	private int porcentajeDesc;
	
	public PackDescuento(int porcentaje){
		porcentajeDesc=porcentaje;
	}

	@Override
	public void agregarArticulo(Articulo articulo) {
		precio+=(articulo.getPrecio() * porcentajeDesc)/100;
		articulos.add(articulo);
	}

}
