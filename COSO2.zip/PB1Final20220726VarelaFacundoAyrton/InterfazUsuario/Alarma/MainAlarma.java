package Alarma;

import java.util.Scanner;

public class MainAlarma {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner teclado = new Scanner(System.in);
		String nombre = "";
		int cantidadDeSensoresMaximos;
		String codigo = "";
		int opcionElegida = 0;
		boolean alarmaActivada=false;
		final int AGREGAR_SENSOR = 1, HABILITAR_O_DESHABILITAR = 2, HABILITAR_POR_ZONA = 3,
				OBTENER_SENSOR_POR_NOMBRE = 4, OBTENER_SENSORES_DEHABILITADOS_POR_ZONA = 5, SALIR = 9;
		System.out.println("Ingrese el nombre de la alarma: ");
		nombre = teclado.next();
		System.out.println("Ingrese la cantidad maximas de sensores posibles: ");
		cantidadDeSensoresMaximos = teclado.nextInt();
		do {
			System.out.println("Ingrese el codigo de Administracion o Configuracion:");
			codigo = teclado.next();
		} while (Alarma.validarCodigoIngresado(codigo) != true);
		
		Alarma nuevaAlarma = new Alarma(nombre, cantidadDeSensoresMaximos, codigo);
		
		if (nuevaAlarma.getCODIGO_ADMINISTRADOR().equals(codigo)) {
			do {
				menuOpcionesAdmin();
				opcionElegida = teclado.nextInt();
				switch (opcionElegida) {
				case AGREGAR_SENSOR:
					int id = 0;
					String nombreDelSensor = "";
					Zona zona;
					int estado = 0;
					int zonaElegida = 0;
					System.out.println("Ingrese la ID del sensor (numero): ");
					id = teclado.nextInt();
					System.out.println("Ingrese el nombre del sensor");
					nombreDelSensor = teclado.next();
					System.out.println("En que zona de la casa lo quiere?: ");
					System.out.println("1- ENTRADA");
					System.out.println("2- PUERTA_TRASERA");
					System.out.println("3- INTERIOR");
					zonaElegida = teclado.nextInt();
					zona = Zona.values()[zonaElegida - 1];
					System.out.println("Ingrese el estado en que se encuentra: ");
					System.out.println("0 - Desactivado / 1 - Activado");
					estado = teclado.nextInt();
					Sensor nuevoSensor = new Sensor(id, nombre, zona, estado);
					
					if (nuevaAlarma.agregarSensor(nuevoSensor)==false) {
						System.out.println("Error al agregar sensor.");
					} else{
						System.out.println("Sensor agregado.");
					}
					break;
				case HABILITAR_O_DESHABILITAR:
					System.out.println("Ingrese la id del sensor del cual quiere cambiar el estado: ");
					id = teclado.nextInt();
					if (nuevaAlarma.habilitarODeshabilitarSensor(id) == true) {
						System.out.println("Se cambio el estado del sensor");
					} else {
						System.out.println("Sensor no encontrado.");
					}
					break;
				case HABILITAR_POR_ZONA:
					System.out.println("Los sensores de que zona quiere habilitar?: ");
					System.out.println("1- ENTRADA");
					System.out.println("2- PUERTA_TRASERA");
					System.out.println("3- INTERIOR");
					zonaElegida = teclado.nextInt();
					zona = Zona.values()[zonaElegida - 1];
					if (nuevaAlarma.habilitarPorZona(zona) == true) {
						System.out.println("Los sensores de la zona fueron activados");

					} else {
						System.out.println("No hay sensores en la zona");
					}
					break;
				case OBTENER_SENSOR_POR_NOMBRE:
					System.out.println("Ingrese el nombre del sensor");
					nombre = teclado.next();
					if (nuevaAlarma.obtenerPorNombre(nombre) == null) {
						System.out.println("No se encuentra ese sensor");
					} else {
						System.out.println(nuevaAlarma.obtenerPorNombre(nombre));
					}
					break;
				case OBTENER_SENSORES_DEHABILITADOS_POR_ZONA:
					System.out.println("Ingrese los vectores deshabilitados de que zona quiere ver: ");
					System.out.println("1- ENTRADA");
					System.out.println("2- PUERTA_TRASERA");
					System.out.println("3- INTERIOR");
					zonaElegida = teclado.nextInt();
					zona = Zona.values()[zonaElegida - 1];
					if (nuevaAlarma.deshabilitadosPorZona(zona) == "") {
						System.out.println("No se encontraron sensores deshabilitados en la zona.");
					} else {
						System.out.println(nuevaAlarma.deshabilitadosPorZona(zona));
					}
					break;
				case SALIR:
					System.out.println("Fin del programa.");
					break;
				default:
					System.out.println("Opcion incorrecta.");
					break;
				}
			} while (opcionElegida != SALIR);

		}
		/*else if (nuevaAlarma.getCODIGO_ACTIVACION().equals(codigo)){
			if (nuevaAlarma.cambiarEstadoAlarma()==false){
				System.out.println("Se desactivo la alarma");
			}
			else{
				
				System.out.println("Se desactivo la alarma");
			}
		}*/
		else{
			System.out.println("este codigo no es ninguno de los 2 preseteados. Fin del programa.");
		}
	}
		//Menu de activacion/desactivacion

	private static void menuOpcionesAdmin() {
		System.out.println("Menu de opciones de Administrador:");
		System.out.println("1- Agregar sensor");
		System.out.println("2- Habilitar o Deshabilitar sensor");
		System.out.println("3- Habilitar todos los sensores de una zona");
		System.out.println("4- Obtener un sensor por su nombre");
		System.out.println("5- Obtener todos los sensores deshabilitados de una zona determinada");
		System.out.println("9- SALIR");
	}
}
