
public abstract class Unidad {
	public abstract int getDanio();
	public abstract int getDefensa();
	
}
