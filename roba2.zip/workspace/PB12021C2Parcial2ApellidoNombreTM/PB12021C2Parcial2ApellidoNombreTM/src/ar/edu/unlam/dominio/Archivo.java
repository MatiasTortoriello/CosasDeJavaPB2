package ar.edu.unlam.dominio;

public class Archivo {
	double tamanio;
	String nombre;
	
	public Archivo() {
		
	}
}
