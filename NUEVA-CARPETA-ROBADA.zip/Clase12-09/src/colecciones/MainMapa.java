package colecciones;

import java.util.HashMap;
import java.util.Map;
import java.util.TreeMap;

public class MainMapa {

	public static void main(String[] args) {
		
//		Map<Integer,String> mapa = new TreeMap<>();
		HashMap<Integer,String> mapa = new HashMap<>();
		
		mapa.put(1, "Yair");
		mapa.put(2, "Micael");
		mapa.put(3, "Zitzmann");
		
		System.out.println(mapa.get(3));
		System.out.println(mapa.containsKey(4));
		System.out.println(mapa.containsValue("Yair"));
		System.out.println(mapa.keySet());
		System.out.println(mapa.values());
		
//		HashMap<String,String> mapa2 = new HashMap<>();// al insertar String, ordena las claves por hashcode
		TreeMap<String,String> mapa2 = new TreeMap<>();// al insertar String, ordena las claves por compareTo
		mapa2.put("first", "Yair");
		mapa2.put("second", "Micael");
		mapa2.put("third", "Zitzmann");
		
		System.out.println(mapa2.keySet());
		System.out.println(mapa2.values());
		
		System.out.println(mapa2.entrySet());
		System.out.println(mapa2.getOrDefault("fourth", "no esta"));
		System.out.println(mapa2.getOrDefault("first", "no esta"));
		
		
	}
	
}
