package Unidades;

public enum Tipo {
 
	METRO, KILOMETRO, MILLA, PIE;
}
