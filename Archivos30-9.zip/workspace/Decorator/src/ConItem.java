
public abstract class ConItem extends Unidad{
	private Unidad unidad;

	public ConItem(Unidad unidad) { //mando unidad q es el personaje, a quien decoro
		
	}
	
}
